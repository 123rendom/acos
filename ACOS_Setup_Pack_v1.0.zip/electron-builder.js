// Electron Configuration for ACOS Windows EXE Build
export default {
  productName: "ACOS AI Creative Operating System",
  appId: "com.acos.app",
  
  files: [
    "build/**/*",
    "package.json",
    "electron/**/*"
  ],

  extraResources: [
    // Python bridge backend copied to <resources>/acos so main.cjs can spawn it
    // in packaged builds (app.asar cannot contain the spawnable script path).
    { from: "src/acos", to: "acos" }
  ],

  directories: {
    output: "release-win32-x64",
    buildResources: "resources",
  },

  win: {
    target: [
      {
        target: "dir",
        arch: ["x64"]
      },
      {
        target: "nsis",
        arch: ["x64"]
      }
    ],
  },

  nsis: {
    oneClick: false,
    allowToChangeInstallationDirectory: true,
  },
};
