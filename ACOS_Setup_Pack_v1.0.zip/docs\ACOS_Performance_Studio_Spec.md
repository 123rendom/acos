# ACOS Performance / Acting Studio — Design Specification

> **Studio ID:** STUDIO-34
> **Version:** 1.0
> **Format:** Borderless 16:9 Desktop Application
> **Resolution Target:** 8K (7680 x 4320)
> **Design Language:** Dark Glass + Neural Performance + Cinematic Acting

---

## 1. VISUAL IDENTITY

### 1.1 Color Palette

| Role | Token | Value |
|---|---|---|
| Deep Black Base | `--studio-bg-deep` | `#05050A` |
| Midnight Navy | `--studio-bg-midnight` | `#0A0E1A` |
| Surface Glass | `--studio-glass-bg` | `rgba(10, 14, 30, 0.72)` |
| Glass Border | `--studio-glass-border` | `rgba(0, 240, 255, 0.08)` |
| Performance Accent | `--studio-performance` | `#FF6B9D` |
| Performance Glow | `--studio-performance-glow` | `rgba(255, 107, 157, 0.35)` |
| Neural Cyan | `--studio-cyan` | `#00F0FF` |
| Neural Blue | `--studio-blue` | `#3B82F6` |
| Surface Text | `--studio-text` | `#F0F9FF` |
| Secondary Text | `--studio-text-dim` | `#64748B` |
| Success Green | `--studio-success` | `#10B981` |
| Warning Amber | `--studio-warning` | `#F59E0B` |

### 1.2 Typography

- **Display:** Orbitron (headings, performance labels)
- **Body:** Inter (parameters, descriptions)
- **Mono:** JetBrains Mono (values, timeline)

### 1.3 Atmosphere

- Deep black background with cyan-blue neural rim lighting
- Performance pink `#FF6B9D` accent on active emotion cards and AI core
- Particle flow visualization: waveform (cyan) -> AI core (pink-cyan) -> body (blue) -> facial (pink)
- Dark glass panels with `backdrop-filter: blur(20px)`
- Subtle grid pulse and scanline overlays

---

## 2. LAYOUT ARCHITECTURE

### 2.1 Full Desktop Layout (16:9)

```
+------------------------------------------------------------------+
|  APPLICATION BAR (ACOS Shell)                                    |
+------------------------------------------------------------------+
| LEFT: EMOTION LIBRARY    |  CENTER: PERFORMANCE PREVIEW      | RIGHT: PERFORMANCE CONTROLS |
| 280px glass              |  Flex - neural flow visualization | 320px glass                 |
|                          |                                   |                             |
|  Fear                    |  [Waveform] -> [AI CORE] ->       |  Emotion                    |
|  Anger                   |  [Body Rig] -> [Facial Rig]       |  Intensity 0-100            |
|  Happiness               |                                   |  Facial 0-100               |
|  Sadness                 |  Particle streams connect stages  |  Gesture                    |
|  Suspense                |  Character silhouette with        |  Body Language              |
|  Confidence              |  skeletal overlay                 |  Eye Direction              |
|  Shock                   |  Real-time expression morph       |  Timing                     |
|  Love                    |                                   |  Personality                |
|  Pain                    |  Timeline sync bar below viewport |                             |
|  Determination           |                                   |  AI State + Progress        |
+--------------------------+-----------------------------------+-----------------------------+
| BOTTOM: TIMELINE SYNC - Dialogue / Camera / Sound (140px glass strip)                   |
| Dialogue waveform | Camera keyframes | Sound cues | Frame markers 01-48                  |
+------------------------------------------------------------------+
| STATUS BAR                                                       |
+------------------------------------------------------------------+
```

### 2.2 Panel Specifications

| Panel | Width | Style |
|---|---|---|
| Left: Emotion Library | 280px | Glass, pink accent on selection, icon + intensity badge |
| Center: Performance Preview | Flex | Canvas with waveform, AI core, body/facial flow, particle streams |
| Right: Performance Controls | 320px | Glass, collapsible sliders, AI inspector |
| Bottom: Timeline Sync | 140px height | Glass strip, multi-track timeline |

---

## 3. CENTER VIEWPORT

### 3.1 Performance Pipeline Visualization

```
Waveform (cyan audio bars)
    |
    v
[ AI CORE ] -- pulsing pink-cyan orb, state label inside
    |
    +--> Body Rig Stream (blue particles)
    +--> Facial Rig Stream (pink particles)
              |
              v
    Character Performer Preview (silhouette + facial mesh)
```

- **Waveform:** Real-time cyan bars driven by dialogue intensity, 32 bars animated at 60fps
- **AI Core:** Central orb, glow color matches AI state, pulse scale 0.98-1.04, particle emission ring
- **Body Flow:** Blue particle stream from core to skeletal figure (right side of center)
- **Facial Flow:** Pink particle stream from core to facial mesh overlay (center-bottom)
- **Character Preview:** Minimalist performer silhouette with joint markers and facial landmark dots, reacts to Emotion/Intensity sliders

### 3.2 Particle Flow System

| Stream | Origin -> Target | Color | Count | Speed |
|---|---|---|---|---|
| Audio -> Core | Waveform -> AI Core | `#00F0FF` cyan | 40 | 2.5 px/frame |
| Core -> Body | AI Core -> Body Rig | `#3B82F6` blue | 30 | 2.0 px/frame |
| Core -> Face | AI Core -> Facial Mesh | `#FF6B9D` pink | 30 | 2.2 px/frame |
| Ambient | Background drift | `rgba(0,240,255,0.08)` | 60 | 0.4 px/frame |

Particles fade on arrival, respawn at origin. Convergence when AI state = VALIDATED (all particles settle).

### 3.3 Performance Metrics Overlay

- **Current Emotion:** Active library selection label + color dot
- **Intensity Value:** 0-100 with gradient fill (cyan -> pink)
- **AI State Badge:** Orbitron 10px, state color, progress %
- **Frame Counter:** JetBrains Mono, current timeline frame

---

## 4. LEFT PANEL — EMOTION LIBRARY

### 4.1 Emotion Categories

| Emotion | Color | Description |
|---|---|---|
| Fear | `#8B5CF6` | Trembling micro-gestures, wide eyes, retracted posture |
| Anger | `#EF4444` | Clenched fists, forward lean, jaw tension |
| Happiness | `#F59E0B` | Open posture, smile, upward gaze |
| Sadness | `#3B82F6` | Slumped shoulders, downcast eyes, slow timing |
| Suspense | `#6366F1` | Held breath, stillness, anticipatory tension |
| Confidence | `#10B981` | Expanded chest, steady gaze, decisive gestures |
| Shock | `#EC4899` | Sudden recoil, widened eyes, gasp timing |
| Love | `#FF6B9D` | Soft gaze, gentle lean, warm facial bloom |
| Pain | `#F97316` | Contraction, wince, guarded body |
| Determination | `#06B6D4` | Focused brow, forward vector, locked jaw |

### 4.2 Card Style

- Glass background `rgba(10, 14, 30, 0.72)`
- Left border 2px transparent -> ` #FF6B9D` on active/hover
- Emotion dot (8px circle) with glow `0 0 8px <color>`
- Label Inter 13px `#F0F9FF`, sublabel JetBrains Mono 9px dim
- Intensity micro-bar (2px height) under label when active
- Single-click selects and triggers AI MAPPING_EMOTION

---

## 5. RIGHT PANEL — PERFORMANCE CONTROLS

### 5.1 Control Sections

| Section | Range | Default | Color | Description |
|---|---|---|---|---|
| Emotion | 0 - 100 | 50 | `#FF6B9D` | Blend weight of selected emotion archetype |
| Intensity | 0 - 100 | 65 | `#EC4899` | Overall performance energy, affects particle density |
| Facial | 0 - 100 | 70 | `#FF6B9D` | Facial expression amplitude, morph target weight |
| Gesture | 0 - 100 | 60 | `#F59E0B` | Hand/arm gesture exaggeration |
| Body Language | 0 - 100 | 55 | `#3B82F6` | Posture openness / contraction |
| Eye Direction | -60 to +60 deg | 0 | `#00F0FF` | Horizontal gaze offset, cyan reticle |
| Timing | 0.5x - 2.0x | 1.0x | `#A855F7` | Performance speed multiplier |
| Personality | 0 - 100 | 50 | `#10B981` | Trait consistency vs. situational override |

Each slider:
- Track height 4px, thumb 12px circle with color glow
- Label JetBrains Mono 10px, value badge cyan/pink 10px
- On change: triggers REFINING_EXPRESSION or SYNCING_BODY depending on control

### 5.2 AI State Inspector

Displays current AI state with color, progress bar (gradient cyan->pink), and description sentence. States:

| State | Color | Description |
|---|---|---|
| ANALYZING_DIALOGUE | `#00F0FF` | Parsing dialogue text, phonemes, sentiment |
| MAPPING_EMOTION | `#FF6B9D` | Mapping to emotion archetype, blending |
| GENERATING_GESTURE | `#F59E0B` | Synthesizing gesture trajectory |
| REFINING_EXPRESSION | `#EC4899` | Sculpting facial micro-expressions |
| SYNCING_BODY | `#3B82F6` | Synchronizing body rig with facial |
| VALIDATED | `#10B981` | Performance locked, ready for timeline |

Auto-advances via interval (120ms tick, +1.1% progress). On VALIDATED, status holds at 100% with steady green glow.

---

## 6. BOTTOM PANEL — TIMELINE SYNC

### 6.1 Triple-Track Timeline

- **Dialogue Track (cyan):** Waveform blocks, phoneme markers, subtitle cues. Height 32px.
- **Camera Track (purple):** Keyframe diamonds, lens focal labels. Height 22px.
- **Sound Track (amber):** Audio cue bars, beat markers. Height 22px.
- Frame ruler: 1-48 frames, tick marks every 4 frames, current playhead cyan line with glow
- Sync connectors: vertical dashed lines at dialogue-camera-sound alignment points, highlight pink when synced, amber when drift detected

### 6.2 Playback Controls

- Play/Pause (Space), scrub by dragging playhead, frame-step arrows
- Loop toggle, sync-lock toggle (forces dialogue+camera alignment)
- Zoom slider for timeline scale

---

## 7. AI PERFORMANCE AGENT

### 7.1 State Machine

```
ANALYZING_DIALOGUE -> MAPPING_EMOTION -> GENERATING_GESTURE
      -> REFINING_EXPRESSION -> SYNCING_BODY -> VALIDATED
```

Loop: VALIDATED holds until emotion or slider change resets to ANALYZING_DIALOGUE.

### 7.2 Particle Behavior Per State

| State | Particle Activity |
|---|---|
| ANALYZING_DIALOGUE | Cyan waveform particles flood toward core, core cyan pulse |
| MAPPING_EMOTION | Core emits pink mapping rays toward emotion library ghost |
| GENERATING_GESTURE | Blue body-stream accelerates, skeletal preview jitters |
| REFINING_EXPRESSION | Pink facial-stream intensifies, landmark dots shimmer |
| SYNCING_BODY | Blue + pink streams converge, character silhouette sync flash |
| VALIDATED | All streams settle, green validation ring around core, ambient particles at 8% opacity |

---

## 8. INTERACTION PATTERNS

### 8.1 Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `1-0` | Select emotion 1-10 |
| `Space` | Play/pause timeline |
| `G` | Generate performance |
| `R` | Reset to ANALYZING_DIALOGUE |
| `F` | Toggle facial overlay |
| `B` | Toggle body rig overlay |

### 8.2 Mouse Interactions

| Action | Button |
|---|---|
| Select emotion | Left click library card |
| Adjust slider | Drag slider thumb |
| Scrub timeline | Drag playhead |
| Orbit preview | Left drag on silhouette |
| Zoom preview | Scroll wheel |

---

## 9. MOTION & ANIMATION

- Panel slide transitions 250ms ease-out
- Emotion card hover 150ms ease
- Slider thumb glow on drag (0 0 12px color)
- Core pulse 1.6s ease-in-out infinite
- Particle streams 60fps canvas, additive blending
- Timeline playhead smooth interpolation 16ms

---

## 10. TECHNICAL SPECIFICATIONS

| Metric | Target |
|---|---|
| Viewport FPS | 60fps @ 4K with 160 particles |
| AI Cycle Time | ~8s per full state progression |
| Slider Latency | < 16ms |
| Timeline Scrub | 120fps interpolation |
| Canvas Resolution | DevicePixelRatio scaled, 8K ready |

---

## 11. DESIGN COHERENCE

Shares with ACOS ecosystem:
- Neural Core, Glass Surfaces, Particle Activity, Typography (Orbitron/Inter/JetBrains Mono), DesignTokens single source, cyan-blue illumination base with studio-specific pink `#FF6B9D` accent.

---

*Specification Version 1.0 — ACOS Creative Operating System*
*Design Standard: 8K, 16:9, Borderless Desktop*
*Color System: Deep Black + Midnight Navy + Performance Pink + Neural Cyan-Blue*
