# ACOS Final Mastering Studio — Design Specification

> **Studio ID:** STUDIO-40
> **Version:** 1.0
> **Format:** Borderless 16:9 Desktop Application
> **Resolution Target:** 8K (7680 x 4320)
> **Design Language:** Dark Glass + Neural Illumination
> **Accent Color:** #FACC15 (Master Gold)

---

## 1. VISUAL IDENTITY

### 1.1 Color Palette

| Role | Token | Value |
|---|---|---|
| Deep Black Base | `--studio-bg-deep` | `#05050A` |
| Midnight Navy | `--studio-bg-midnight` | `#0A0E1A` |
| Surface Glass | `--studio-glass-bg` | `rgba(10, 14, 30, 0.72)` |
| Glass Border | `--studio-glass-border` | `rgba(0, 240, 255, 0.08)` |
| Cyan Neural | `--studio-neural-cyan` | `#00F0FF` |
| Blue Neural | `--studio-neural-blue` | `#3B82F6` |
| Master Gold | `--studio-accent` | `#FACC15` |
| Gold Glow | `--studio-accent-glow` | `rgba(250, 204, 21, 0.38)` |
| Emerald Validated | `--studio-validated` | `#10B981` |
| Surface Text | `--studio-text` | `#F0F9FF` |
| Secondary Text | `--studio-text-dim` | `#64748B` |

### 1.2 Typography

- **Display:** Orbitron (master titles, pipeline phase names, viewer labels)
- **Body:** Inter (pipeline descriptions, checkpoint notes)
- **Mono:** JetBrains Mono (technical specs, bitrate, loudness, timecodes)

### 1.3 Atmosphere

- Borderless dark glass shell, cyan-blue neural rim lighting, #FACC15 master-gold accent on final output and validated states
- Massive central viewer dominates 60% of center width, polished cinematic frame with subtle gold inner glow and letterbox-safe guides
- Gold particle burst forms a master seal/symbol when mastering completes
- 8K target ensures mastering preview fidelity at native resolution

---

## 2. LAYOUT ARCHITECTURE

```
+------------------------------------------------------------------+
| LEFT: MASTERING PIPELINE (300px) | CENTER: FINAL-OUTPUT VIEWER (Flex) | RIGHT: TECHNICAL SPECIFICATIONS (340px) |
| Picture Lock -> Color -> Audio   |  Polished cinematic frame         |  Resolution / Aspect / FPS               |
| Subtitle -> QC -> Encoding ->    |  Letterbox + safe area toggles    |  Codec / Bitrate / Audio Channels        |
| Master (7 stages)                |  Gold seal burst on complete      |  Loudness / Color Space / Subs / Quality |
+------------------------------------------------------------------+
| BOTTOM: FINAL OUTPUT TIMELINE (160px) — technical checkpoints with traveling pulse + gold burst on complete                                                     |
+------------------------------------------------------------------+
```

| Panel | Width | Style |
|---|---|---|
| Left: Mastering Pipeline | 300px | Glass, vertical stepper with connectors |
| Center: Final-Output Viewer | Flex | Cinematic frame, gold-accented, canvas particles |
| Right: Technical Specs | 340px | Glass, grouped spec cards with validation dots |
| Bottom: Output Timeline | 160px height | Glass strip, checkpoint pills, traveling pulse, burst on complete |

---

## 3. CENTER — FINAL-OUTPUT VIEWER

### 3.1 Visual

- Polished cinematic frame: 16:9 native, black letterbox bars when content is narrower, gold inner rim glow `0 0 32px rgba(250,204,21,0.12)` plus cyan outer glass border
- Frame header: small mono label "FINAL MASTER PREVIEW" and resolution badge (e.g., 3840x2160) top-left; status dot top-right (gold mastering, green validated)
- Content placeholder: gradient (#0A0E1E to #05050A) with large gold play emblem and scanlines at 4% opacity
- Safe area toggle: 90% and 95% safe frames drawn as dashed lines (cyan 08)
- On mastering complete: burst of 36 gold particles outward from frame center, coalescing into a master seal symbol (geometric star within circle) that holds for 2s then fades to subtle watermark

### 3.2 Interaction

- Click frame to toggle between fit and 1:1 pixel view (zoom)
- Hover reveals control bar: Play, Scrub, Safe Toggle, Fullscreen, Export Master
- Safe toggle cycles Off -> 90% -> 95%
- Fullscreen expands viewer to cover left+right panels with overlay dim

### 3.3 Motion

- Frame entrance: fade + scale 0.98 to 1.0 over 400ms cubic-bezier(0.16,1,0.3,1)
- Gold glow pulses slowly 3.2s during mastering states
- Burst: particles explode outward over 900ms, then converge to seal over 600ms, seal drawn with stroke-dashoffset animation 800ms

---

## 4. LEFT PANEL — MASTERING PIPELINE

### 4.1 Pipeline Stages (7)

| Order | Stage | Description |
|---|---|---|
| 1 | Picture Lock | Edit locked, no further picture changes |
| 2 | Color | Grade and LUT applied, scope validated |
| 3 | Audio | Mix, loudness, channel mapping |
| 4 | Subtitle | Burn-in or sidecar, language coverage |
| 5 | QC | Automated and human validation |
| 6 | Encoding | Transcode to delivery codec and bitrate |
| 7 | Master | Final validated deliverable, seal burst |

### 4.2 Visual

- Glass panel title MASTERING PIPELINE, master-gold 11px Orbitron
- Vertical stepper: each stage is a pill row with numbered circle (gold when active, cyan when pending, green when passed), label, and status icon (dot, check, warning)
- Connectors: vertical line between circles; segment fills gold as stages complete, with traveling pulse dot moving downward on state advance
- Active stage has gold left border (2px) and background `rgba(250,204,21,0.09)`

### 4.3 Interaction

- Click stage to focus viewer on that stage's preview and right-panel spec group
- Hover stage shows tooltip with stage notes and duration
- Run Stage button triggers progress for that stage, advancing pipeline state

---

## 5. RIGHT PANEL — TECHNICAL SPECIFICATIONS

### 5.1 Spec Groups

| Group | Fields |
|---|---|
| Delivery | Resolution (3840x2160), Aspect Ratio (16:9), FPS (24) |
| Encoding | Codec (H.265 / ProRes), Bitrate (80 Mbps), Container (MP4/MOV) |
| Audio | Channels (Stereo / 5.1), Loudness (-14 LUFS), Sample Rate (48kHz) |
| Color | Color Space (Rec.709 / Rec.2020), Bit Depth (10-bit), HDR (Off) |
| Subtitles | Status (Embedded / Sidecar / None), Languages (EN, HI) |
| Quality Validation | Overall score 0-100, per-check dots (Resolution, Audio Sync, Subtitle Sync, Loudness, Color) |

### 5.2 Visual

- Glass panel title TECHNICAL SPECIFICATIONS, gold accent
- Each spec row: mono label 9px dim + value 12px primary + validation dot (gold pending, green pass, amber warn, red fail)
- Quality Validation section has large circular score gauge at top with gold gradient arc, plus mini dots per check below
- Group dividers are subtle 1px `rgba(0,240,255,0.06)`

### 5.3 Interaction

- Click value to edit inline via dropdown or input (resolution presets, codec list, etc.)
- Editing triggers re-validation (QC stage re-enters checking)
- Hover validation dot shows check detail tooltip

---

## 6. BOTTOM — FINAL OUTPUT TIMELINE

### 6.1 Visual

- Horizontal glass strip, 160px height
- Timeline track spans full width, 7 pipeline phases as checkpoint pills equally spaced
- Each pill shows stage number and short label; size scales slightly when active
- Technical checkpoint markers: small gold ticks below track at encoding boundaries (I-frame alignment, bitrate switches)
- Traveling pulse dot moves left-to-right along track as mastering progresses
- On reaching MASTER (100%), burst of gold particles forms master symbol centered above timeline, holds 2.4s

### 6.2 Interaction

- Click checkpoint pill to jump to that pipeline stage (left panel selection syncs)
- Drag playhead scrubs through timeline; viewer updates to show stage-appropriate preview
- Hover checkpoint shows bitrate/loudness overlay for that segment

### 6.3 Motion

- Pulse travel: requestAnimationFrame along horizontal track, eased, 2.8s per full pass during ENCODING
- Checkpoint activation: scale 1.06 over 220ms + glow intensifies
- Burst: 32 particles explode from pulse position, converge to master symbol (star-in-circle) via SVG path animation, shimmer pulse 2s

---

## 7. AI / AUTOMATION STATE MACHINE

```
IDLE -> PICTURE_LOCK -> COLOR_GRADING -> AUDIO_MASTERING -> SUBTITLING -> QC_CHECKING -> ENCODING -> MASTER_VALIDATED -> COMPLETE
```

- Auto-advances every 1.6s in demo; QC_CHECKING holds 2.2s, ENCODING shows incremental progress 0-100%, MASTER_VALIDATED holds 1.8s then COMPLETE burst
- State label and progress bar shown in center header, color maps to gold/cyan/green per stage
- COMPLETE triggers gold seal burst both in center viewer and bottom timeline

---

## 8. PARTICLE SYSTEM

- Canvas particles: 170 count, gold (#FACC15) + cyan (#00F0FF) palette, speed 0.3-0.8
- Idle: ambient gold dust 0.11 opacity
- ENCODING: directed flow along timeline track left-to-right
- COMPLETE: radial burst from center (36 particles) and from timeline pulse (32 particles), converging to seal symbols
- Seal: geometric star within circle drawn with `stroke-dasharray` animation, fill `rgba(250,204,21,0.14)`

---

## 9. TECHNICAL SPECIFICATIONS

| Metric | Target |
|---|---|
| Viewport FPS | 60fps |
| Canvas particles | 170 |
| Viewer frame | 16:9, letterbox-safe, scalable to 8K |
| Pipeline auto-advance | 1.6s per stage |
| Seal burst | 900ms explode + 600ms converge |

### API Integration

```typescript
interface MasteringStudioAPI {
  getPipeline(): MasteringStage[];
  advancePipeline(stageId: string): void;
  getTechnicalSpecs(): TechnicalSpecs;
  updateSpec(key: string, value: string): void;
  exportMaster(): Promise<ExportResult>;
  getMasterStatus(): MasterStatus;
}
```

---

*Specification Version 1.0 — ACOS Creative Operating System*
*Design Standard: 8K, 16:9, Borderless Desktop*
*Color System: Deep Black + Midnight Navy + Cyan-Blue Neural + #FACC15 Master Gold*
