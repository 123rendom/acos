﻿"""Backward compatibility shim forwarding to acos_engine.server.bridge."""
from __future__ import annotations

import sys
import runpy
from pathlib import Path

# Re-export all symbols for modules importing from acos.server.bridge
try:
    from acos_engine.server.bridge import *
    from acos_engine.server.bridge import (
        AcosBridgeServer,
        AcosBridgeRequestHandler,
        run_standalone,
        DEFAULT_PORT,
    )
except ImportError:
    pass

_TARGET = Path(__file__).resolve().parent.parent.parent / "acos_engine" / "server" / "bridge.py"

if __name__ == "__main__":
    runpy.run_path(str(_TARGET), run_name="__main__")
