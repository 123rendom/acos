# ACOS Neural Workspace Interaction System — Design Specification

> **System ID:** SYSTEM-41
> **Version:** 1.0
> **Format:** Universal Interaction Layer (applies to all ACOS studios)
> **Resolution Target:** 8K (7680 × 4320)
> **Design Language:** Dark Glass + Neural Cursor + Spatial Intelligence

---

## 1. INTERACTION PHILOSOPHY

Every object in ACOS possesses:

| Property | Description |
|---|---|
| **POSITION** | Where it exists in space |
| **STATE** | Current status (idle, active, processing, locked) |
| **CONTEXT** | Relationship to other objects |
| **RELATIONSHIP** | Connected objects and dependencies |
| **ACTION** | Available operations |
| **FEEDBACK** | Visual response to interaction |

The user immediately understands:
- What can be selected
- What can be moved
- What can be edited
- What is connected
- What is active
- What is processing
- What is locked
- What will happen next

All interactions produce **immediate visual feedback**.

---

## 2. PRIMARY INPUT METHODS

### 2.1 Mouse

| Action | Button | Modifier |
|---|---|---|
| Select | Left click | — |
| Multi-select | Left click | Ctrl |
| Range select | Left drag | Shift |
| Context menu | Right click | — |
| Pan | Middle drag / Alt+Left | — |
| Orbit | Left drag | — |
| Zoom | Scroll wheel | Ctrl for precise |
| Drop | Left release | — |

### 2.2 Keyboard

| Shortcut | Action |
|---|---|
| `Ctrl+K` | Command Palette |
| `Ctrl+Z` | Undo |
| `Ctrl+Shift+Z` | Redo |
| `Ctrl+S` | Save |
| `Ctrl+F` | Focus Selection |
| `F` | Focus Mode |
| `Space` | Play/Pause |
| `W` | Move Mode |
| `E` | Rotate Mode |
| `R` | Scale Mode |
| `Tab` | Cycle Workspace |
| `Escape` | Deselect / Close |
| `Delete` | Delete |
| `Ctrl+D` | Duplicate |
| `Ctrl+G` | Group |
| `Ctrl+L` | Lock |
| `Ctrl+H` | Hide |
| `Ctrl+Shift+T` | Timeline |
| `Ctrl+Shift+I` | Inspector |
| `Ctrl+Shift+N` | Neural Graph |

### 2.3 Voice

| Command Type | Example |
|---|---|
| Natural language | "Make this darker" |
| Multi-step | "Select Shot 042, open camera, switch to 35mm" |
| Confirmation | "Confirm delete Shot 042" |
| Contextual | "Set keyframe at frame 120" |

### 2.4 Trackpad

| Gesture | Action |
|---|---|
| Pinch | Zoom |
| Two-finger drag | Pan |
| Swipe | Navigation |
| Three-finger swipe | Switch workspace |

All input methods control the **same underlying state**.

---

## 3. NEURAL CURSOR SYSTEM

### 3.1 Cursor States

| State | Visual | Trigger |
|---|---|---|
| Normal | Small cyan intelligence point | Default |
| Hover | Tiny particle attraction effect | Over interactive element |
| Interactive | Soft circular neural ring | Over selectable object |
| Active | Bright selection ring | Object selected |
| Processing | Rotating neural indicator | Object processing |
| Locked | Stable dim ring | Object locked |
| Drag | Energy filament trail | Dragging object |
| Connect | Temporary energy filament | Connecting objects |
| Invalid | Subtle amber rejection field | Invalid drop target |

### 3.2 Cursor Design

```
Normal:     ●  (2px cyan point)
Hover:      ●  + 3 particle attraction
Interactive: ◎  (4px ring, 30% opacity)
Active:     ◎  (6px ring, 100% opacity, glow)
Processing:  ⚙  (rotating 8px ring)
Locked:     ○  (4px ring, 20% opacity, dim)
```

### 3.3 Particle Attraction Effect

When cursor hovers over an interactive object:
- 5-10 tiny particles (`#00F0FF`) emanate from the object toward the cursor
- Particles travel at 2-4 units/sec
- Particles fade at 10px distance from cursor
- Particle size: 0.5-1.5px

---

## 4. OBJECT SELECTION

### 4.1 Single Selection

When selecting any object:
1. Object receives subtle illumination (`+20%` brightness)
2. Surrounding glass interface responds
3. Relevant contextual controls appear
4. Connected neural nodes illuminate
5. Related assets receive a low-intensity pulse

### 4.2 Selection Propagation

```
Select Character →
  Character highlights (cyan)
  → Wardrobe pulses (amber)
  → Voice pulses (amber)
  → Performance pulses (amber)
  → Scene highlights (blue)
  → Camera highlights (blue)
  → Lighting highlights (blue)
  → Continuity node pulses (green)
```

Only **relevant relationships** brighten. Unrelated objects remain unchanged.

### 4.3 Selection Indicators

| Indicator | Color | Meaning |
|---|---|---|
| Primary selection | `#00F0FF` | Directly selected object |
| Related | `#F59E0B` | Connected/dependent object |
| Affected | `#4CCB8A` | Will be affected by change |
| Unrelated | `#1F2937` | Hidden/background |

---

## 5. MULTI-SELECTION

### 5.1 Multi-Select Modes

| Mode | Input | Description |
|---|---|---|
| Additive | `Ctrl+Click` | Add to selection |
| Range | `Shift+Click` | Select range |
| Box | Left drag (empty space) | Rectangle selection |
| Lasso | `Ctrl+Left drag` | Freeform selection |

### 5.2 Multi-Selection Display

```
┌──────────────────────────────┐
│  3 OBJECTS SELECTED          │
│                              │
│  Character_Hero              │
│  Camera_MAIN                 │
│  Lighting_Key                │
│                              │
│  Available Operations:       │
│  Move | Duplicate | Group    │
│  Align | Hide | Lock         │
│  Export | Add to Scene       │
│  Create Variation            │
└──────────────────────────────┘
```

### 5.3 Combined Context Panel

When multiple objects are selected:
- Show **common operations** only
- Show **shared properties**
- Hide **object-specific controls**
- Display count: `3 OBJECTS SELECTED`

---

## 6. SPATIAL DRAG & DROP

### 6.1 Valid Drop Targets

| Source | Valid Destinations |
|---|---|
| Character | Scene, Character Library, Animation, Performance |
| Audio | Timeline, Voice, Audio Library |
| Camera | Shot, Scene, Timeline |
| VFX | Scene, Shot, Timeline |
| Asset | Viewport, Asset Library, 3D Object |
| Research | Story |
| Story | Script |
| Script Scene | Timeline |
| Prompt | Generator |
| Generated Asset | Asset Library |
| Texture | Material Studio, Asset Library, 3D Object |

### 6.2 Drag Visual Feedback

| State | Visual |
|---|---|
| Dragging | Thin neural energy filament follows cursor |
| Valid target | Cyan target field glows |
| Invalid target | Subtle amber rejection field |
| Over valid zone | Magnetic snap guide appears |
| On drop | Particle pulse confirms operation |

### 6.3 Drop Animation

```
1. Particle stream forms between source and destination
2. Energy filament crystallizes at destination
3. Brief green pulse at destination (`#4CCB8A`)
4. Destination object receives subtle illumination
5. Operation confirmed in action history
```

---

## 7. NEURAL CONNECTION CREATION

### 7.1 Connection Flow

1. User starts dragging from a node
2. Temporary energy filament follows cursor
3. Valid targets expand slightly with `#00F0FF` glow
4. On drop, connection crystallizes into permanent neural pathway
5. Relationship label displayed (if useful)

### 7.2 Connection Examples

```
CHARACTER
    ↓
PERFORMANCE

CAMERA
    →
SHOT 042

LIGHTING_KEY
    →
SCENE_MAIN
```

### 7.3 Connection Validation

| Connection | Valid | Reason |
|---|---|---|
| Audio file → Audio Track | ✓ | Compatible types |
| Audio file → 3D topology | ✗ | Incompatible |
| Character → Character Performance | ✓ | Related objects |
| Render output → Render Queue | ✓ | Pipeline flow |
| Script → Timeline | ✓ | Content flow |
| Camera → Character | ✗ | No direct relationship |

When invalid: Display **INCOMPATIBLE CONNECTION** with concise explanation. No aggressive error animation.

---

## 8. PANEL MOVEMENT

### 8.1 Drag Behavior

When dragging a panel header:
- Panel smoothly follows cursor
- Glass shadow increases (`shadow: 0 8px 32px`)
- Depth separation increases (z-index +2)
- Nearby panels subtly move away (`transform: translateX(8px)`)
- Neural connections temporarily stretch
- Magnetic alignment guides appear

### 8.2 Release Behavior

When panel is released:
- Panel gently settles (`transition: transform 300ms ease-out`)
- Magnetic snap if near a valid zone
- Neural connections re-establish
- Panel shadow returns to normal

### 8.3 Panel Zones

| Zone | Position | Behavior |
|---|---|---|
| LEFT | Left edge | Snap to left margin |
| CENTER | Center | Float above viewport |
| RIGHT | Right edge | Snap to right margin |
| TOP | Top edge | Snap above timeline |
| BOTTOM | Bottom edge | Snap below timeline |
| FLOATING | Anywhere | Free position |
| FULLSCREEN | Full viewport | Hide all other panels |

---

## 9. MAGNETIC SPATIAL LAYOUT

### 9.1 Snap Guides

When a panel approaches a valid zone (within 20px):
- Subtle spatial guide appears (`rgba(0, 240, 255, 0.2)`)
- Guide shows panel destination area
- Panel header glows faintly

### 9.2 Snap Behavior

| Action | Response |
|---|---|
| Panel enters zone | Guide appears, panel slows |
| Panel within zone | Magnetic attraction begins |
| Panel at center of zone | Lock animation |
| Panel released | Panel locks in position |
| Panel moved away | Guide disappears, panel follows |

---

## 10. PANEL RESIZE

### 10.1 Resize Handles

Floating panels support resize via edge handles:
- Width: min 200px, max viewport width - 200px
- Height: min 100px, max viewport height - 200px
- Resize from any edge or corner

### 10.2 Panel Operations

| Operation | Shortcut | Effect |
|---|---|---|
| Resize | Edge drag | Change dimensions |
| Maximize | Double-click header | Fill zone |
| Minimize | Click header | Collapse to icon |
| Collapse | Click collapse button | Hide content |
| Pin | Click pin button | Prevent auto-hide |
| Dock | Drag to zone | Snap to edge |
| Detach | Drag away | Float independently |

---

## 11. PANEL DEPTH

Panels exist in a virtual Z-space:

| Layer | Content | Opacity |
|---|---|---|
| Foreground | Active production controls | 100% |
| Middle | Supporting information | 85% |
| Background | System/context information | 60% |

Depth should be **subtle**. Avoid excessive 3D rotation. Professional usability first.

---

## 12. ZOOM SYSTEM

### 12.1 Zoom Targets

| Target | Shortcut | Default |
|---|---|---|
| Viewport | Scroll wheel | 100% |
| Timeline | Scroll wheel | 100% |
| Neural Graph | Scroll wheel | 100% |
| Node Graph | Scroll wheel | 100% |
| Asset Browser | Scroll wheel | 100% |

### 12.2 Zoom Behavior

- Zoom focuses around pointer position
- `Ctrl+Scroll` for precise zoom (±1%)
- Trackpad pinch for zoom
- Keyboard: `Ctrl++` / `Ctrl+-`
- Reset: `Ctrl+0`
- Zoom range: 25% – 400%

---

## 13. 3D VIEWPORT NAVIGATION

| Navigation | Shortcut | Description |
|---|---|---|
| Orbit | Left drag | Rotate around focus |
| Pan | Middle drag | Pan view |
| Zoom | Scroll wheel | Zoom in/out |
| Frame Selected | `F` | Focus on selected |
| Focus Selected | `Ctrl+F` | Zoom to fit selection |
| Reset Camera | `0` | Reset to default |
| Top View | `5` | Top-down orthographic |
| Front View | `1` | Front orthographic |
| Side View | `3` | Side orthographic |
| Perspective | `P` | Perspective view |
| Orthographic | `O` | Orthographic view |

Keyboard shortcuts are configurable.

---

## 14. GIZMO SYSTEM

For 3D objects, provide:

| Mode | Shortcut | Gizmo |
|---|---|---|
| Move | `W` | Translation arrows |
| Rotate | `E` | Rotation circles |
| Scale | `R` | Scale handles |

### 14.1 Gizmo Appearance

```
Move Gizmo:
  X (red) ──── Y (green) ──── Z (blue)
  with subtle neural illumination at each axis tip

Rotate Gizmo:
  Three concentric circles (XY, YZ, XZ)

Scale Gizmo:
  Cube with axis-aligned handles
```

When active:
- Display X, Y, Z labels with subtle neural illumination
- Numeric values editable directly in gizmo
- Values update in real-time during drag

---

## 15. CINEMATIC CAMERA INTERACTION

Camera objects behave like physical virtual-production cameras.

### 15.1 Camera Controls

| Action | Method |
|---|---|
| Drag camera | Left drag on camera icon |
| Rotate camera | Right drag |
| Change focal length | Scroll wheel or slider |
| Change focus target | Click target point |
| Change camera height | Vertical drag |
| Change distance | Scroll / drag toward/away |
| Change movement path | Edit trajectory |

### 15.2 Camera Visualization

- Camera frustum (wireframe pyramid)
- Lens cone
- Focus plane
- Trajectory path
- Safe area (frame boundaries)
- When camera moves: trajectory updates in real-time

---

## 16. TIMELINE INTERACTION

### 16.1 Timeline Operations

| Operation | Shortcut | Method |
|---|---|---|
| Drag clips | Left drag | Move clip position |
| Trim | Edge drag | Adjust clip start/end |
| Split | `Ctrl+B` | Cut clip at playhead |
| Duplicate | `Ctrl+D` | Copy clip |
| Move | Left drag | Reposition |
| Snap | Toggle | Align to markers |
| Slip | `Alt+drag` | Move content within clip |
| Ripple | `Ctrl+Shift+drag` | Shift subsequent clips |
| Lock | `L` | Prevent editing |
| Mute | `M` | Silence audio |
| Solo | `S` | Isolate track |
| Group | `Ctrl+G` | Group clips |

### 16.2 Neural Activity

Timeline neural activity remains **subtle**. The timeline is a professional editing tool, not a decorative animation. Neural particles appear only during AI-assisted operations.

---

## 17. KEYFRAME INTERACTION

### 17.1 Keyframe Creation

| Method | Action |
|---|---|
| Manual button | Click add keyframe |
| Parameter change | Auto-create on value change |
| Keyboard shortcut | `K` at current frame |
| Voice command | "Set camera zoom to 50mm at frame 120" |

### 17.2 Voice Keyframe Workflow

```
User: "Set camera zoom to 50mm at frame 120."
ACOS: UNDERSTAND → CAMERA → FOCAL LENGTH → FRAME 120 → APPLY
Result: Keyframe appears with small neural pulse
```

### 17.3 Keyframe Visualization

- Keyframe marker on timeline
- Small neural pulse on creation
- Connected by interpolation curve
- Tangent handles editable

---

## 18. VOICE + SPATIAL INTERACTION

### 18.1 Contextual Voice Commands

| User Command | Context | Action |
|---|---|---|
| "Make this darker" | Lighting selected | Reduce lighting intensity |
| "Make this darker" | Color selected | Reduce exposure / lift |
| "Make this darker" | Environment selected | Suggest atmospheric adjustment |
| "Increase" | Volume selected | Increase volume |
| "Increase" | Brightness selected | Increase brightness |

### 18.2 Ambiguity Resolution

When ambiguity exists, ACOS asks a short clarification:

```
**"Do you mean lighting or color?"**
[ Lighting ] [ Color ] [ Environment ]
```

---

## 19. NATURAL MULTI-STEP COMMANDS

### 19.1 Command Decomposition

User: `"Select Shot 042, open camera controls, switch to 35mm and preview it."`

Execution visualization:
```
VOICE
    ↓
INTENT
    ↓
SHOT 042
    ↓
CAMERA
    ↓
35MM
    ↓
PREVIEW
```

Each completed action produces a **small confirmation pulse**.

### 19.2 Command Status Display

```
┌──────────────────────────────────┐
│  COMMAND EXECUTING              │
│                                  │
│  ✓ Select Shot 042              │
│  ✓ Open Camera Controls         │
│  ○ Switch to 35mm               │
│  ○ Preview                      │
│                                  │
│  Progress: 50%                  │
└──────────────────────────────────┘
```

---

## 20. COMMAND PALETTE

### 20.1 Universal Command Palette

- Shortcut: `Ctrl+K`
- Floating panel with search input
- Results are **context-ranked**

### 20.2 Search Categories

| Category | Icon | Examples |
|---|---|---|
| Actions | ⚡ | Save, Render, Export |
| Studios | 🎬 | Open 3D Modeling, Open Material |
| Assets | 📦 | Find Character, Find Asset |
| Characters | 👤 | Create Character |
| Scenes | 🏛️ | Create Scene, Duplicate Scene |
| Shots | 🎥 | Create Shot, Compare Shots |
| Agents | 🤖 | Run AI Agent |
| Commands | ⌨️ | Undo, Redo, Focus |
| Settings | ⚙️ | Open Settings |

### 20.3 Command Examples

```
"Create shot"
"Find character"
"Open render queue"
"Show continuity problems"
"Compare Shot 041 and Shot 042"
"Generate camera variations"
"Set keyframe at frame 120"
"Render current scene"
"Export as MP4"
"Toggle timeline"
```

---

## 21. CONTEXT MENU

### 21.1 Intelligent Right-Click

| Object | Context Menu Actions |
|---|---|
| Character | Open, Edit DNA, Change Wardrobe, Generate Variation, Add to Scene, Check Continuity, Find Related Shots |
| Camera | Edit Camera, Change Lens, Generate Alternative, Save Shot, Check Continuity, Add Keyframe |
| Scene | Open, Duplicate, Export, Check Continuity, Render, Delete |
| Shot | Open, Edit, Add Keyframe, Check Continuity, Compare, Delete |
| Asset | Open, Edit, Duplicate, Export, Delete, Add to Scene |
| Timeline Clip | Cut, Copy, Paste, Trim, Split, Duplicate, Lock, Mute |

The menu contains **relevant actions only** — no giant universal list.

---

## 22. UNDO / REDO

### 22.1 Action History

Every meaningful interaction is reversible:
- `Ctrl+Z` — Undo
- `Ctrl+Shift+Z` — Redo

### 22.2 Visual Action History

Recent actions represented as a neural activity stream:

```
13:42:08  CAMERA     50mm → 35mm
13:42:14  LIGHTING   Intensity +12%
13:42:22  CHARACTER  Wardrobe Variant B
13:42:30  RENDER     Shot 042 queued
```

The stream is **collapsible**.

### 22.3 Undo Granularity

| Operation | Undo Level |
|---|---|
| Parameter change | Individual parameter |
| Object creation | Full object |
| Scene modification | Full scene state |
| AI generation | Full generation |
| Timeline edit | Individual clip |

---

## 23. HOVER INTELLIGENCE

Hovering displays:

| Field | Description |
|---|---|
| Name | Object name |
| Type | Object type |
| Status | Current status (READY, PROCESSING, ERROR) |
| Owner Agent | AI agent responsible |
| Current Version | Version number |
| Continuity | Continuity percentage |
| Dependencies | Connected objects |

### 23.1 Hover Tooltip Example

```
SHOT 042

Status: READY
Camera: CAM-A
Character: ARJUN
Continuity: 98.4%
Render: NOT STARTED
```

Tooltips must be **fast and unobtrusive** (appear in 100ms, disappear in 200ms).

---

## 24. LOADING / PROCESSING INTERACTION

### 24.1 Non-Blocking Operations

During AI operations:
- Active object continues responding
- Display `GENERATING 72%`
- Allow: Pause, Cancel, Background, View Details

### 24.2 Particle Progress Representation

- Particles represent actual task progress
- Particle count increases with progress
- Color matches current AI agent state
- Complete: particles stabilize into result

### 24.3 Operation Controls

```
[ GENERATING ] 72%
[ Pause ] [ Cancel ] [ Background ] [ Details ]
```

---

## 25. FILE INTERACTION

### 25.1 File Drop

Dragging a file into ACOS triggers:
1. **FILE DETECTED** notification
2. Automatic type/format/metadata detection
3. Possible destination identification
4. Compatibility check

### 25.2 File Type Handling

| File Type | Detection | Actions |
|---|---|---|
| MP4 | VIDEO ASSET DETECTED | Add to Timeline, Add to Asset Library, Analyze, Extract Audio, Create Proxy |
| PNG/JPG | IMAGE ASSET DETECTED | Add to Asset Library, Create Material, Use as Reference |
| WAV/MP3 | AUDIO ASSET DETECTED | Add to Timeline, Voice, Audio Library |
| FBX/OBJ | 3D MODEL DETECTED | Add to Scene, Import to Asset Library |
| PNG Sequence | IMAGE SEQUENCE DETECTED | Add to Timeline, Create Animation |

---

## 26. INTELLIGENT DROP ZONES

When dragging, only compatible destinations illuminate:

| Source | Highlighted Zones |
|---|---|
| Character asset | Scene, Character Library, Animation, Performance |
| Audio | Timeline, Voice, Audio Library |
| Texture | Material Studio, Asset Library, 3D Object |
| Script | Timeline, Story |
| Camera | Shot, Scene, Timeline |
| Prompt | Generator |
| Render | Render Queue, Export |

This makes complex workflows **understandable**.

---

## 27. NEURAL FEEDBACK LANGUAGE

| Action | Visual Language |
|---|---|
| SELECT | Ring pulse |
| MOVE | Energy trail |
| CONNECT | Filament |
| GENERATE | Particle stream |
| PROCESS | Accelerated neural activity |
| COMPLETE | Stable pulse |
| WARNING | Amber pulse |
| ERROR | Localized red disruption |
| CANCEL | Particles dissipate |
| DELETE | Controlled particle collapse |

---

## 28. DESTRUCTIVE ACTIONS

For destructive operations, require confirmation:

| Operation | Confirmation Required |
|---|---|
| Delete | Yes |
| Overwrite | Yes (unless auto-saved) |
| Replace | Yes |
| Remove Asset | Yes |
| Clear Timeline | Yes |
| Delete Project | Yes |

### 28.1 Contextual Confirmation

```
**DELETE SHOT 042?**

This will remove:
• Camera
• Animation
• VFX
• Audio references

[ CANCEL ] [ DELETE ]
```

---

## 29. KEYBOARD-FIRST WORKFLOW

Professional users operate ACOS rapidly without constant mouse use:

| Category | Shortcuts |
|---|---|
| Create | `Ctrl+N` (New), `Ctrl+Shift+S` (Scene) |
| Save | `Ctrl+S` |
| Render | `Ctrl+Enter` |
| Play | `Space` |
| Split | `Ctrl+B` |
| Search | `Ctrl+K` |
| Toggle Panels | `Ctrl+Shift+T/I/N` |
| Focus | `Ctrl+F` |
| Fullscreen | `Ctrl+Shift+F` |

---

## 30. ACCESSIBILITY / REDUCED MOTION

### 30.1 Accessibility Modes

| Mode | Effect |
|---|---|
| Reduced Motion | Replace transitions with fast opacity/position |
| Reduced Glow | Disable neural glow effects |
| Reduced Particles | Reduce particle count by 80% |
| High Contrast | Increase contrast ratios |
| Larger Text | Scale text 125%/150%/200% |
| Keyboard Navigation | Full keyboard support |
| Voice Navigation | Navigate via voice commands |

### 30.2 Reduced Motion Behavior

When enabled:
- Replace elaborate transitions with fast opacity/position transitions (50-100ms)
- Do NOT disable functionality
- Maintain all interaction capabilities

---

## 31. PERFORMANCE ARCHITECTURE

Interaction must remain responsive with:
- Large projects
- Thousands of assets
- Large neural graphs
- Long timelines
- Many agents
- Multiple background tasks
- High-density particles

### 31.1 Performance Techniques

| Technique | Purpose |
|---|---|
| GPU-accelerated rendering | Smooth viewport |
| Virtualized lists | Fast asset browsing |
| Lazy-loaded panels | Fast startup |
| Event-driven state updates | Efficient re-renders |
| Incremental rendering | Partial updates |
| Worker threads | Background computation |
| Efficient graph rendering | Fast neural graph |
| Debounced high-frequency events | Prevent jank |
| Background processing | Non-blocking UI |

Never rebuild the entire application for a small UI change.

---

## 32. INPUT CONFLICT PREVENTION

| Focus Context | Ctrl+Z Behavior |
|---|---|
| Text editor | Undo text editing |
| Viewport | Undo scene state |
| Timeline | Undo timeline edit |
| Command Palette | Cancel palette |
| Voice Control | Cancel voice command |

Keyboard shortcuts must respect focused input fields.

---

## 33. INTERACTION CONSISTENCY

| Action | Behavior |
|---|---|
| Double-click | Asset → open, Shot → open, Character → open, Agent → inspect |
| Single-click | Select |
| Right-click | Context actions |
| Drag | Move / assign / connect depending on object type |

The same action behaves **consistently** throughout ACOS.

---

## 34. MICRO-ANIMATION RULES

| Duration | Purpose |
|---|---|
| 80–160ms | Micro interaction (button press, toggle) |
| 160–300ms | Panel transition (slide, expand, collapse) |
| 300–600ms | Workspace transition (panel move, zone snap) |
| 600ms+ | Major cinematic transition only |

The application should feel **fast**. No unnecessary delays.

---

## 35. SPATIAL FOCUS MODE

Press `FOCUS` to minimize distractions:

**Visible:**
- Selected object
- Relevant controls
- Essential timeline
- AI assistant

**Hidden:**
- All other panels
- Navigation
- Telemetry
- Secondary information

Everything else becomes **background glass**.

Press `FOCUS` again to restore workspace.

---

## 36. CINEMATIC PRESENTATION MODE

Hide:
- Navigation
- Telemetry
- Debug information
- Secondary panels

Keep:
- Cinematic viewport
- Minimal controls
- Shot information

Useful for **reviewing finished scenes**.

---

## 37. AI ASSISTED MANIPULATION

### 37.1 Camera Arrangement

User: `"Arrange these three cameras for wide, medium and close-up coverage."`

ACOS automatically creates:
```
CAM A — WIDE
CAM B — MEDIUM  
CAM C — CLOSE
```
and visually places them around the scene.

### 37.2 Lighting Setup

User: `"Create a three-point lighting setup."`

ACOS creates:
```
KEY
FILL
RIM
```
and positions them intelligently.

---

## 38. FINAL INTERACTION EXPERIENCE

The completed ACOS interaction system should feel like:

**Photoshop-level creative control**
+ **Blender-level 3D interaction**
+ **Premiere/Resolve-level timeline interaction**
+ **AI natural-language control**
+ **Neural spatial interface**

The guiding principle:

> **The UI should disappear when the user is creating and become visible when the user needs control.**

ACOS must remain:

FAST · PRECISE · PREDICTABLE · REVERSIBLE · CONTEXT-AWARE · PROFESSIONAL · CINEMATIC · FUNCTIONAL

No fake interactions. No decorative controls. No dead buttons. No invisible functionality. No unnecessary 3D gimmicks. No excessive animations. No forced AI automation. No human avatar. No humanoid interface.

---

*Specification Version 1.0 — ACOS Creative Operating System*
*Interaction Design Standard: 8K, 16:9, Borderless Desktop*
*Core Principle: Functionality First, Visual Intelligence Second*
