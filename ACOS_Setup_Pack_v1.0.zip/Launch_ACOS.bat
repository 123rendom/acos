@echo off
title ACOS — Autonomous Creative Operating System (Enterprise)
color 0b

echo =========================================================================
echo    ACOS - Autonomous Creative Operating System (v0.1.0 Enterprise)
echo    Offline-First Neural Studio ^| 48 In-Process Engines ^| 24 Agent Swarm
echo =========================================================================
echo.

cd /d "%~dp0"

echo [*] Checking Python Virtual Environment (.venv)...
if not exist ".venv\Scripts\python.exe" (
    echo [!] Virtual environment not found. Please create .venv with Python 3.12.
    pause
    exit /b 1
)

echo [*] Probing Local Inference Providers (LM Studio / Ollama)...
curl -s http://127.0.0.1:1234/v1/models >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] LM Studio detected on 127.0.0.1:1234
) else (
    echo [INFO] LM Studio not active on port 1234 (Falling back to Ollama / local neural ONNX)
)

echo [*] Starting ACOS Local Bridge Server on http://127.0.0.1:8980...
start /b "" ".venv\Scripts\python.exe" -m acos.server.bridge

timeout /t 2 /nobreak >nul

echo [*] Launching ACOS Desktop Web Application...
start http://127.0.0.1:8980

echo.
echo =========================================================================
echo    ACOS Studio is LIVE and running on http://127.0.0.1:8980
echo    Press Ctrl+C in this terminal window to stop the system.
echo =========================================================================
echo.

pause