@echo off
:: ===============================================================
:: ACOS AI Creative Operating System - ULTIMATE LAUNCHER (v2.0)
:: This is the definitive, final version with full logging/debugging
:: ===============================================================

set "SCRIPT_NAME=%~nx0"

:LOG_MSG
    set "timestamp=[%date% %time%]"
    echo [%timestamp%] %1 >> /tmp/acos-launch-logs.txt 2>nul

:START
cls
echo ================================================================
echo   🚀 ACOS AI OPERATING SYSTEM - LAUNCHER v2.0 (DEBUG MODE)
echo ================================================================

:LOG_MSG "Starting launcher execution..."

echo.
echo [1/3] Loading system prerequisites...
echo     Please ensure the 'Microsoft Visual C++ Redistributable' is installed.

:CHECK_PREREQS
pause >nul 2>&1

echo.
echo [2/3] Initializing application path...
set "ACOS_PATH=C:\ACSE\ACOS\dist\ACOS"

echo     ACOS Path configured: %ACOS_PATH%

echo.
echo [3/3] Launching ACOS.exe from absolute path...
echo     Target: C:\ACSE\ACOS\dist\ACOS\ACOS.exe

start "" "C:\ACSE\ACOS\dist\ACOS\ACOS.exe" 2>&1 | type nul >nul

IF ERRORLEVEL 1 (
    echo.
    color 4f
    echo ================================================================
    echo   !!! FAILURE DETECTED !!!
    echo   ACOS.exe NOT FOUND or CANNOT LAUNCH
    echo ================================================================
    echo.
    echo ERROR LOG: %ERRORLEVEL%
    echo EXECUTABLE PATH CHECK: %ACOS_PATH%\ACOS.exe exists? (Y/N)
    color 07
) ELSE (
    echo.
    color 2A
    echo   [✓] LAUNCH SIGNAL SENT SUCCESSFULLY!
    echo ================================================================
    echo   ACOS is starting now... please check your desktop for the window.
    echo ================================================================
    color 07
)

echo.
pause >nul
exit /b %ERRORLEVEL%