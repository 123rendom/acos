# ACOS 3D Modeling Studio — Design Specification

> **Studio ID:** STUDIO-31
> **Version:** 1.0
> **Format:** Borderless 16:9 Desktop Application
> **Resolution Target:** 8K (7680 × 4320)
> **Design Language:** Dark Glass + Neural Illumination

---

## 1. VISUAL IDENTITY

### 1.1 Color Palette

| Role | Token | Value |
|---|---|---|
| Deep Black Base | `--studio-bg-deep` | `#05050A` |
| Midnight Navy | `--studio-bg-midnight` | `#0A0E1A` |
| Surface Glass | `--studio-glass-bg` | `rgba(10, 14, 30, 0.72)` |
| Glass Border | `--studio-glass-border` | `rgba(0, 240, 255, 0.08)` |
| Cyan Neural | `--studio-neural-cyan` | `#00F0FF` |
| Blue Neural | `--studio-neural-blue` | `#3B82F6` |
| Violet Energy | `--studio-energy-violet` | `#A855F7` |
| Accent Primary | `--studio-accent` | `#00E5CC` |
| Wireframe | `--studio-wireframe` | `rgba(0, 240, 255, 0.6)` |
| Vertex | `--studio-vertex` | `#FF6B6B` |
| Edge | `--studio-edge` | `#4ECDC4` |
| Face | `--studio-face` | `rgba(59, 130, 246, 0.4)` |
| Surface Text | `--studio-text` | `#F0F9FF` |
| Secondary Text | `--studio-text-dim` | `#64748B` |

### 1.2 Typography

- **Display:** Orbitron (headings, labels)
- **Body:** Inter (data, descriptions)
- **Mono:** JetBrains Mono (polygon stats, coordinates)

### 1.3 Atmosphere

- Deep black background with subtle radial gradient (#0A0F1E → #05050A)
- Cyan-blue neural rim lighting on glass panels
- Violet processing energy pulses in the viewport periphery
- Floating particle dust at 0.3 opacity in the background

---

## 2. LAYOUT ARCHITECTURE

### 2.1 Full Desktop Layout (16:9)

```
+------------------------------------------------------------------+
|  APPLICATION BAR (ACOS Shell)                                     |
+------------------------------------------------------------------+
|                              |                                    |
|  LEFT: ASSET CREATION        |  CENTER: 3D VIEWPORT               |
|  CREATION LIBRARY            |  REAL-TIME CINEMATIC VIEW          |
|                              |                                    |
|  • Characters                |  [Main Viewport Canvas]            |
|  • Architecture              |                                    |
|  • Vehicles                  |  Viewport Controls (Overlay)       |
|  • Props                     |  - Wireframe Toggle                |
|  • Nature                    |  - Subdivision Level               |
|  • Furniture                 |  - Material Preview                |
|  • Weapons                   |  - Grid / Safe Frame               |
|  • Mechanical Objects        |                                    |
|  • Custom Models             |                                    |
|                              |                                    |
|  Glass Panels with           |                                    |
|  cyan-blue borders           |                                    |
|                              |                                    |
+------------------------------|------------------------------------+
|                              |  RIGHT: MODELING INTELLIGENCE      |
|  BOTTOM:                     |  MODELING PANEL                    |
|  OPERATION TIMELINE          |                                    |
|  & OBJECT HIERARCHY          |  • Geometry Panel                  |
|                              |  • Topology Panel                  |
|  Timeline with keyframes     |  • Sculpt Panel                    |
|  Hierarchy tree with         |  • Retopology Panel                |
|  drag-and-drop             |  • UV Panel                        |
|                              |  • Materials Panel                 |
|                              |  • Symmetry Panel                  |
|                              |  • Modifiers Panel                 |
|                              |  • Detail Level Panel              |
|                              |  • Optimization Panel              |
+------------------------------------------------------------------+
|  STATUS BAR                                                       |
+------------------------------------------------------------------+
```

### 2.2 Panel Specifications

| Panel | Width | Style |
|---|---|---|
| Left: Asset Library | 320px | Glass, scrollable, categorised |
| Center: Viewport | Flex (remaining) | Full canvas, borderless |
| Right: Intelligence | 340px | Glass, collapsible sections |
| Bottom: Timeline | 200px height | Glass strip with hierarchy |

---

## 3. CENTER VIEWPORT

### 3.1 Viewport Features

- **Real-time rendering** with physically-based materials
- **Cinematic lighting** with HDR environment map
- **Multi-representations:**
  - Solid shaded (default)
  - Wireframe overlay
  - Vertex/edge/face overlay toggle
  - X-Ray transparency mode
  - Material Preview (PBR only)
  - Normals visualization
  - UV Layout overlay

### 3.2 Viewport Overlays

| Overlay | Color | Opacity |
|---|---|---|
| Wireframe | `#00F0FF` | 60% |
| Vertices | `#FF6B6B` | 80% |
| Edges | `#4ECDC4` | 60% |
| Faces (flat) | `rgba(59, 130, 246, 0.25)` | 25% |
| Grid | `rgba(0, 240, 255, 0.1)` | 10% |
| Safe Frame | `rgba(255, 255, 255, 0.15)` | 15% |

### 3.3 Viewport Camera

- Orbit: Left-drag
- Pan: Middle-drag or Alt-drag
- Zoom: Scroll wheel
- Focus: Double-click object
- Frame: Auto-fit selected

---

## 4. LEFT PANEL — ASSET CREATION LIBRARY

### 4.1 Categories

| Category | Icon | Description |
|---|---|---|
| Characters | Humanoid silhouette | Pre-built characters with rigs |
| Architecture | Building outline | Buildings, interiors, structural elements |
| Vehicles | Car/Aircraft silhouette | Cars, ships, aircraft, spacecraft |
| Props | Box icon | Handheld objects, tools, containers |
| Nature | Leaf/tree | Trees, rocks, flora, terrain |
| Furniture | Chair icon | Chairs, tables, decorative items |
| Weapons | Blade icon | Melee, ranged, futuristic arms |
| Mechanical | Gear icon | Engines, devices, mechanical assemblies |
| Custom Models | User icon | User-imported or AI-generated models |

### 4.2 Asset Card Style

- Glass background (`rgba(10, 14, 30, 0.72)`)
- Cyan-blue border on hover (`rgba(0, 240, 255, 0.3)`)
- Thumbnail preview (rendered in viewport)
- Category badge with color coding
- AI-generated indicator (neural pulse dot)

### 4.3 Search & Filter

- Search bar with `#00F0FF` focus glow
- Category filter chips
- Sort by: Name, Date, Type, Complexity
- Drag-to-viewport for placement

---

## 5. RIGHT PANEL — MODELING INTELLIGENCE

### 5.1 Section: Geometry

- Vertex count (real-time)
- Edge count
- Face count (triangles, quads, N-gons)
- Bounding box dimensions
- Surface area
- Volume estimate

### 5.2 Section: Topology

- Polygon density map (heat overlay)
- Triangle quality score
- Edge flow visualization toggle
- N-gon count and warnings
- Non-manifold geometry warnings
- Mesh validity status

### 5.3 Section: Sculpt

- Resolution level slider
- Brush size / strength / falloff
- Draw / Smooth / Flatten / Crease modes
- Symmetry axis toggle
- Mirror editing
- Layer stack

### 5.4 Section: Retopology

- Auto-retopology button
- Target polygon count
- Quad-dominant toggle
- Edge loop detection
- Retopology quality indicator
- Manual guide curve overlay

### 5.5 Section: UV

- UV layout preview
- Seam editing mode
- Atlas efficiency percentage
- Overlap detection
- Resolution preview
- Channel assignment

### 5.6 Section: Materials

- PBR channel stack:
  - Base Color (Albedo)
  - Roughness
  - Metallic
  - Normal
  - Height (Displacement)
  - Ambient Occlusion
  - Emission
  - Coat / Coat Roughness
- Material presets library
- Live preview on viewport object

### 5.7 Section: Symmetry

- Axis: X / Y / Z
- Mirror mode toggle
- Merge threshold
- Symmetry validation
- Asymmetry heatmap

### 5.8 Section: Modifiers

- Modifier stack (list)
- Add: Subdivision, Mirror, Bevel, Boolean, Decimate, Solidify
- Enable/disable per modifier
- Modifier order drag-reorder
- Apply / Reset / Remove

### 5.9 Section: Detail Level

- LOD0: Full resolution
- LOD1: 50%
- LOD2: 25%
- LOD3: 10%
- Auto-LOD toggle
- Screen-space error metric

### 5.10 Section: Optimization

- Decimate ratio slider
- Mesh simplification algorithm choice (Quadric Edge Collapse, Planar)
- Memory footprint
- Draw call estimate
- GPU VRAM usage
- Optimization score (0-100)

---

## 6. BOTTOM PANEL — OPERATION TIMELINE & OBJECT HIERARCHY

### 6.1 Object Hierarchy Tree

```
Scene Root
├── Character_Hero
│   ├── Body_Mesh
│   ├── Eyes_Mesh
│   ├── Clothing_Geometry
│   └── Rig_Hierarchy
├── Environment_Building_01
│   ├── Foundation
│   ├── Walls
│   ├── Roof
│   └── Windows
├── Vehicle_Car_01
│   ├── Chassis
│   ├── Wheels[4]
│   ├── Body
│   └── Headlights
└── Light_Directional_01
    └── Shadow_Map
```

- Color-coded by type (mesh = cyan, light = gold, camera = green)
- Selection highlighting with `#00F0FF` glow
- Drag to reorder
- Collapse/expand groups

### 6.2 Modeling Operation Timeline

- Horizontal timeline with keyframe markers
- Operation markers:
  - CREATE (green pulse)
  - MODIFY (blue pulse)
  - RETOPOLOGIZE (violet pulse)
  - TEXTURE (cyan pulse)
  - OPTIMIZE (amber pulse)
- Scrub bar for navigation
- Zoom to time range
- Undo/Redo markers

---

## 7. AI MODELING AGENT STATES

### 7.1 State Machine

```
ANALYZING → BLOCKING → GENERATING → REFINING → RETOPOLOGIZING → TEXTURING → OPTIMIZING → VERIFIED
```

### 7.2 State Visualizations

| State | Color | Animation | Description |
|---|---|---|---|
| ANALYZING | `#64748B` | Slow pulse, scanning ring | AI examines target geometry |
| BLOCKING | `#F59E0B` | Amber block indicators | AI establishes base blocking mesh |
| GENERATING | `#00F0FF` | Fast neural particle burst | AI generates geometry |
| REFINING | `#A855F7` | Violet smoothing waves | AI refines surface detail |
| RETOPOLOGIZING | `#3B82F6` | Blue edge-flow animation | AI rebuilds topology |
| TEXTURING | `#4CCB8A` | Green color-flow across surface | AI applies materials |
| OPTIMIZING | `#FFD700` | Gold optimization sparks | AI reduces polygon count |
| VERIFIED | `#10B981` | Steady green, check pulse | AI validates final output |

### 7.3 AI Agent Panel

```
+------------------------------------------+
|  🤖 AI MODELING AGENT                     |
+------------------------------------------+
|  Current State: GENERATING                |
|  Progress: 47%                            |
|  Target: Character_Hero_Body              |
|  Confidence: 94%                          |
|  Model: ACOS-NeuralMesh v3.2              |
|                                         |
|  [Cancel] [Pause] [Step Forward]          |
+------------------------------------------+
```

---

## 8. PARTICLE CRYSTALLIZATION ANIMATION

### 8.1 AI-Generated Geometry Visualization

When the AI generates geometry, the viewport displays:

1. **Particle Phase (0-30%):**
   - Millions of tiny glowing particles (`#00F0FF`)
   - Particles converge toward formation bounds
   - Random movement with gentle attraction forces
   - Particle density increases over time

2. **Crystallization Phase (30-70%):**
   - Particles begin snapping to lattice positions
   - Crystal facets form with `#4ECDC4` edge highlights
   - Violet energy (`#A855F7`) pulses between forming vertices
   - Surface tension visual effects

3. **Solidification Phase (70-100%):**
   - Particles merge into solid mesh faces
   - `#3B82F6` face shading fills in
   - Wireframe overlay appears
   - Material preview gradually fades in

4. **Completion:**
   - Single cyan pulse wave across the mesh
   - Particle count stabilizes at mesh vertex count
   - `VERIFIED` state activates

### 8.2 Particle Parameters

| Parameter | Value |
|---|---|
| Particle Count | 2,000,000 – 10,000,000 |
| Particle Size | 0.5 – 2.0 px |
| Particle Color | `#00F0FF` → `#4ECDC4` → `#3B82F6` |
| Convergence Speed | 0.8 – 2.5 units/sec |
| Crystal Snap Threshold | 0.15 units |
| Animation Duration | 3 – 8 seconds |
| Glow Radius | 3 – 8 px |

---

## 9. WIREFRAME-TO-MATERIAL TRANSITION

### 9.1 Transition Modes

| Mode | Description | Duration |
|---|---|---|
| Solid → Wireframe | Fills dissolve into edges | 0.5s |
| Wireframe → Solid | Edges inflate to filled faces | 0.5s |
| Wireframe → Material | Edges dissolve, PBR material fades in | 0.8s |
| Material → Wireframe | Faces dissolve, edges emerge | 0.8s |
| X-Ray | Full transparency with edge emphasis | 0.3s |

### 9.2 Transition Controls

- Toggle button in viewport overlay
- Keyboard shortcut: `W` (wireframe), `X` (x-ray), `F` (solid)
- Smooth interpolation with easing curves

---

## 10. POLYGON STATISTICS & OPTIMIZATION INDICATORS

### 10.1 Statistics Overlay

```
┌─────────────────────────┐
│  VERTICES:  1,247,832    │
│  EDGES:     3,891,405    │
│  FACES:     2,643,573    │
│  TRIS:      5,287,146    │
├─────────────────────────┤
│  MEMORY:    240 MB VRAM  │
│  DRAW CALLS: 847         │
│  DENSITY:   0.89 px/tri  │
│  QUALITY:   96%          │
├─────────────────────────┤
│  OPTIMIZATION:  ━━━━━━━━  78%  │
└─────────────────────────┘
```

### 10.2 Optimization Indicators

- **Density Map:** Color heat overlay (red = dense, blue = sparse)
- **Quality Score:** 0-100% ring gauge
- **VRAM Meter:** Bar filling from left to right
- **Draw Call Counter:** Real-time update
- **Triangle Budget:** Progress bar against target

---

## 11. INTERACTION PATTERNS

### 11.1 Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `W` | Toggle wireframe |
| `X` | Toggle x-ray |
| `F` | Toggle solid |
| `V` | Toggle vertex overlay |
| `E` | Toggle edge overlay |
| `G` | Toggle grid |
| `Tab` | Cycle viewport modes |
| `Ctrl+Z` | Undo |
| `Ctrl+Shift+Z` | Redo |
| `Space` | Play/pause animation |
| `S` | Save snapshot |
| `R` | Render viewport to image |
| `Ctrl+D` | Duplicate selected |
| `Delete` | Delete selected |

### 11.2 Mouse Interactions

| Action | Button |
|---|---|
| Orbit | Left drag |
| Pan | Middle drag / Alt+Left |
| Zoom | Scroll wheel |
| Select | Left click |
| Box select | Shift+Left drag |
| Lasso select | Ctrl+Left drag |
| Move | `G` + drag |
| Scale | `S` + drag |
| Rotate | `R` + drag |
| Extrude | `E` + drag |
| Bevel | `Ctrl+B` + drag |

---

## 12. MOTION & ANIMATION

### 12.1 Panel Transitions

- Left panel slide-in/out: 300ms ease-out
- Right panel collapse/expand: 250ms ease-in-out
- Bottom timeline expand/collapse: 200ms linear
- Hover state transitions: 150ms ease

### 12.2 Neural Particle Activity

- Background particle density varies with AI activity level
- When AI is active, particles flow toward the viewport
- Particle color matches current AI agent state color
- Idle state: ambient particles at 15% opacity
- Active state: directed particle streams at 60% opacity

### 12.3 Button & Control Feedback

- All controls have 100ms press animation
- Panel sections expand with 200ms staggered delay
- AI state changes trigger 400ms color transition
- Notification toasts slide in from bottom-right (300ms)

---

## 13. LIGHTING & ATMOSPHERE

### 13.1 Viewport Lighting

- **Key Light:** Cinematic HDRI environment (studio setup)
- **Fill Light:** Soft cyan-blue rim from viewport edges
- **Ambient:** Low, matching `#0A0E1A` background
- **Model-specific:** Per-object PBR with real-time GI approximation

### 13.2 Glass Panel Lighting

- All panels have `rgba(0, 240, 255, 0.08)` border glow
- Panel interiors have subtle `rgba(15, 25, 45, 0.85)` background
- Panel headers have `rgba(0, 240, 255, 0.1)` bottom border
- Active panel sections have stronger glow (`rgba(0, 240, 255, 0.2)`)

---

## 14. DESIGN SYSTEM COMPONENTS

### 14.1 Panel Structure

```jsx
<StudioPanel
  title="Geometry"
  icon="geometry"
  color="#00F0FF"
  collapsible={true}
  defaultExpanded={true}
>
  <PanelContent />
</StudioPanel>
```

### 14.2 Button Styles

| Type | Background | Border | Text |
|---|---|---|---|
| Primary | `rgba(0, 240, 255, 0.15)` | `#00F0FF` | `#F0F9FF` |
| Secondary | `rgba(168, 85, 247, 0.1)` | `#A855F7` | `#F0F9FF` |
| Ghost | transparent | `#3A3A50` | `#A0A0B0` |
| Danger | `rgba(244, 67, 54, 0.15)` | `#EF6262` | `#FF6B6B` |

### 14.3 Slider Styles

- Track: `#2A2A40`
- Fill: `#00F0FF` gradient
- Thumb: `#00F0FF` circle with glow
- Tooltip: `#0A0E1A` with `#00F0FF` text

---

## 15. TECHNICAL SPECIFICATIONS

### 15.1 Performance Targets

| Metric | Target |
|---|---|
| Viewport FPS | 60fps @ 4K |
| Particle Count | 10M max |
| Panel Render | < 16ms |
| AI State Transition | < 200ms |
| Undo/Redo | < 50ms |
| Scene Save | < 2s |
| Viewport Resize | < 100ms |

### 15.2 GPU Requirements

- Minimum: NVIDIA GTX 1080 (8GB VRAM)
- Recommended: NVIDIA RTX 3080 (10GB VRAM)
- Ideal: NVIDIA RTX 4090 (24GB VRAM)
- Compute: CUDA-capable for AI agent operations

### 15.3 API Integration

```typescript
interface ModelingStudioAPI {
  getAssetLibrary(): AssetCategory[];
  loadAsset(assetId: string): MeshData;
  getViewportStats(): ViewportStatistics;
  getAIAgentState(): AIAgentState;
  applyModifier(modifier: ModifierConfig): void;
  retopology(targetCount: number): MeshData;
  exportScene(format: ExportFormat): Blob;
  subscribeToAIEvent(callback: AIEventCallback): void;
}
```

---

## 16. ACCESSIBILITY

- All color pairs meet WCAG AA contrast ratios
- Keyboard navigation for all controls
- Screen reader support for viewport state announcements
- High-contrast mode override
- Reduced motion preference respected
- Focus indicators on all interactive elements

---

## 17. DESIGN COHERENCE WITH ACOS ECOSYSTEM

This studio shares the following design DNA with all other ACOS studios:

- **Neural Core:** Central glowing node that pulses with AI activity
- **Glass Surfaces:** Consistent transparency and blur levels
- **Particle Activity:** Background neural particles respond to system state
- **Cyan-Blue Illumination:** Shared accent color family
- **Spatial Transitions:** Smooth panel animations across all studios
- **AI Agent Pattern:** Consistent state machine visualization
- **Typography:** Orbitron + Inter + JetBrains Mono font stack
- **Design Tokens:** Single source of truth via `DesignTokens`

---

## APPENDIX A: AI MODELING AGENT STATE DIAGRAM

```
                   ┌─────────────┐
                   │ ANALYZING   │
                   │ (scanning)  │
                   └──────┬──────┘
                          │ AI completes analysis
                          ▼
                   ┌─────────────┐
                   │ BLOCKING    │
                   │ (foundations)│
                   └──────┬──────┘
                          │ Base mesh established
                          ▼
                   ┌─────────────┐
                   │ GENERATING  │
                   │ (particles) │
                   │ → crystallize│
                   └──────┬──────┘
                          │ Geometry formed
                          ▼
                   ┌─────────────┐
                   │ REFINING    │
                   │ (surface)   │
                   └──────┬──────┘
                          │ Surface detailed
                          ▼
                   ┌─────────────┐
                   │ RETOPOLOGIZING│
                   │ (topology)  │
                   └──────┬──────┘
                          │ Clean topology
                          ▼
                   ┌─────────────┐
                   │ TEXTURING   │
                   │ (materials) │
                   └──────┬──────┘
                          │ Materials applied
                          ▼
                   ┌─────────────┐
                   │ OPTIMIZING  │
                   │ (efficiency)│
                   └──────┬──────┘
                          │ Optimization complete
                          ▼
                   ┌─────────────┐
                   │ VERIFIED    │
                   │ ✓ validated │
                   └─────────────┘
```

---

## APPENDIX B: VIEWPORT RENDERING PIPELINE

```
Scene Graph
    │
    ▼
Culling (Frustum + Occlusion)
    │
    ▼
LOD Selection
    │
    ▼
Material Binding (PBR)
    │
    ▼
Lighting Pass (HDRI + Punctual)
    │
    ▼
Shadow Pass
    │
    ▼
GBuffer Generation
    │
    ▼
Post-Processing (Bloom + DOF + ACES)
    │
    ▼
Overlay Pass (Wireframe / Topology / Particles)
    │
    ▼
Output to Viewport
```

---

*Specification Version 1.0 — ACOS Creative Operating System*
*Design Standard: 8K, 16:9, Borderless Desktop*
*Color System: Deep Black + Midnight Navy + Cyan-Blue Neural + Violet Energy*
