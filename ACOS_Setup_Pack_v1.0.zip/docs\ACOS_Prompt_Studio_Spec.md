# ACOS Prompt Engineering Studio — Design Specification

> **Studio ID:** STUDIO-39
> **Version:** 1.0
> **Format:** Borderless 16:9 Desktop Application
> **Resolution Target:** 8K (7680 x 4320)
> **Design Language:** Dark Glass + Neural Illumination
> **Accent Color:** #06B6D4 (Prompt Cyan)

---

## 1. VISUAL IDENTITY

### 1.1 Color Palette

| Role | Token | Value |
|---|---|---|
| Deep Black Base | `--studio-bg-deep` | `#05050A` |
| Midnight Navy | `--studio-bg-midnight` | `#0A0E1A` |
| Surface Glass | `--studio-glass-bg` | `rgba(10, 14, 30, 0.72)` |
| Glass Border | `--studio-glass-border` | `rgba(0, 240, 255, 0.08)` |
| Cyan Neural | `--studio-neural-cyan` | `#00F0FF` |
| Blue Neural | `--studio-neural-blue` | `#3B82F6` |
| Prompt Cyan | `--studio-accent` | `#06B6D4` |
| Prompt Glow | `--studio-accent-glow` | `rgba(6, 182, 214, 0.35)` |
| Violet Energy | `--studio-energy-violet` | `#A855F7` |
| Surface Text | `--studio-text` | `#F0F9FF` |
| Secondary Text | `--studio-text-dim` | `#64748B` |

### 1.2 Typography

- **Display:** Orbitron (section headers, pipeline labels)
- **Body:** Inter (prompt text, intelligence descriptions)
- **Mono:** JetBrains Mono (engine tags, version ids, token counts)

### 1.3 Atmosphere

- Dark glass master layout, cyan-blue neural rim lighting, #06B6D4 prompt accent on active prompt segments
- Center editor shows neural particles assembling prompt components into a cohesive block
- Bottom timeline shows prompt version history with particle assembly on version change
- 8K rendering ensures crisp monospaced prompt typography

---

## 2. LAYOUT ARCHITECTURE

```
+------------------------------------------------------------------+
| LEFT: TEMPLATES & PRESETS (300px) | CENTER: STRUCTURED PROMPT EDITOR | RIGHT: INTELLIGENCE (340px) |
| Search + template chips           |  10-segment editor: Character / |  Consistency                    |
| Prompt Templates (6)              |  Environment / Camera / Lighting|  Cinematic Detail               |
| Production Presets (5)            |  Animation / VFX / Voice /      |  Missing Info                   |
| Token weight hint                 |  Sound / Music / Video Gen      |  Engine Compatibility           |
|                                   |  Compiled preview block         |  Negative Constraints           |
|                                   |                                 |  Optimization Suggestions       |
+------------------------------------------------------------------+
| BOTTOM: PROMPT VERSION TIMELINE (150px) — version pills with assembling particles                                                         |
+------------------------------------------------------------------+
```

| Panel | Width | Style |
|---|---|---|
| Left: Templates & Presets | 300px | Glass, grouped list, selectable chips |
| Center: Structured Prompt Editor | Flex | Glass sub-panels per segment, compiled output |
| Right: Intelligence | 340px | Glass, stack of diagnostic sections |
| Bottom: Version Timeline | 150px height | Glass strip, version pills, particle assembly |

---

## 3. CENTER — STRUCTURED PROMPT EDITOR

### 3.1 Structure

- 10 labeled segments, each is a glass sub-card with textarea
- Segments: Character, Environment, Camera, Lighting, Animation, VFX, Voice, Sound, Music, Video Generation
- Each segment header: Orbitron 9px label, mono token count (e.g., 24 tokens), colored left border per segment
- Segment colors cycle cyan / blue / violet / emerald for visual variety, all within prompt-cyan family when active
- Compiled Preview block at bottom of center: read-only merged prompt with copy button

### 3.2 Visual

- Segment card: `rgba(10,14,30,0.72)` glass, `1px solid rgba(0,240,255,0.08)` border, 8px radius
- Active segment (focused): border `rgba(6,182,214,0.35)`, inner glow `0 0 16px rgba(6,182,214,0.12)`, scale 1.01
- Textarea: transparent background, mono-friendly, placeholder dim
- Token count updates on keystroke (debounced 180ms)
- Neural particles above editor coalesce toward the compiled preview when segments change

### 3.3 Interaction

- Click segment header to focus; keyboard Tab cycles segments
- Typing triggers reassessment of right-panel intelligence after 400ms debounce
- Copy compiled prompt copies merged text to clipboard, shows toast "Copied"
- Enhance button per segment calls `AcosAPI.enhancePrompt` for AI rewrite

### 3.4 Motion

- Segment focus transition: border-color 200ms cubic-bezier(0.16,1,0.3,1), scale 1.01
- Particle assembly: when prompt updates, 18 particles travel from edited segment toward compiled preview over 900ms
- Compiled preview updates with fade (opacity 0 to 1 over 220ms) and subtle height lerp

---

## 4. LEFT PANEL — PROMPT TEMPLATES & PRODUCTION PRESETS

### 4.1 Content

**Prompt Templates (6):**

| Template | Description |
|---|---|
| Cinematic Hero Portrait | Close-up character with volumetric lighting |
| Mumbai Monsoon Chase | Rain-soaked street action |
| Neo-Mumbai Skyline | Wide establishing, neon reflections |
| Intimate Dialogue | Two-shot, shallow depth of field |
| Mythic Landscape | Environment establishing, golden hour |
| Action Montage | Fast-cut multi-angle beats |

**Production Presets (5):**

| Preset | Description |
|---|---|
| 35mm Anamorphic | Lens + aperture + film grain |
| Volumetric Cyberpunk Neon | Lighting rig |
| Octane Photoreal 8K | Render style |
| Kodak Film Grain | Color + texture |
| Unreal Engine 5 | Rendering pipeline |

### 4.2 Visual

- Glass panel title PROMPT TEMPLATES, subtitle PRODUCTION PRESETS below divider
- Each template/preset is a pill chip with left color dot, label, and token hint; selected chip has prompt-cyan background `rgba(6,182,214,0.14)` and border `#06B6D4`
- Search input at top with cyan focus glow

### 4.3 Interaction

- Click template to populate center segments with preset content, triggers particle assembly burst (16 particles)
- Click preset to overlay style tokens into relevant segments
- Hover chip scales 1.02, border brightens

---

## 5. RIGHT PANEL — INTELLIGENCE

### 5.1 Diagnostic Sections

| Section | Metric | Visual |
|---|---|---|
| Consistency | 0-100 score + issue list | Progress ring, cyan |
| Cinematic Detail | 0-100 score + suggestions | Progress ring, violet |
| Missing Info | Checklist of absent fields | Amber badges per missing item |
| Engine Compatibility | Per-engine pass/warn/fail | Chip per engine (SDXL, Veo, Runway, Pika) |
| Negative Constraints | Current negative prompt + add buttons | Tag list |
| Optimization Suggestions | Ranked suggestions with Apply | Numbered rows with Apply button |

### 5.2 Visual

- Glass panel title INTELLIGENCE, prompt-cyan accent
- Scores use circular SVG progress with glow; value text Orbitron 11px
- Engine compatibility chips: green pass, amber warn, red fail with 1px border
- Optimization rows: hover reveals Apply button with cyan glow

### 5.3 Interaction

- Apply suggestion merges its text into the relevant center segment, triggers particle reassembly
- Click engine chip shows compatibility tooltip
- Missing info item click focuses the corresponding center segment

---

## 6. BOTTOM — PROMPT VERSION TIMELINE

### 6.1 Visual

- Horizontal glass strip, 150px height
- Version pills: V01 to V08, each showing timestamp, token delta (+12), and status dot (draft, reviewed, approved)
- Active version pill larger, prompt-cyan border, glow `0 0 12px rgba(6,182,214,0.28)`
- Track line connects pills, particle assembly effect travels when switching versions
- Assembling particles: small cyan dots coalesce toward active pill from both sides

### 6.2 Interaction

- Click pill to load that version into center editor (content swaps, particles assemble from timeline to editor)
- Hover pill shows preview tooltip (first 80 chars)
- New Version button creates next version (duplicates current, bumps id)
- Scrub playhead drags selection

### 6.3 Motion

- Pill activation: scale 1.06 over 220ms, glow fade in 300ms
- Particles travel along track toward active pill using requestAnimationFrame, staggered start 40ms
- Version switch emits burst of 12 particles from timeline toward compiled preview

---

## 7. AI STATE MACHINE

```
IDLE -> ANALYZING_PROMPT -> CHECKING_CONSISTENCY -> SCORING_CINEMATIC -> VALIDATING_ENGINES -> SUGGESTING -> OPTIMIZED
```

- Each state auto-advances via interval 1.5s; SUGGESTING holds 2s then loops to IDLE unless user edits
- State color drives right-panel score ring colors and particle hue
- State label shown in center header with progress bar

---

## 8. PARTICLE SYSTEM

- Canvas particles: 160 count, cyan (#06B6D4 / #00F0FF) palette, speed 0.3-0.7
- Assembly behavior: on edit, particles converge from segment positions to compiled preview anchor point
- Timeline particles: directed flow along bottom track when version switches
- Opacity 0.14 idle, 0.55 during assembly

---

## 9. TECHNICAL SPECIFICATIONS

| Metric | Target |
|---|---|
| Viewport FPS | 60fps |
| Canvas particles | 160 |
| Intelligence reassessment debounce | 400ms |
| State transition | 1.5s |

### API Integration

```typescript
interface PromptStudioAPI {
  getPromptTemplates(): PromptTemplate[];
  getProductionPresets(): ProductionPreset[];
  enhancePrompt(segment: string, text: string): Promise<PromptEnhancement>;
  compilePrompt(segments: PromptSegments): string;
  getIntelligence(prompt: string): PromptIntelligence;
  getPromptVersions(): PromptVersion[];
}
```

---

*Specification Version 1.0 — ACOS Creative Operating System*
*Design Standard: 8K, 16:9, Borderless Desktop*
*Color System: Deep Black + Midnight Navy + Cyan-Blue Neural + #06B6D4 Prompt*
