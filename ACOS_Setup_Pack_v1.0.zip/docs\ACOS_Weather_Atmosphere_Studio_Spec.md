# ACOS Weather & Atmospheric Intelligence Studio — Design Specification

> **Studio ID:** STUDIO-33
> **Version:** 1.0
> **Format:** Borderless 16:9 Desktop Application
> **Resolution Target:** 8K (7680 × 4320)
> **Design Language:** Dark Glass + Volumetric Atmospheric + Neural Weather

---

## 1. VISUAL IDENTITY

### 1.1 Color Palette

| Role | Token | Value |
|---|---|---|
| Deep Black Base | `--studio-bg-deep` | `#05050A` |
| Midnight Navy | `--studio-bg-midnight` | `#0A0E1A` |
| Surface Glass | `--studio-glass-bg` | `rgba(10, 14, 30, 0.72)` |
| Glass Border | `--studio-glass-border` | `rgba(0, 240, 255, 0.08)` |
| Weather Accent | `--studio-weather` | `#00BFFF` |
| Rain Blue | `--studio-rain` | `#4A90D9` |
| Storm Purple | `--studio-storm` | `#6A3093` |
| Fog Gray | `--studio-fog` | `#8B9BAF` |
| Snow White | `--studio-snow` | `#E8ECF1` |
| Lightning | `--studio-lightning` | `#FFD93D` |
| Wind Cyan | `--studio-wind` | `#00E5CC` |
| Heat Orange | `--studio-heat` | `#FF6B35` |
| Monsoon Teal | `--studio-monsoon` | `#00838F` |
| Surface Text | `--studio-text` | `#F0F9FF` |
| Secondary Text | `--studio-text-dim` | `#64748B` |

### 1.2 Typography

- **Display:** Orbitron (headings, weather labels)
- **Body:** Inter (parameters, descriptions)
- **Mono:** JetBrains Mono (values, intensities)

### 1.3 Atmosphere

- Deep black background with volumetric fog gradient
- Weather accent (`#00BFFF`) rim lighting on glass panels
- Rain particle effects on viewport borders
- Lightning flash effects during storm
- Dynamic atmospheric color shifts

---

## 2. LAYOUT ARCHITECTURE

### 2.1 Full Desktop Layout (16:9)

```
+------------------------------------------------------------------+
|  APPLICATION BAR (ACOS Shell)                                   |
+------------------------------------------------------------------+
|                              |                                    |
|  LEFT: WEATHER               |  CENTER: 3D CINEMATIC           |
|  PRESETS                     |  ENVIRONMENT WITH DYNAMIC     |
|                              |  WEATHER SYSTEM               |
|  • Indian Monsoon            |                                    |
|  • Summer Heat               |  Atmosphere Controls Overlay   |
|  • Winter Fog                |  • Rain Toggle                 |
|  • Dust Storm                |  • Fog Density                 |
|  • Thunderstorm              |  • Wind Direction              |
|  • Clear Sky                 |  • Lightning                   |
|  • Golden Hour               |  • Snow                        |
|  • Night Mist                |  • Humidity                    |
|                              |  • Atmospheric Density         |
|                              |  • Visibility                  |
|  Glass Panels with           |                                    |
|  weather-blue borders        |  Volumetric Cloud & Fog        |
|                              |  Rendering                     |
+------------------------------|------------------------------------+
|                              |  RIGHT: WEATHER                |
|  BOTTOM:                     |  INTELLIGENCE PANEL           |
|  WEATHER TIMELINE          |                                    |
|  & TIME TRANSITIONS        |  • Intensity                     |
|                              |  • Direction                     |
|  Gradual transition          |  • Density                       |
|  bar across timeline       |  • Particle Count                |
|  Show scene evolution      |  • Wind Velocity                 |
|                              |  • Visibility                    |
|                              |  • Environmental Interaction   |
+------------------------------------------------------------------+
|  STATUS BAR                                                       |
+------------------------------------------------------------------+
```

### 2.2 Panel Specifications

| Panel | Width | Style |
|---|---|---|
| Left: Weather Presets | 280px | Glass, blue-cyan accents |
| Center: 3D Environment | Flex (remaining) | Full volumetric rendering |
| Right: Intelligence | 320px | Glass, collapsible sections |
| Bottom: Timeline | 160px height | Glass strip with time markers |

---

## 3. CENTER VIEWPORT

### 3.1 Cinematic 3D Environment

- **Photorealistic rendering** with volumetric weather effects
- **Dynamic landscape** — cityscape or natural terrain
- **Real-time weather interaction** — rain on surfaces, fog density changes
- **Time-of-day cycle** — from dawn to midnight
- **Lightning illumination** — brief flash illuminates entire scene

### 3.2 Weather Particle System

| Weather Type | Particle Style | Color | Behavior |
|---|---|---|---|
| Rain | Vertical streaks | `#4A90D9` | Gravity-driven, splashes on impact |
| Snow | Flakes | `#E8ECF1` | Drifting, wind-affected, slow descent |
| Fog | Volumetric volume | `rgba(139, 155, 175, 0.3)` | Distance-based density |
| Dust | Horizontal streaks | `#D4A574` | Wind-driven, ground-level |
| Lightning | Flash pulses | `#FFD93D` | Instantaneous illumination |
| Wind | Flow lines | `#00E5CC` | Directional, variable speed |
| Clouds | Volumetric layers | `rgba(200, 210, 220, 0.4)` | Drifting, density varies |

### 3.3 Atmospheric Controls

| Control | Range | Description |
|---|---|---|
| Rain Intensity | 0% – 100% | Drop density and speed |
| Fog Density | 0% – 100% | Atmospheric scattering |
| Wind Speed | 0 – 100 km/h | Particle drift speed |
| Wind Direction | 0° – 360° | Cardinal + intercardinal |
| Dust Density | 0% – 100% | Particulate matter |
| Snow Density | 0% – 100% | Flake count |
| Lightning Frequency | 0 – 20/min | Strike rate |
| Humidity | 0% – 100% | Surface wetness |
| Atmospheric Density | 0.5 – 2.0 | Scattering coefficient |
| Temperature | -40°C – 60°C | Affects weather type |
| Visibility | 10m – 50km | Atmospheric clarity |
| Cloud Coverage | 0% – 100% | Sky coverage |

### 3.4 Surface Interaction

- Rain physically interacts with surfaces (wetness, puddles, splashes)
- Fog changes opacity based on distance and wind direction
- Lightning briefly illuminates the environment (0.5s flash)
- Snow accumulates on surfaces gradually
- Dust creates haze on distant objects
- Wet surfaces show reflections with rain intensity

---

## 4. LEFT PANEL — WEATHER PRESETS

### 4.1 Preset Categories

| Preset | Color | Icon | Description |
|---|---|---|---|
| Indian Monsoon | `#00838F` | [Monsoon] | Heavy rain, humidity 95%, wind 60km/h |
| Summer Heat | `#FF6B35` | [Heat] | Clear sky, high temp, haze |
| Winter Fog | `#8B9BAF` | [Fog] | Dense fog, low temp, visibility 200m |
| Dust Storm | `#D4A574` | [Dust] | Severe dust, wind 80km/h, orange haze |
| Thunderstorm | `#6A3093` | [Storm] | Lightning, heavy rain, wind 100km/h |
| Clear Sky | `#4A90D9` | [Clear] | Perfect visibility, no particles |
| Golden Hour | `#FFB347` | [Golden] | Warm light, long shadows, sunset |
| Night Mist | `#2C3E50` | [Night] | Darkness, fog, low visibility |

### 4.2 Preset Card Style

- Glass background (`rgba(10, 14, 30, 0.72)`)
- Weather accent border on hover (`rgba(0, 191, 255, 0.3)`)
- Mini environment thumbnail (rendering in viewport)
- Category badge with weather-specific color coding
- Auto-apply indicator (neural pulse dot)

### 4.3 Preset Details

Each preset shows:
- Primary weather condition
- Temperature range
- Wind profile
- Visibility range
- Recommended camera settings
- AI mood recommendation

---

## 5. RIGHT PANEL — WEATHER INTELLIGENCE

### 5.1 Section: Intensity

- **Overall intensity:** 0% – 100% (global weather strength)
- **Rain intensity:** Independent slider
- **Fog intensity:** Independent slider
- **Wind intensity:** Independent slider
- **Storm intensity:** Lightning + thunder + rain combined
- **Dust intensity:** Particulate density
- **Snow intensity:** Flake density

### 5.2 Section: Direction

- **Wind vector display** (compass rose)
- **Direction:** 0° (N) → 360° (N)
- **Wind speed:** 0 – 100 km/h
- **Gust factor:** 1.0x – 3.0x multiplier
- **Direction visualization:** Arrow with particle flow
- **Prevailing wind indicator**
- **Crosswind component**

### 5.3 Section: Density

- **Particle count:** Real-time counter
- **Fog layers:** Near, Mid, Far (independent)
- **Cloud base height:** 100m – 5000m
- **Cloud ceiling:** Variable
- **Volumetric resolution:** Low / Medium / High / Ultra
- **Scattering order:** Front-to-back / Back-to-front
- **Density gradient map**

### 5.4 Section: Particle Count

- **Rain drops/sec:** 1,000 – 1,000,000
- **Snow flakes/sec:** 100 – 100,000
- **Dust particles:** 10,000 – 5,000,000
- **Cloud particles:** 100,000 – 10,000,000
- **Fog volume voxels:** 1M³ – 1000M³
- **Lightning strikes:** Visual counter
- **Performance impact indicator**

### 5.5 Section: Wind Velocity

- **Speed:** 0 – 200 km/h
- **Direction:** 360° compass
- **Turbulence:** 0% – 100%
- **Vortex detection:** Auto-identified swirl zones
- **Wind shear:** Vertical speed differential
- **Pressure system:** High / Low / Neutral
- **Wind visualization:** Flow lines and particle trails

### 5.6 Section: Visibility

- **Current visibility:** 10m – 50km
- **Fog layer visibility:** Separate near/far/mid
- **Particle obscuration:** % of scene obscured
- **Contrast reduction:** Visual clarity metric
- **HDR bloom intensity:** Weather-related
- **Depth of field:** Affected by atmospheric scattering

### 5.7 Section: Environmental Interaction

| Parameter | Description |
|---|---|
| Surface Wetness | Rain accumulation on surfaces |
| Puddle Formation | Water pooling on terrain |
| Wet Reflection | Surface reflectivity increase |
| Fog Occlusion | Objects hidden by fog |
| Lightning Exposure | Object illumination during strikes |
| Wind Sway | Vegetation and structure movement |
| Temperature Effect | Frost/condensation on surfaces |
| Dust Accumulation | Surface dirt over time |

---

## 6. BOTTOM PANEL — TIME-BASED WEATHER TIMELINE

### 6.1 Weather Timeline

- Horizontal timeline showing weather transitions
- Time markers from dawn → noon → dusk → midnight → dawn
- Each segment shows weather state:
  - Clear (blue)
  - Cloudy (gray)
  - Rain (blue-gray)
  - Storm (purple)
  - Fog (white-gray)
  - Snow (white-blue)
  - Dust (orange-brown)
  - Golden Hour (orange-yellow)
  - Night (dark-blue)

### 6.2 Transition Controls

- **Gradual transition:** Smooth weather change over time
- **Instant transition:** Immediate weather change
- **Scheduled transitions:** Auto-change at time markers
- **Manual scrub:** Drag timeline to any point
- **Transition duration:** 30s – 30min
- **Weather interpolation:** Linear / Ease-in / Ease-out / Natural

### 6.3 Comparison Mode

- Side-by-side comparison of two time points
- Difference highlighting (color-coded)
- Weather delta values displayed
- Scene state comparison (wetness, fog, lighting)

---

## 7. AI ENVIRONMENT AGENT

### 7.1 State Machine

```
SCOUTING → ANALYZING → RECOMMENDING → GENERATING → APPLYING → SIMULATING → VALIDATING → OPTIMIZED
```

### 7.2 State Visualizations

| State | Color | Animation | Description |
|---|---|---|---|
| SCOUTING | `#64748B` | Slow scan ring | AI examines scene context |
| ANALYZING | `#00BFFF` | Blue analysis pulse | AI analyzes mood/scene |
| RECOMMENDING | `#FFD93D` | Amber suggestion pulse | AI recommends weather |
| GENERATING | `#00BFFF` | Fast particle generation | AI generates weather system |
| APPLYING | `#00E5CC` | Cyan flow onto scene | AI applies weather parameters |
| SIMULATING | `#6A3093` | Purple simulation waves | AI runs physics simulation |
| VALIDATING | `#4CCB8A` | Green validation pulse | AI validates realism |
| OPTIMIZED | `#10B981` | Steady green | AI optimizes performance |

### 7.3 AI Recommendations

- **Scene mood analysis:** What weather fits the emotional tone?
- **Character interaction:** How do characters respond to weather?
- **Camera suitability:** Best camera settings for current weather
- **Lighting optimization:** Optimal light setup for weather
- **Performance balancing:** Particle count vs. visual quality
- **Automatic weather transitions:** Seamless time-of-day changes

### 7.4 Neural Particle Flow

- AI analyzes scene → particles flow from neural core
- Particles carry weather data (type, intensity, direction)
- Particles crystallize into weather particle systems
- Each weather type has unique particle color:
  - Rain → Blue particle streams
  - Snow → White particle clouds
  - Fog → Gray volumetric wisps
  - Lightning → Gold flash particles
  - Dust → Orange horizontal streams
- Particles settle into weather simulation grid
- Environment updates in real-time

---

## 8. PARTICLE VISUALIZATION

### 8.1 AI Weather Generation Flow

When the AI generates weather:

1. **Scouting Phase (0-15%):**
   - Gray particles (`#64748B`) scan the environment
   - Particles analyze terrain, structures, lighting
   - Scene context identified

2. **Analysis Phase (15-30%):**
   - Blue particles (`#00BFFF`) flow across scene
   - AI calculates optimal weather parameters
   - Mood analysis completed
   - Recommendation displayed

3. **Generation Phase (30-55%):**
   - Weather-specific particles begin forming
   - Rain particles (blue) or snow particles (white)
   - Fog volumetric wisps (gray) begin forming
   - Lightning energy (gold) accumulating
   - Particle count ramps up

4. **Application Phase (55-75%):**
   - Particles spread across environment
   - Surface interaction effects begin
   - Wetness, puddles, accumulation appear
   - Wind affects all particle types

5. **Simulation Phase (75-90%):**
   - Physics simulation runs
   - Particles interact with surfaces realistically
   - Environmental feedback loop active
   - AI validates physical accuracy

6. **Validation Phase (90-100%):**
   - All particles stabilize
   - Weather system reaches equilibrium
   - Quality metrics displayed
   - Green completion pulse

### 8.2 Particle Parameters

| Parameter | Value |
|---|---|
| Max Particle Count | 10,000,000 |
| Rain Particle Size | 0.5 – 2.0 px |
| Snow Particle Size | 1.0 – 4.0 px |
| Fog Voxel Resolution | 64³ – 512³ |
| Cloud Particle Count | 100K – 10M |
| Lightning Duration | 0.1 – 0.5s per strike |
| Convergence Speed | 0.3 – 1.5 units/sec |
| Animation Duration | 5 – 15 seconds |
| Simulation Resolution | 128 – 1024 grid |

---

## 9. LIGHTNING AND ATMOSPHERIC EFFECTS

### 9.1 Lightning System

- **Fork count:** 1 – 5 branches per strike
- **Duration:** 0.1 – 0.5 seconds per flash
- **Intensity:** 0 – 100% brightness
- **Color:** `#FFD93D` (white-yellow)
- **Strike pattern:** Random / Targeted / Patterned
- **Sound synchronization:** Thunder delay based on distance
- **Environment illumination:** 0.5s full scene flash
- **Afterglow:** 0.2s residual glow

### 9.2 Volumetric Fog

| Parameter | Range | Description |
|---|---|---|
| Near Fog | 0% – 100% | Ground-level density |
| Mid Fog | 0% – 100% | Mid-altitude density |
| Far Fog | 0% – 100% | Horizon density |
| Fog Color | RGB | Tinted by weather |
| Scattering | 0 – 10 | Multiple scattering order |
| Absorption | 0 – 10 | Light absorption coefficient |
| Animated | Boolean | Wind-driven fog movement |

### 9.3 Wet Surface Rendering

- **Specular boost:** Wet surfaces reflect more
- **Normal map modification:** Water fills micro-details
- **Puddle generation:** Automatic water pooling
- **Reflection quality:** Increases with rain intensity
- **Color shift:** Surfaces appear darker when wet
- **Evaporation:** Slow drying when rain stops

---

## 10. INTERACTION PATTERNS

### 10.1 Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `R` | Toggle rain |
| `F` | Toggle fog |
| `S` | Toggle snow |
| `D` | Toggle dust |
| `L` | Trigger lightning |
| `W` | Toggle wind visualization |
| `C` | Toggle clouds |
| `G` | Generate weather (AI) |
| `T` | Toggle timeline |
| `1`-`8` | Select weather preset |
| `Space` | Play/pause timeline |
| `Ctrl+Z` | Undo |
| `Ctrl+Shift+Z` | Redo |
| `M` | Macro view |
| `P` | Picture-in-picture comparison |

### 10.2 Mouse Interactions

| Action | Button |
|---|---|
| Orbit environment | Left drag |
| Pan view | Middle drag / Alt+Left |
| Zoom | Scroll wheel |
| Adjust parameter | Left drag on slider |
| Set wind direction | Right drag on compass |
| Select lightning target | Left click on object |
| Scrub timeline | Left drag on timeline |
| Adjust fog region | Left drag on fog volume |
| Pick weather preset | Left click in library |

---

## 11. MOTION & ANIMATION

### 11.1 Panel Transitions

- Left panel slide-in/out: 300ms ease-out
- Right panel collapse/expand: 250ms ease-in-out
- Bottom timeline expand/collapse: 200ms linear
- Weather parameter changes: 200ms smooth
- Lightning flash: 50ms instant
- Fog transition: 1000ms gradual
- Rain intensity change: 500ms smooth ramp

### 11.2 Neural Particle Activity

- Background particle density varies with AI activity
- When AI generates weather, particles flow toward viewport
- Particle color matches current AI agent state color
- Idle state: ambient particles at 8% opacity (blue)
- Active state: directed particle streams at 40% opacity
- Weather-specific particles visible in viewport
- Thunder creates sudden particle burst

---

## 12. DESIGN SYSTEM COMPONENTS

### 12.1 Weather Preset Card

```jsx
<WeatherPresetCard
  name="Indian Monsoon"
  color="#00838F"
  temperature="28°C"
  wind="60 km/h"
  humidity="95%"
  isActive={false}
  icon="[Monsoon]"
/>
```

### 12.2 Atmospheric Slider

```jsxx
<AtmosphericSlider
  label="Rain Intensity"
  color="#4A90D9"
  value={0.75}
  unit="%"
  onChange={(v) => updateWeather('rain', v)}
/>
```

### 12.3 Particle Counter

```jsx
<ParticleCounter
  label="Rain Drops"
  value={450000}
  max={1000000}
  color="#4A90D9"
/>
```

### 12.4 Button Styles

| Type | Background | Border | Text |
|---|---|---|---|
| Primary | `rgba(0, 191, 255, 0.15)` | `#00BFFF` | `#F0F9FF` |
| Weather | `rgba(106, 48, 147, 0.1)` | `#6A3093` | `#F0F9FF` |
| Temperature | `rgba(255, 107, 53, 0.1)` | `#FF6B35` | `#F0F9FF` |
| Ghost | transparent | `#3A3A50` | `#A0A0B0` |
| Danger | `rgba(244, 67, 54, 0.15)` | `#EF6262` | `#FF6B6B` |

---

## 13. TECHNICAL SPECIFICATIONS

### 13.1 Performance Targets

| Metric | Target |
|---|---|
| Viewport FPS | 60fps @ 4K |
| Max Particle Count | 10M |
| Volumetric Fog FPS | 60fps @ Ultra |
| Parameter Update | < 16ms |
| Lightning Render | < 50ms |
| Transition Time | < 2s |
| AI Generation Time | < 5s |
| Scene Save/Load | < 3s |

### 13.2 Rendering Pipeline

```
Scene Geometry
    │
    ▼
Weather System Generation
    │
    ▼
Volumetric Fog Pass
    │
    ▼
Particle System Pass (Rain/Snow/Dust)
    │
    ▼
Cloud Layer Rendering
    │
    ▼
Lighting Pass (Dynamic weather lighting)
    │
    ▼
Wet Surface Pass (Reflection/Refraction)
    │
    ▼
Lightning Flash Pass
    │
    ▼
Post-Processing (Bloom + DOF + ACES + Weather)
    │
    ▼
Output to Viewport
```

### 13.3 GPU Requirements

- Minimum: NVIDIA GTX 1070 (8GB VRAM) — volumetric fog
- Recommended: NVIDIA RTX 3080 (10GB VRAM) — particle systems
- Ideal: NVIDIA RTX 4090 (24GB VRAM) — 10M particles, 512³ fog
- Compute: CUDA for AI agent operations

---

## 14. DESIGN COHERENCE WITH ACOS ECOSYSTEM

This studio shares the following design DNA with all other ACOS studios:

- **Neural Core:** Central glowing node that pulses with AI activity
- **Glass Surfaces:** Consistent transparency and blur levels
- **Particle Activity:** Background neural particles respond to system state
- **Weather Accent (`#00BFFF`):** Shared blue-cyan accent color
- **Spatial Transitions:** Smooth panel animations across all studios
- **AI Agent Pattern:** Consistent state machine visualization
- **Typography:** Orbitron + Inter + JetBrains Mono font stack
- **Design Tokens:** Single source of truth via `DesignTokens`

---

*Specification Version 1.0 — ACOS Creative Operating System*
*Design Standard: 8K, 16:9, Borderless Desktop*
*Color System: Deep Black + Midnight Navy + Weather Blue + Neural Particles*
