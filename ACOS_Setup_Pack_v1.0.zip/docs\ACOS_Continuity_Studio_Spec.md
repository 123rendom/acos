# ACOS Continuity Control Studio — Design Specification

> **Studio ID:** STUDIO-35
> **Version:** 1.0
> **Format:** Borderless 16:9 Desktop Application
> **Resolution Target:** 8K (7680 x 4320)
> **Design Language:** Dark Glass + Neural Graph + Continuity Amber

---

## 1. VISUAL IDENTITY

### 1.1 Color Palette

| Role | Token | Value |
|---|---|---|
| Deep Black Base | `--studio-bg-deep` | `#05050A` |
| Midnight Navy | `--studio-bg-midnight` | `#0A0E1A` |
| Surface Glass | `--studio-glass-bg` | `rgba(10, 14, 30, 0.72)` |
| Glass Border | `--studio-glass-border` | `rgba(0, 240, 255, 0.08)` |
| Continuity Accent | `--studio-continuity` | `#F59E0B` |
| Continuity Glow | `--studio-continuity-glow` | `rgba(245, 158, 11, 0.35)` |
| Amber Pulse | `--studio-amber-pulse` | `#FBBF24` |
| Neural Cyan | `--studio-cyan` | `#00F0FF` |
| Neural Blue | `--studio-blue` | `#3B82F6` |
| Success Green | `--studio-success` | `#10B981` |
| Warning Amber | `--studio-warning` | `#F59E0B` |
| Error Red | `--studio-error` | `#EF4444` |
| Surface Text | `--studio-text` | `#F0F9FF` |
| Secondary Text | `--studio-text-dim` | `#64748B` |

### 1.2 Typography

- **Display:** Orbitron (headings, graph node labels)
- **Body:** Inter (panel text, descriptions)
- **Mono:** JetBrains Mono (scores, frame numbers)

### 1.3 Atmosphere

- Deep black background with amber-cyan bi-tone rim lighting
- Continuity amber `#F59E0B` for inspector scores, mismatch pulses, active links
- Cyan-blue `#00F0FF / #3B82F6` for graph edges and neural core
- Dark glass panels with `backdrop-filter: blur(20px)`
- Amber mismatch pulse (1.4s ease-in-out) on affected timeline frames
- Radial vignette + grid pulse overlays

---

## 2. LAYOUT ARCHITECTURE

### 2.1 Full Desktop Layout (16:9)

```
+------------------------------------------------------------------+
|  APPLICATION BAR (ACOS Shell)                                    |
+------------------------------------------------------------------+
| LEFT: CATEGORIES    |  CENTER: 3D RELATIONSHIP GRAPH        | RIGHT: AI CONTINUITY INSPECTOR |
| 280px glass         |  Flex - force-directed graph canvas   | 320px glass                    |
|                     |                                       |                                |
| Character           |  Nodes: Characters, Wardrobe, Props,  |  Character  98% [bar]         |
| Environment         |  Locations, Weather, Lighting,        |  Environment 96% [bar]       |
| Props               |  Camera, Time, Dialogue, Scene Events |  Lighting 94% [bar]          |
| Camera              |                                       |  Camera 99% [bar]            |
| Lighting            |  Edges glow cyan, amber on hover      |  Prop 97% [bar]             |
| Audio               |  Central neural core pulse            |  Overall 97%                 |
| Timeline            |                                       |  Mismatches: 2               |
| Story               |  Node orbits + edge curvature         |  [Fix] [Ignore]              |
+---------------------+---------------------------------------+-------------------------------+
| BOTTOM: SCENE-TO-SCENE COMPARISON TIMELINE (150px glass strip)                              |
| Scene A thumbnails | <--> diff | Scene B thumbnails | Amber pulse on mismatch frames           |
| Frames 01-24       | Affected: F12, F18           | Frames 01-24 | Highlight border amber    |
+------------------------------------------------------------------+
| STATUS BAR                                                       |
+------------------------------------------------------------------+
```

### 2.2 Panel Specifications

| Panel | Width | Style |
|---|---|---|
| Left: Categories | 280px | Glass, amber left-border on active, count badge |
| Center: Relationship Graph | Flex | Canvas force-directed graph, orb core, curved edges |
| Right: Inspector | 320px | Glass, score bars amber-cyan gradient, collapse sections |
| Bottom: Comparison Timeline | 150px height | Glass strip, dual-scene thumbnails, diff connector |

---

## 3. CENTER VIEWPORT — 3D RELATIONSHIP GRAPH

### 3.1 Node Types

| Node Category | Color | Shape | Description |
|---|---|---|---|
| Characters | `#F59E0B` | Circle 18px | Cast continuity (costume, hair, position) |
| Wardrobe | `#EC4899` | Square 16px | Clothing continuity across scenes |
| Props | `#A855F7` | Diamond 14px | Object placement and state |
| Locations | `#10B981` | Hexagon 16px | Set continuity |
| Weather | `#06B6D4` | Triangle 14px | Atmospheric state binding |
| Lighting | `#FBBF24` | Star 16px | Light rig continuity |
| Camera | `#3B82F6` | Circle 18px | Focal length, angle continuity |
| Time | `#64748B` | Square 12px | Chronological consistency |
| Dialogue | `#00F0FF` | Diamond 14px | Script continuity |
| Scene Events | `#EF4444` | Hexagon 14px | Action beat continuity |

### 3.2 Graph Behavior

- **Layout:** Force-directed simulation (Barnes-Hut approx), center gravity toward neural core (canvas center), repulsion between nodes, spring edges
- **Core:** Central neural orb (radius 22px, amber-cyan gradient, pulse scale 0.96-1.06, emits edge glow)
- **Edges:** Bezier curves with cyan `rgba(0,240,255,0.35)` stroke, thickness 1.5px, hover thickness 2.5px amber `#F59E0B`, directional arrow chevron at 70% along curve
- **Node Motion:** Idle orbit drift `sin(time * 0.3 + index) * 8px`, selection lock (fixed position), filtered nodes fade to 0.15 opacity and stop attracting
- **Interaction:** Click node selects and highlights connected edges amber; drag node repositions with physics; hover shows tooltip (label + connections count)
- **Filtering:** Left category selection dims non-matching nodes and collapses their edges; Center re-centers simulation origin

### 3.3 Visual Details

- Node glow `0 0 14px <color>40`
- Edge particle: small amber dot travels along edge at 1.2 px/frame when inspector reports mismatch in that domain
- Background: radial gradient deep->midnight, vignette, cyan border glow 0.08 opacity
- Frame counter and graph stats overlay (node count, edge count, mismatch count) bottom-right

---

## 4. LEFT PANEL — CATEGORIES

### 4.1 Categories

| Category | Icon Label | Node Count | Color |
|---|---|---|---|
| Character | [Character] | 12 | `#F59E0B` |
| Environment | [Environment] | 8 | `#10B981` |
| Props | [Props] | 15 | `#A855F7` |
| Camera | [Camera] | 6 | `#3B82F6` |
| Lighting | [Lighting] | 7 | `#FBBF24` |
| Audio | [Audio] | 5 | `#06B6D4` |
| Timeline | [Timeline] | 9 | `#64748B` |
| Story | [Story] | 11 | `#EF4444` |

### 4.2 Card Style

- Glass row, 10px vertical gap, border-radius 6px
- Left accent bar 2px transparent -> `#F59E0B` on active
- Color dot 10px circle with `0 0 8px <color>`
- Label Inter 13px `#F0F9FF`
- Count badge: JetBrains Mono 9px, amber text, `rgba(245,158,11,0.15)` bg
- Filter badge when active: "FILTERING" amber pill 7px
- Click toggles filter (multi-select not required; single active at a time for clarity)

---

## 5. RIGHT PANEL — AI CONTINUITY INSPECTOR

### 5.1 Score Sections

| Domain | Target | Description |
|---|---|---|
| Character | 98% | Costume, hair, position, expression consistency |
| Environment | 96% | Location dressing, background continuity |
| Lighting | 94% | Light intensity, color temp, shadows |
| Camera | 99% | Lens, angle, height continuity |
| Prop | 97% | Object existence, position, state |

Each domain:
- Row with label (Inter 11px), score (Orbitron 12px amber/cyan), progress bar (amber gradient, height 4px, thumb glow)
- Trend indicator (up/flat/down) 9px
- Expand chevron shows detail list (e.g., "Wardrobe mismatch at Scene 4 Frame 12")

### 5.2 Overall Continuity

- Large pill: Overall 97% with circular progress ring amber `stroke #F59E0B` 4px
- Subtext: "2 mismatches detected" amber 10px JetBrains Mono
- Action row: [Fix All] amber primary, [Ignore] ghost
- On fix: scores increment toward 100%, amber pulse fades, graph edge pulse stops

### 5.3 Mismatch Detail

- Affected frames chips: `F12`, `F18` amber background `rgba(245,158,11,0.2)` border amber
- Scene pair: "Scene 3 -> Scene 4"
- Severity: High / Medium / Low with color red/amber/green

---

## 6. BOTTOM PANEL — SCENE-TO-SCENE COMPARISON TIMELINE

### 6.1 Dual-Scene Strip

- **Scene A strip:** 12 thumbnail cells (48px width each), first row, border `rgba(0,240,255,0.08)`, active frame cyan, mismatch frame amber border + pulse `box-shadow 0 0 12px rgba(245,158,11,0.4)`
- **Scene B strip:** Same count, second row, synchronized scroll
- **Diff Connector:** Vertical dashed line between A/B at mismatch frames, amber ` #F59E0B` 1px dashed, label "MISMATCH" 7px Orbitron amber
- **Affected Frames Highlight:** Chips row below strips: "Affected: F12, F18" with amber pills
- **Scrub:** Drag playhead across either strip moves both; diff connector follows
- **Comparison Toggle:** [Side-by-Side] [Overlay] [Diff Mask] pill controls at right

### 6.2 Amber Pulse

- On mismatch, affected thumbnail border animates `pulseAmber 1.4s ease-in-out infinite` (0 0 8px -> 0 0 18px amber)
- Timeline background flash `rgba(245,158,11,0.06)` for 400ms on inspector mismatch update

---

## 7. AI CONTINUITY AGENT

### 7.1 State Machine

```
SCANNING -> MAPPING_LINKS -> DETECTING_MISMATCH -> SCORING -> VALIDATED
```

- **SCANNING:** Graph edges sweep cyan, inspector bars indeterminate
- **MAPPING_LINKS:** Nodes connect with drawing animation, core pulse accelerates
- **DETECTING_MISMATCH:** Amber edge travelers spawn, mismatch count increments, pulse on timeline
- **SCORING:** Bars fill to final percentages with easing, scores tick up
- **VALIDATED:** Green ring on core, scores at final, pulse stops, overall 97% stable

Auto-advances via interval (140ms tick, +1.0% progress). Re-triggers SCANNING when category filter changes or Fix is pressed (immediate re-scan).

---

## 8. INTERACTION PATTERNS

### 8.1 Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `1-8` | Select category 1-8 |
| `F` | Fix all mismatches |
| `I` | Ignore mismatch |
| `Space` | Play timeline scrub |
| `D` | Toggle diff mode |
| `R` | Re-scan continuity |

### 8.2 Mouse Interactions

| Action | Button |
|---|---|
| Filter graph | Click category row |
| Select node | Click graph node |
| Drag node | Drag node circle |
| Re-score | Click Fix All |
| Scrub comparison | Drag timeline playhead |

---

## 9. MOTION & ANIMATION

- Category row highlight 150ms ease
- Node drift 0.3 rad/s sinusoid, edge curve updates per frame
- Inspector bar fill 600ms ease-out
- Amber pulse 1.4s ease-in-out infinite
- Core pulse 1.8s ease-in-out infinite
- Diff connector draw 300ms ease

---

## 10. TECHNICAL SPECIFICATIONS

| Metric | Target |
|---|---|
| Graph Nodes | 70 nodes @ 60fps force sim |
| Edges | ~120 curves @ 60fps |
| Canvas | DPR scaled, 8K ready |
| Inspector Update | < 16ms post-scan |
| Timeline Scrub | 120fps interpolation |
| AI Cycle | ~9s full progression |

---

## 11. DESIGN COHERENCE

Shares ACOS DNA: Neural Core, Glass Surfaces, Particle/Edge Activity, Orbitron/Inter/JetBrains Mono, DesignTokens, cyan-blue base + continuity amber `#F59E0B` accent.

---

*Specification Version 1.0 — ACOS Creative Operating System*
*Design Standard: 8K, 16:9, Borderless Desktop*
*Color System: Deep Black + Midnight Navy + Continuity Amber + Neural Cyan-Blue*
