# ACOS — AI Creative Operating System — Setup Pack

> **Version:** 1.0 · **Build:** 2026-04-13 · **Platform:** Windows 10/11 x64
> **Included Studios:** 31-40 + 03/05/06/07 + Interaction (41) — 8K 16:9 Borderless

## 1) Quick Start (Double-Click)
1. Zip ko extract kijiye `C:\ACOS_Setup\` me
2. `Final_Launch_ACOS.bat` par double-click kijiye — Vite + Electron auto-start hoga
3. Browser me `http://localhost:5173` khulega, desktop shell overlay hoga

## 2) Manual Run
```bat
npm install
npm run build
npm run dev      :: Vite http://localhost:5173
npm run electron :: Desktop shell (requires build/)
```

## 3) Pack Contents
```
ACOS_Setup_Pack/
  build/               — Vite production (index.html + assets 406kB)
  electron/            — Electron main.cjs + resources
  src_acos/            — Python backend bridge (acos engine)
  package.json         — scripts: dev/build/electron
  electron-builder.js  — productName com.acos.app → release-win32-x64/
  docs/ACOS_*.md       — 11 studio specs (31-40 + 03/05/06/07 + Interaction)
  Final_Launch_ACOS.bat, Launch_ACOS.bat, run-acos.bat
  README_SETUP_HI.md   — yeh file
```

## 4) System Requirements
- Windows 10/11 x64, 8GB RAM (16GB recommended), Node 18+, Python 3.10+
- GPU: GTX 1070+ (volumetric), RTX 3080+ (10M particles), RTX 4090 (8K)
- Port 5173 free, 1920×1080 min (3840×2160 recommended)

## 5) EXE Build (Installer)
```bat
npm install -g electron-builder
npx electron-builder --win --x64   :: output → release-win32-x64/ACOS AI Creative Operating System Setup.exe
```

## 6) Verify
- `npm run build` → `✓ built in ~140ms, 39 modules, 27kB CSS + 406kB JS`
- Studios visible: ORDER = cinematicPrevis ... publish + modeling/material/weather/interaction/performance/continuity/experiment/director/voiceCommand/prompt/mastering + story/character/environment/camera
- No emoji in `src/components/studios/*.jsx` (verified)

## 7) Support
`docs/ACOS_*_Spec.md` padhein — har studio ka 8K layout, neural core, glass, particle specs diya hai.
Issue ho to `dev-server.log` / `electron.log` check kijiye.

— ACOS Pack 1.0 · 8K 16:9 · Dark Glass + Cyan-Violet Neural
