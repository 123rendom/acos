# ACOS Environment Studio — Design Specification

> **Studio ID:** STUDIO-06
> **Version:** 1.0 · **Format:** Borderless 16:9 · **Resolution:** 8K · **Language:** Dark Glass + Volumetric World + Neural Particles

## 1. Visual Identity
| Token | Value |
|---|---|
| --acos-bg-deep | `#05050A` |
| --acos-bg-navy | `#0A0E1A` |
| --acos-glass | `rgba(10,14,30,0.72)` + blur 20px + border `rgba(0,240,255,0.08)` |
| --acos-env | `#2BCB8B` (Environment) |
| --acos-cyan | `#00F0FF` (vectors/grids) |
| --acos-violet | `#9D7BFF` (atmosphere) |
| --acos-amber | `#F59E0B` (population/props) |
| --acos-green | `#10B981` (continuity) |

Typography Orbitron/Inter/JetBrains Mono. Unreal/Blender photoreal, volumetric fog, atmospheric perspective, ray-traced reflections.

## 2. Layout 16:9
```
+---------------------------------------------------------------+
| APP BAR                                                     |
+---------------------------------------------------------------+
| LEFT 300px | CENTER flex (3D Environment Viewport) | RIGHT 340px |
| Location   | Photoreal Indian location             | Environment |
| Library    | architecture/streets/terrain/veg      | Intelligence|
| City ·     | vehicles/props/volumetric light       | 11 sections |
| Village ·  | measurement vectors · terrain grid    |             |
| Interior   | architectural outlines · weather     |             |
+---------------------------------------------------------------+
| BOTTOM 160px: Environment Continuity Timeline (Scenes 01-12)  |
+---------------------------------------------------------------+
| STATUS BAR                                                  |
+---------------------------------------------------------------+
```

## 3. Center — 3D Environment Viewport
- **Photoreal Indian location:** Mumbai chawl / Varanasi ghat / Jaipur haveli / Himalayan village (switchable HDR 360°)
- **Layers:** Terrain mesh + architecture + vegetation + vehicles + props + population crowds + volumetric fog + sun shafts
- **Overlays:** Floating 3D measurement vectors (cyan, length labels), terrain grid (40px, 0.06 opacity), architectural outlines (violet wireframe), weather indicators (rain streaks/fog volumes/dust haze)
- **Lighting:** Volumetric sun (5600K) + skylight (8000K) + bounce, ray-traced reflections on wet streets, atmospheric perspective (distance desaturation)
- **Interaction:** Orbit (L-drag) / Pan (M-drag) / Zoom (wheel) / Focus selected (F) / Top/Front/Side (1/3/5)

## 4. Left — Location Library 300px
Categories: **City** (Mumbai/Dharavi/Delhi) · **Village** (Kutch/Rajasthan/Kerala backwaters) · **Interior** (Haveli/Café/Police Station) · **Exterior** (Ghat/Street/Highway) · **Nature** (Desert/Jungle/Himalaya) · **Urban** (Cyber Market/Metro) · **Historical** (Fort/Temple/Mughal) · **Futuristic** (Neo-Varanasi/Orbital Ghat). Each card: thumb, name, continuity %, particle count. `+ Generate Environment` CTA green.

## 5. Right — Environment Intelligence 340px
11 sections:
**Location** (lat/long, biome) · **Time** (Golden Hour/Cyber Midnight/Neon Amber) · **Weather** (Monsoon/Dust/Acid Rain) · **Season** (Summer/Monsoon/Winter) · **Architecture** (Indo-Saracenic/Brutalist/Vernacular) · **Materials** (46: stone/wood/metal) · **Population** (340 crowds) · **Props** (128) · **Atmosphere** (fog density 75, scattering) · **Lighting** (HDR type, camera FOV 35mm anamorphic) · **Environmental Continuity** (96% gauge)
Modify any → neural particles flow core→viewport (green) + weather particles update live

## 6. Bottom — Continuity Timeline 160px
Scenes 01-12: each block shows environment thumb + weather + time. Consistency line graph 96% baseline, amber pulse on mismatch (Scene 07 Desert vs Monsoon). Click to diff drawer with location/weather/lighting delta.

## 7. Neural Particles
Environment Agent → viewport: 60 green particles at 0.08 opacity (idle) → 40% on generating, travel 0.8u/s, crystallize into terrain/arch. Weather particles: rain cyan streaks (speedY 3 + windX 1.5), dust amber haze. Horizon line at 0.65h.

## 8. AI States
`IDLE → SCOUTING_LOCATION → GENERATING_TERRAIN → POPULATING_WORLD → SIMULATING_WEATHER → VALIDATING_CONTINUITY → OPTIMIZED` (slate→cyan→green→violet→amber→green, 140ms tick).

## 9. Interaction
Click library = load + particles burst + viewport crossfade. Slider = live viewport. Right-click = Generate Variant / Weather Sim / Optimize LOD. `Ctrl+K` palette, `L` lighting, `G` generate.

## 10. Tech
Canvas 2D volumetric + particles @60fps (60 particles), grid 40px, 140ms AI tick, VRAM <300MB, <16ms slider.

*Spec 1.0 — Environment Lab — 8K 16:9 — Glass + Green/Cyan/Violet — Virtual Production*
