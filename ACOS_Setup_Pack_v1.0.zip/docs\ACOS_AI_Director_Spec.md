# ACOS AI Director Studio — Design Specification

> **Studio ID:** STUDIO-37
> **Version:** 1.0
> **Format:** Borderless 16:9 Desktop Application
> **Resolution Target:** 8K (7680 x 4320)
> **Design Language:** Dark Glass + Neural Illumination
> **Accent Color:** #EF4444 (Director Red)

---

## 1. VISUAL IDENTITY

### 1.1 Color Palette

| Role | Token | Value |
|---|---|---|
| Deep Black Base | `--studio-bg-deep` | `#05050A` |
| Midnight Navy | `--studio-bg-midnight` | `#0A0E1A` |
| Surface Glass | `--studio-glass-bg` | `rgba(10, 14, 30, 0.72)` |
| Glass Border | `--studio-glass-border` | `rgba(0, 240, 255, 0.08)` |
| Cyan Neural | `--studio-neural-cyan` | `#00F0FF` |
| Blue Neural | `--studio-neural-blue` | `#3B82F6` |
| Accent Director | `--studio-accent` | `#EF4444` |
| Director Glow | `--studio-accent-glow` | `rgba(239, 68, 68, 0.35)` |
| Surface Text | `--studio-text` | `#F0F9FF` |
| Secondary Text | `--studio-text-dim` | `#64748B` |

### 1.2 Typography

- **Display:** Orbitron (headings, labels, node names)
- **Body:** Inter (brief content, intelligence fields)
- **Mono:** JetBrains Mono (confidence scores, dependencies, pipeline telemetry)

### 1.3 Atmosphere

- Deep black background with subtle radial gradient (#0A0F1E to #05050A)
- Cyan-blue neural rim lighting on all glass panels; director-red accent on active decisions
- Abstract non-human directorial brain: faceless, geometric, neural, not a human avatar
- Floating particle dust at low opacity, director pulse radiates from central core on decisions
- 8K crisp edges, soft glass blur (24px), cinematic vignette

---

## 2. LAYOUT ARCHITECTURE

### 2.1 Full Desktop Layout (16:9)

```
+------------------------------------------------------------------+
|  LEFT: DIRECTOR BRIEF (280px) | CENTER: NEURAL DIRECTOR CORE | RIGHT: DIRECTOR INTELLIGENCE (340px) |
|  Creative Vision              |  Abstract Brain Core + 14     |  Current Decision                      |
|  Genre / Tone / Audience      |  Orbiting Agent Nodes         |  Reasoning                             |
|  Duration / Visual Identity   |  STORY SCRIPT CHARACTER ...   |  Selected Agents                       |
|                               |  Neural pulse on decision     |  Dependencies / Confidence / Approval  |
+------------------------------------------------------------------+
|  BOTTOM: LIVE PRODUCTION TIMELINE (160px) — neural pulse travels on AI decision                         |
+------------------------------------------------------------------+
```

### 2.2 Panel Specifications

| Panel | Width | Style |
|---|---|---|
| Left: Director Brief | 300px | Glass, sectioned form, collapsible |
| Center: Neural Director Core | Flex | Full canvas, 14 orbiting nodes, central abstract core |
| Right: Director Intelligence | 340px | Glass, vertical intelligence stack |
| Bottom: Production Timeline | 160px height | Glass strip, phase checkpoints, traveling pulse |

---

## 3. CENTER — ACOS NEURAL DIRECTOR CORE

### 3.1 Visual

- Central abstract brain: geometric neural lattice, not human-shaped, composed of interlocking cyan and director-red wireframe polyhedra with inner glow
- Surrounded by 14 orbiting agent nodes at two radii (inner 7, outer 7), labels: STORY, SCRIPT, CHARACTER, ENVIRONMENT, CAMERA, LIGHTING, ANIMATION, VFX, VOICE, SOUND, EDIT, COLOR, QC, RENDER
- Each node: glass chip with rounded corners, cyan border idle, director-red glow when activated by current decision
- Neural tendrils connect core to active nodes; thickness and brightness indicate selection strength
- Core pulses (scale 1.0 to 1.06) when AI transitions states
- Background: subtle grid (60x40), radial vignette, ambient cyan particles drifting

### 3.2 Interaction

- Click node to inspect agent brief; selected node scales to 1.08, glow intensifies
- Hover node shows tooltip with domain and last decision
- Click core to cycle director decisions; approval button in right panel gates execution
- Drag to orbit view subtly parallax-shifts node positions

### 3.3 Motion

- Nodes orbit slowly at distinct angular velocities (8s to 18s per revolution)
- Tendrils animate dash offset continuously; pulse travels from core outward over 900ms on state change
- Particles emit from core toward selected nodes during THINKING and DECIDING states
- Core rotation: slow 24s 360-degree drift

### 3.4 State Behavior

| AI State | Color | Core Animation | Node Behavior |
|---|---|---|---|
| IDLE | #64748B | Slow breathe | All dim, gentle drift |
| ANALYZING_BRIEF | #00F0FF | Cyan scan ring | Inner ring highlights |
| REASONING | #A855F7 | Violet pulse | Reasoning nodes brighten |
| SELECTING_AGENTS | #3B82F6 | Blue burst | Selected nodes glow red |
| DECIDING | #EF4444 | Red pulse wave | Active nodes pulse sequentially |
| AWAITING_APPROVAL | #F59E0B | Amber hold | Approval node throbs |
| EXECUTING | #10B981 | Green flow | Timeline pulse travels |
| COMPLETE | #10B981 | Steady green ring | All selected hold glow |

---

## 4. LEFT PANEL — DIRECTOR BRIEF

### 4.1 Sections

| Field | Control | Description |
|---|---|---|
| Creative Vision | Textarea | High-level directorial intent |
| Genre | Dropdown | Thriller, Action, Drama, Sci-Fi, Romance, Horror, Documentary |
| Tone | Segmented | Dark, Uplifting, Neutral, Intense, Playful |
| Audience | Chips | General, Youth, Family, Premium, Niche |
| Duration | Input | Minutes + seconds, fps hint |
| Visual Identity | Preset grid | Cinematic, Neon, Natural, Vintage, High Contrast |

### 4.2 Visual

- Glass panel with title DIRECTOR BRIEF, Orbitron 11px, letter-spacing 0.12em
- Each field row has cyan focus glow; edited fields get director-red left accent (2px)
- Visual Identity presets show miniature color strips

### 4.3 Interaction

- Editing any field triggers AI to re-enter REASONING state (debounced 600ms)
- Preset click applies instantly, core pulses, affected nodes highlight

---

## 5. RIGHT PANEL — DIRECTOR INTELLIGENCE

### 5.1 Fields

| Field | Display |
|---|---|
| Current Decision | Title + one-line summary of active directorial choice |
| Reasoning | 2-3 line chain-of-thought, updated per state |
| Selected Agents | Chip list of chosen nodes (e.g., CAMERA, LIGHTING, VFX) with confidence bars |
| Dependencies | Directed list (e.g., SCRIPT -> CHARACTER -> CAMERA) |
| Confidence | Circular gauge 0-100%, color-mapped (amber <70, cyan 70-90, green >90) |
| Approval | Approve / Revise buttons; only human actor can approve |

### 5.2 Visual

- Glass panel title DIRECTOR INTELLIGENCE, director-red accent
- Confidence gauge uses canvas or SVG arc with glow
- Selected Agents chips have per-agent mini progress bars
- Dependencies shown as vertical neural path with dots

### 5.3 Interaction

- Approve gates timeline execution; triggers EXECUTING pulse traveling across bottom timeline
- Revise returns to REASONING, core emits violet pulse

---

## 6. BOTTOM — LIVE PRODUCTION TIMELINE

### 6.1 Visual

- Horizontal glass strip spanning full width, 160px height
- Phases: STORY -> SCRIPT -> CHARACTER -> ENVIRONMENT -> CAMERA -> LIGHTING -> ANIMATION -> VFX -> VOICE -> SOUND -> EDIT -> COLOR -> QC -> RENDER
- Each phase is a checkpoint pill; completed phases filled with director-red gradient, pending outlined
- Traveling neural pulse: bright dot moves left-to-right along timeline track when AI decides or executes
- Pulse leaves fading trail (600ms)

### 6.2 Interaction

- Click checkpoint to jump intelligence panel to that phase decision
- Hover checkpoint shows tooltip with phase status and agent
- Scrub playhead drags pulse position
- Execution animates pulse from current decision phase to RENDER over 2.4s

### 6.3 Motion

- Pulse traveling uses requestAnimationFrame along bezier track, speed eased cubic-bezier(0.16,1,0.3,1)
- Phase pills scale 1.04 when pulse passes over
- Timeline track glows brighter during EXECUTING state

---

## 7. AI STATE MACHINE

```
IDLE -> ANALYZING_BRIEF -> REASONING -> SELECTING_AGENTS -> DECIDING -> AWAITING_APPROVAL -> EXECUTING -> COMPLETE
                                                            ^                           |
                                                            +---- REVISE ---------------+
```

Each transition auto-advances on interval (1.4s) except AWAITING_APPROVAL which holds until Approve clicked or auto-advance after 3.2s in demo mode.

---

## 8. PARTICLE SYSTEM

- Canvas-based neural particles: 180 count, speed 0.35-0.8, cyan base, director-red when traveling to selected nodes
- On DECIDING, burst of 24 particles emitted from core outward
- On EXECUTING, particles flow along bottom timeline track left-to-right
- Particle opacity 0.15 idle, 0.55 active, additive blending

---

## 9. TECHNICAL SPECIFICATIONS

| Metric | Target |
|---|---|
| Viewport FPS | 60fps @ 4K, 30fps @ 8K |
| Canvas particle count | 180 |
| Panel render | <16ms |
| AI state transition | <200ms visual, 1.4s logical |
| Timeline pulse travel | 2.4s |

### API Integration

```typescript
interface AIDirectorStudioAPI {
  getDirectorBrief(): DirectorBrief;
  updateDirectorBrief(patch: Partial<DirectorBrief>): void;
  getDirectorDecision(): DirectorDecision;
  getProductionTimeline(): TimelinePhase[];
  approveDecision(id: string): void;
  reviseDecision(id: string, feedback: string): void;
}
```

---

*Specification Version 1.0 — ACOS Creative Operating System*
*Design Standard: 8K, 16:9, Borderless Desktop*
*Color System: Deep Black + Midnight Navy + Cyan-Blue Neural + #EF4444 Director*
