@echo off
REM === ACOS Launcher for Windows ===
REM Usage: run-acos.bat             (offline mode)
REM        run-acos.bat --full      (start workers + app)
set ROOT=%~dp0
set MODE=offline

REM Parse arguments
for %%A in (%*) do if /I "%%~A"=="--full" set MODE=full

REM Find Python from venv scripts dir
if exist "%ROOT%.venv\Scripts\python.exe" (
    set "PYTHON_EXE=%ROOT%.venv\Scripts\python.exe"
) else (
    echo ERROR: .venv not found!
    exit /b 1
)

echo ============================================
echo   ACOS Launcher for Windows
echo   Mode: %MODE%
echo ============================================

"%PYTHON_EXE%" -m acos ui