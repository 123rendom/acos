# ACOS Voice Command Studio — Design Specification

> **Studio ID:** STUDIO-38
> **Version:** 1.0
> **Format:** Borderless 16:9 Desktop Application
> **Resolution Target:** 8K (7680 x 4320)
> **Design Language:** Dark Glass + Neural Illumination
> **Accent Color:** #10B981 (Voice Emerald)

---

## 1. VISUAL IDENTITY

### 1.1 Color Palette

| Role | Token | Value |
|---|---|---|
| Deep Black Base | `--studio-bg-deep` | `#05050A` |
| Midnight Navy | `--studio-bg-midnight` | `#0A0E1A` |
| Surface Glass | `--studio-glass-bg` | `rgba(10, 14, 30, 0.72)` |
| Glass Border | `--studio-glass-border` | `rgba(0, 240, 255, 0.08)` |
| Cyan Neural | `--studio-neural-cyan` | `#00F0FF` |
| Blue Neural | `--studio-neural-blue` | `#3B82F6` |
| Voice Emerald | `--studio-accent` | `#10B981` |
| Emerald Glow | `--studio-accent-glow` | `rgba(16, 185, 129, 0.35)` |
| Violet Think | `--studio-think` | `#A855F7` |
| Surface Text | `--studio-text` | `#F0F9FF` |
| Secondary Text | `--studio-text-dim` | `#64748B` |

### 1.2 Typography

- **Display:** Orbitron (state labels, pipeline tags)
- **Body:** Inter (history, preview descriptions)
- **Mono:** JetBrains Mono (waveform metrics, intent tokens)

### 1.3 Atmosphere

- Borderless dark glass, cyan-blue rim lighting, emerald accent pulses on voice activity
- Large circular neural command core dominates center (52% of center width)
- Audio waveform rings inside core, glass text cards float around core with command transcriptions
- 8K high-DPI waveform fidelity

---

## 2. LAYOUT ARCHITECTURE

```
+------------------------------------------------------------------+
| LEFT: COMMAND HISTORY (300px) | CENTER: NEURAL COMMAND CORE + WAVEFORM + DECOMPOSITION | RIGHT: EXECUTION PREVIEW (340px) |
| Search + history list         |  Circular core (audio rings + waveform)                |  Intent                                   |
| 4-6 past commands             |  Floating glass transcription cards                     |  Agents                                   |
| Voice trigger button          |  STORY -> CHARACTERS -> ENVIRONMENT -> CAMERA -> ...   |  Resources / Planned Actions              |
+------------------------------------------------------------------+
| BOTTOM: VOICE STATE PIPELINE (140px) — LISTENING -> UNDERSTANDING -> THINKING -> EXECUTING -> VERIFYING -> COMPLETE                                                        |
+------------------------------------------------------------------+
```

| Panel | Width | Style |
|---|---|---|
| Left: Command History | 300px | Glass, scrollable, filterable |
| Center: Neural Command Core | Flex | Canvas + DOM overlay, waveform, decomposition chain |
| Right: Execution Preview | 340px | Glass, intelligence stack |
| Bottom: State Pipeline | 140px height | Glass strip, 6-stage pipeline with traveling pulse |

---

## 3. CENTER — NEURAL COMMAND CORE

### 3.1 Visual

- Large perfect circle (320px diameter at 1080p, scales to 680px at 8K) centered in viewport
- Outer ring: conic gradient (emerald to cyan) with rotating dash when LISTENING
- Inner disc: dark glass with radial cyan glow, audio waveform rendered as circular bars emanating from center
- Central dot: pulsing core (scale 1.0 to 1.12), color maps to current voice state
- Floating glass cards: 2-3 translucent cards orbiting core edge, each showing a transcribed command example: "Create a 10-second cinematic fight scene in Mumbai during monsoon."
- Decomposition chain: horizontal pill sequence below core: STORY -> CHARACTERS -> ENVIRONMENT -> CAMERA -> ANIMATION -> VFX -> AUDIO -> RENDER, each pill lights as pipeline advances

### 3.2 Audio Waveform

- 64 circular waveform bars distributed 360 degrees, bar height driven by synthetic or mic input amplitude
- During LISTENING, bars respond to ambient waveform; during UNDERSTANDING, bars freeze then consolidate
- Bar color: emerald/cyan gradient when active, dim when idle

### 3.3 Interaction

- Click core to initiate LISTENING (simulated; no real mic required for demo, uses synthetic waveform)
- Floating card click loads that command into execution preview
- Decomposition pill click shows stage detail in right panel
- Hover core intensifies glow and expands outer ring by 4px

### 3.4 Motion

- Outer ring rotates 360 degrees over 4s during LISTENING
- Waveform bars animate via requestAnimationFrame, lerp height over 80ms
- Floating cards drift slowly on elliptical orbits (14s and 19s periods), hover pauses drift
- Decomposition chain: pills light sequentially left-to-right as EXECUTING progresses (stagger 180ms)
- Core pulse: scale keyframe `neural-pulse` 1.8s infinite, intensity by state

---

## 4. LEFT PANEL — COMMAND HISTORY

### 4.1 Content

| Entry | Fields |
|---|---|
| Timestamp | JetBrains Mono 9px, dim |
| Transcription | Inter 13px, primary, truncated to 2 lines |
| Status badge | LISTENING / EXECUTED / VERIFIED / COMPLETE |
| Duration | Mono 9px, seconds |

- Top search/filter input (cyan focus glow)
- 5 history entries pre-populated with varied commands
- Selected entry has emerald left border (2px) and background `rgba(16,185,129,0.08)`
- Mic trigger button at bottom: large emerald pill "Hold to Speak" (simulated)

### 4.2 Interaction

- Click history entry loads its transcription into core and triggers UNDERSTANDING flow
- Search filters entries in real time
- Trigger button cycles through voice states on click (demo mode: auto-cycles)

---

## 5. RIGHT PANEL — EXECUTION PREVIEW

### 5.1 Sections

| Section | Content |
|---|---|
| Intent | One-line inferred goal + confidence % and domain tags |
| Agents | Chip list of selected agents with role and readiness dot |
| Resources | Required engines, estimated time, queue position |
| Planned Actions | Ordered numbered list of actions that will execute |

### 5.2 Visual

- Glass panel title EXECUTION PREVIEW, emerald accent
- Intent confidence bar: emerald fill, animated on state change
- Agents chips: cyan border idle, emerald when selected for current command
- Resources shown as compact metric rows (label mono 9px, value 11px)
- Planned Actions numbered circles with connecting vertical line

### 5.3 Interaction

- Execute button (emerald solid) triggers EXECUTING state, starts decomposition chain illumination and timeline pulse
- Cancel returns to LISTENING
- Hover planned action highlights corresponding decomposition pill

---

## 6. VOICE STATE PIPELINE

### 6.1 State Definitions

| State | Color | Core Visual | Description |
|---|---|---|---|
| LISTENING | #10B981 / #00F0FF | Green-cyan rotating ring, waveform active | Awaiting voice input |
| UNDERSTANDING | #06B6D4 | Cyan consolidating waveform, ring narrows | Transcribing and parsing |
| THINKING | #A855F7 | Violet pulse, particles converge | Agent reasoning |
| EXECUTING | #00F0FF streams | Cyan particle streams along pipeline | Running planned actions |
| VERIFYING | #F59E0B | Amber checkpoint glow | Validating outputs |
| COMPLETE | #10B981 | Steady green ring, success burst | Finished, ready for next |

### 6.2 Bottom Pipeline Visual

- 6 stage pills connected by track line across bottom glass strip
- Active stage scales 1.06, border glow matches state color, subtle shadow
- Traveling dot moves between stages as state advances (600ms transition)
- Stage labels Orbitron 9px, mono timestamp below
- Particles stream along track during EXECUTING (cyan dots, 2.4px, 60% opacity)

### 6.3 State Progression

- Auto-progress via interval 1.6s per state in demo; LISTENING holds 2.2s, COMPLETE holds 2.8s then loops to LISTENING
- Each transition emits waveform burst and core color shift via CSS transition 400ms cubic-bezier(0.16,1,0.3,1)

---

## 7. PARTICLE SYSTEM

- Canvas particles: 140 count, emerald/cyan palette, speed 0.4-0.9
- During EXECUTING, particles form directed streams along the decomposition chain and bottom pipeline
- On COMPLETE, burst of 28 emerald particles from core outward
- Idle ambient opacity 0.12, active stream opacity 0.55

---

## 8. TECHNICAL SPECIFICATIONS

| Metric | Target |
|---|---|
| Viewport FPS | 60fps |
| Canvas particle count | 140 |
| Waveform bars | 64 circular |
| State transition | <200ms visual, 1.6s logical |

### API Integration

```typescript
interface VoiceCommandStudioAPI {
  startListening(): void;
  getCommandHistory(): VoiceCommand[];
  getExecutionPreview(commandId: string): ExecutionPreview;
  executeCommand(commandId: string): void;
  getVoiceState(): VoiceState;
}
```

---

*Specification Version 1.0 — ACOS Creative Operating System*
*Design Standard: 8K, 16:9, Borderless Desktop*
*Color System: Deep Black + Midnight Navy + Cyan-Blue Neural + #10B981 Voice*
