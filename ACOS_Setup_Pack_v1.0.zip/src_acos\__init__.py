"""Backward-compatibility shim: acos -> acos_engine.

This module exists solely to prevent import breakage in any code that still
imports from acos.* instead of acos_engine.*.  The entire acos package
was renamed to acos_engine during the DILAAVAR restructure (Phase 1).
All internal imports (from acos.core.ids import ..., etc.) continue to work
because this shim resolves acos to acos_engine at runtime.

Architecture rule: this shim is load-bearing only during the transition window.
New code should import acos_engine.* directly.
"""

from __future__ import annotations

import sys as _sys
import types as _types

# acos IS acos_engine -- resolve the shim immediately.
import acos_engine as _acos_engine

# Install acos_engine into sys.modules under the acos key so that
# from acos.core.ids import EngineId etc. all resolve correctly.
_sys.modules["acos"] = _acos_engine  # type: ignore[attr-defined]

# Propagate ALL sub-packages as module attributes AND sys.modules entries so that
# acos.server IS acos_engine.server (same object, not a copy).
# Without this, Python creates a separate acos.server package and the test
# monkeypatch on acos.server._stream_local_llm has no effect on the actual
# acos_engine.server._stream_local_llm used by the server handler.
for _key in dir(_acos_engine):
    if _key.startswith("_"):
        continue
    try:
        _sub = getattr(_acos_engine, _key)
    except AttributeError:
        continue
    if isinstance(_sub, _types.ModuleType):
        # Set as attribute on acos (which IS acos_engine) so
        # acos.server -> acos_engine.server without creating a new module
        object.__setattr__(_acos_engine, _key, _sub)
        # Also set sys.modules entry (redundant but safe)
        _sys.modules[f"acos.{_key}"] = _sub  # type: ignore[attr-defined]

__all__ = ["acos_engine"]
__path__ = _acos_engine.__path__
__file__ = _acos_engine.__file__
