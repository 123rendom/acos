# ACOS Story Architect Studio — Design Specification

> **Studio ID:** STUDIO-03
> **Version:** 1.0 · **Format:** Borderless 16:9 Desktop · **Resolution:** 8K · **Language:** Dark Glass + Neural Core + Floating Story Structures

## 1. Visual Identity
| Token | Value |
|---|---|
| --acos-bg-deep | `#05050A` |
| --acos-bg-navy | `#0A0E1A` |
| --acos-glass | `rgba(10,14,30,0.72)` + `blur(20px)` + border `rgba(0,240,255,0.08)` |
| --acos-cyan | `#00F0FF` (connections, pulses) |
| --acos-violet | `#9D7BFF` (Act II, suspense, core halo) |
| --acos-amber | `#F59E0B` (stakes, cultural) |
| --acos-green | `#10B981` (validated) |
| --acos-magenta | `#D35DB8` (characters/emotion) |

Typography Orbitron (titles) · Inter (body) · JetBrains Mono (stats). 8K photorealistic, cinematic depth, volumetric light.

## 2. Layout 16:9
```
+---------------------------------------------------------------+
| APP BAR                                                     |
+---------------------------------------------------------------+
| LEFT 280px | CENTER flex (Story Universe Map) | RIGHT 340px |
| Projects   | Neural Core + 10 node ring       | Story AI    |
| Concepts   | Act I · Act II · Act III         | Agent       |
| Genres     | floating glass structures         | 8 sliders   |
| Themes     | connected by energy lines         | Hindi/Indian|
| Templates  |                                   | labels      |
| AI Ideas   |                                   |             |
+---------------------------------------------------------------+
| BOTTOM 160px: Emotional Arc Graph + Story Progression Timeline|
+---------------------------------------------------------------+
| STATUS BAR                                                  |
+---------------------------------------------------------------+
```
All panels `backdrop-filter: blur(20px)`, `rgba(8,12,24,0.82)`.

## 3. Center — Story Universe Map
Central neural core (radial cyan→violet, breathing 3.2s) + 10 orbiting nodes:
**Premise · Theme · Characters · Conflict · Locations · Timeline · Events · Emotional Arc · Stakes · Ending**
- Nodes: 36px circles, glass + color pulse per type, bezier connections (0.08→0.25 opacity, animated dash)
- Secondary: 3 Act structures as large floating glass blocks (Act I 25% / Act II 50% / Act III 25% width, heights 80/55/35%)
- AI modifies narrative → particles (12 per edge) travel along pathways from core to target node, new branches grow as thin cyan filaments that crystallize
- Selection illuminates related nodes (cyan ring + amber pulse on dependencies)

## 4. Left — Story Library 280px
Projects (4) · Concepts (6) · Genres [Drama, Thriller, Romance, Mythology, Sci-Fi, Comedy] · Themes [Family, Honor, Love, Revenge, Fate] · Templates [3-Act, Hero Journey, Kishōtenketsu, Panchtantra] · AI Ideas (Generate Premise / Expand Act / Twist)
Glass list items, left accent 3px on active, hover `rgba(0,240,255,0.06)`.

## 5. Right — Story AI Agent 340px
8 controls (0-100 sliders, track `#2A2A40` fill `#9D7BFF`→`#00F0FF`):
Originality · Emotional Intensity · Pacing · Character Motivation · Conflict · Suspense · Cultural Authenticity · Cinematic Potential
+ Indian labels badges: `Hindi Dialogue` `Indian Locations` `Cultural Context` `Emotion` `Audience` (amber outline)
+ Confidence gauge (0-98%), Generate / Refine / Validate CTA (`#9D7BFF`).

## 6. Bottom — Emotional Arc + Timeline 160px
Left 55%: Emotional Arc graph — SVG bezier (6 points) with gradient fill `rgba(157,123,255,0.12)`, tension overlay, Y 0-100 (Despair→Euphoria), X Act markers. Right 45%: Story Progression Timeline — dots for Beat/Scene, progress bar `9D7BFF→00F0FF`, time `00:00/02:14:00`.
Hover tooltip: beat name + emotion + characters involved.

## 7. AI Agent States
`IDLE → ANALYZING_STORY → GENERATING_BRANCH → WEAVING_ARC → VALIDATING_CULTURE → OPTIMIZED` (colors slate→cyan→violet→cyan→green). Particles 80 at 60fps during generation, settle on validated.

## 8. Interaction
Orbit/pan on map, click node = select + propagate, drag node = reposition (spring), double-click = edit detail drawer, right-click = Generate Variant / Check Cultural Authenticity / Hindi Dialogue. `Ctrl+K` palette, `F` focus mode, `Ctrl+Z` undo (history stream `13:42 Story branch expanded`).

## 9. Motion
Panel slide 300ms ease-out, node spring 400ms, particle travel 0.8-2.0u/s, arc morph 600ms, core breathe 3.2s idle / 1.4s thinking / 0.7s executing. Reduced Motion → 80ms opacity only.

## 10. Tech
Canvas 2D (core+nodes+particles) @60fps, virtualized left list, debounced sliders (16ms), worker for AI generation, VRAM <200MB for graph, <16ms slider feedback.

*Spec 1.0 — ACOS Creative OS — 8K 16:9 Borderless — Neural Core + Glass + Cyan-Violet + Indian Cinematic*
