// electron/main.js - Electron Main Process for ACOS
const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');

const BRIDGE_PORT = 8980;
const BRIDGE_POLL_ATTEMPTS = 30;
const BRIDGE_POLL_INTERVAL_MS = 500;

// Fix Windows Chromium GPU & Disk Cache lock / permission errors (0x5 Access Denied)
app.commandLine.appendSwitch('disable-gpu-shader-disk-cache');
app.commandLine.appendSwitch('disable-http-cache');

let mainWindow;
let pythonProcess = null;

// ---------------------------------------------------------------------------
// Bridge health check (with fast timeout)
// ---------------------------------------------------------------------------
function checkBridgeOnline() {
  return new Promise((resolve) => {
    const req = http.get(`http://127.0.0.1:${BRIDGE_PORT}/api/health`, (res) => {
      res.resume();
      resolve(res.statusCode === 200);
    });
    req.on('error', () => resolve(false));
    req.setTimeout(1000, () => {
      req.destroy();
      resolve(false);
    });
  });
}

// ---------------------------------------------------------------------------
// Start the Python bridge; wait until it answers /api/health or give up.
// ---------------------------------------------------------------------------
async function startPythonBridge() {
  if (await checkBridgeOnline()) {
    console.log(`[ACOS Electron] Bridge server already online on ${BRIDGE_PORT}`);
    return true;
  }

  console.log('[ACOS Electron] Spawning Python ACOS Bridge Server...');
  // In dev, __dirname = <repo>/electron. Packaged, __dirname lives inside app.asar,
  // so the bridge + python runtime must come from process.resourcesPath (extraResources).
  const resourcesDir = app.isPackaged ? process.resourcesPath : path.join(__dirname, '..');
  const projectSrc = app.isPackaged ? resourcesDir : path.join(__dirname, '..', 'src');

  const pythonCandidates = app.isPackaged
    ? [
        path.join(resourcesDir, 'python', 'python.exe'),   // bundled portable python (optional)
        path.join(resourcesDir, '.venv', 'Scripts', 'python.exe'),
      ]
    : [path.join(__dirname, '..', '.venv', 'Scripts', 'python.exe')];
  const pythonExe = pythonCandidates.find((p) => fs.existsSync(p)) || 'python';
  const serverScriptCandidates = [
    path.join(projectSrc, 'acos_engine', 'server', 'bridge.py'),
    path.join(projectSrc, 'acos', 'server', 'bridge.py'),
  ];
  const serverScript = serverScriptCandidates.find((p) => fs.existsSync(p)) || serverScriptCandidates[0];

  console.log(`[ACOS Electron] Bridge python: ${pythonExe}`);
  console.log(`[ACOS Electron] Bridge script: ${serverScript}`);

  pythonProcess = spawn(pythonExe, [serverScript, String(BRIDGE_PORT)], {
    cwd: resourcesDir,
    env: { ...process.env, PYTHONPATH: projectSrc },
    stdio: 'ignore',
  });

  pythonProcess.on('error', (err) => {
    console.error('[ACOS Electron] Failed to spawn Python bridge:', err);
  });

  // Wait for the bridge to become reachable before creating the window.
  for (let i = 0; i < BRIDGE_POLL_ATTEMPTS; i += 1) {
    await new Promise((r) => setTimeout(r, BRIDGE_POLL_INTERVAL_MS));
    if (await checkBridgeOnline()) {
      console.log('[ACOS Electron] Bridge is ready.');
      return true;
    }
  }
  console.warn('[ACOS Electron] Bridge did not become ready in time; UI will show offline state.');
  return false;
}

// ---------------------------------------------------------------------------
// Clean shutdown of spawned Python process
// ---------------------------------------------------------------------------
function stopPythonBridge() {
  if (pythonProcess) {
    console.log('[ACOS Electron] Terminating Python Bridge Process...');
    try {
      pythonProcess.kill('SIGTERM');
      setTimeout(() => {
        if (pythonProcess) {
          try { pythonProcess.kill('SIGKILL'); } catch (e) { /* ignore */ }
          pythonProcess = null;
        }
      }, 2000);
    } catch (e) {
      console.error('[ACOS Electron] Error stopping Python process:', e);
    }
    pythonProcess = null;
  }
}

// ---------------------------------------------------------------------------
// Native Application Menu (Section 2 & Section 35)
// ---------------------------------------------------------------------------
function buildApplicationMenu() {
  const template = [
    {
      label: 'File',
      submenu: [
        { label: 'New Project', accelerator: 'CmdOrCtrl+N', click: () => { mainWindow?.webContents.send('menu-command', 'new-project'); } },
        { label: 'Open Project', accelerator: 'CmdOrCtrl+O', click: () => { mainWindow?.webContents.send('menu-command', 'open-project'); } },
        { type: 'separator' },
        { role: 'quit' }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
        { role: 'selectAll' }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' }
      ]
    },
    {
      label: 'Help',
      submenu: [
        { label: 'ACOS Documentation', click: () => { shell.openExternal('http://127.0.0.1:8980/api/health'); } },
        { type: 'separator' },
        { label: 'About ACOS Enterprise', click: () => {
          if (mainWindow) {
            mainWindow.webContents.executeJavaScript('alert("ACOS — AI Creative Operating System Enterprise v1.0.0\\nLocal-First Desktop Studio");');
          }
        }}
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ---------------------------------------------------------------------------
// Window creation with GPU-failure fallback & Security Restrictions (Section 32)
// ---------------------------------------------------------------------------
function createWindow() {
  const webPreferences = {
    nodeIntegration: false,
    contextIsolation: true,
    webSecurity: true,
    spellcheck: false,
    sandbox: true,
  };

  mainWindow = new BrowserWindow({
    width: 1600,
    height: 1000,
    minWidth: 1200,
    minHeight: 800,
    show: false,
    backgroundColor: '#0a0b0e',
    title: 'ACOS — AI Creative Operating System',
    webPreferences,
  });

  // Security: Content Security Policy
  mainWindow.webContents.session.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        'Content-Security-Policy': [
          "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self' http://127.0.0.1:8980 http://localhost:5173;"
        ],
      },
    });
  });

  // Critical: bypass the system proxy for all localhost traffic (NN-01).
  mainWindow.webContents.session.setProxy({
    proxyRules: 'direct://',
    proxyBypassRules: 'localhost;127.0.0.1;<local>',
  });

  // Section 32: Secure origin validation & link protection
  mainWindow.webContents.on('will-navigate', (event, url) => {
    const parsedUrl = new URL(url);
    if (parsedUrl.origin !== 'http://localhost:5173' && parsedUrl.protocol !== 'file:') {
      event.preventDefault();
      console.warn(`[ACOS Security] Navigation blocked to external origin: ${url}`);
    }
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http://') || url.startsWith('https://')) {
      shell.openExternal(url);
    }
    return { action: 'deny' };
  });

  const isDev = process.env.NODE_ENV === 'development' || process.argv.includes('--dev');

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
  } else {
    const loadProduction = async () => {
      console.log('[ACOS Electron] Starting in production mode...');
      const fs = require('fs');
      const indexPath = path.join(__dirname, '..', 'build', 'index.html');
      const fallbackPath = path.join(__dirname, '..', 'build', 'fallback_offline.html');

      if (fs.existsSync(indexPath)) {
        mainWindow.loadFile(indexPath);
      } else if (fs.existsSync(fallbackPath)) {
        mainWindow.loadFile(fallbackPath);
      } else {
        console.error('[ACOS Electron] CRITICAL: Neither index.html nor fallback_offline.html exists in build directory.');
      }
    };
    loadProduction();
  }

  // Graceful GPU fallback (Section 2)
  let gpuFallbackDone = false;
  const relaunchSoftware = () => {
    if (gpuFallbackDone) return;
    gpuFallbackDone = true;
    console.warn('[ACOS Electron] GPU process crashed; relaunching in software rendering mode.');
    try { mainWindow.destroy(); } catch (e) { /* noop */ }
    app.commandLine.appendSwitch('disable-gpu');
    app.commandLine.appendSwitch('disable-gpu-compositing');
    app.relaunch();
    app.quit();
  };

  mainWindow.webContents.on('render-process-gone', (event, details) => {
    if (details.reason === 'crashed' || details.reason === 'gpu-process-exited') {
      relaunchSoftware();
    }
  });
  app.on('child-process-gone', (event, details) => {
    if (details.type === 'GPU') relaunchSoftware();
  });

  mainWindow.webContents.on('did-fail-load', (e, code, desc) => {
    console.error('[ACOS Electron] Failed to load URL:', desc, `(code ${code})`);
  });

  mainWindow.webContents.on('console-message', (e, level, message, line, sourceId) => {
    console.log(`[Renderer Console] ${message}`);
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });
}

app.whenReady().then(async () => {
  buildApplicationMenu();
  await startPythonBridge();
  createWindow();
});

app.on('before-quit', () => {
  stopPythonBridge();
});

app.on('window-all-closed', () => {
  stopPythonBridge();
  if (process.platform !== 'darwin') {
    app.quit();
  }
});