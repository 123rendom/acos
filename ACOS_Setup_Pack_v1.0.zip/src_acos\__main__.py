"""Backward-compat: ``python -m acos`` -  ``python -m acos_engine``."""

from acos_engine.__main__ import *

# Re-export everything so the entry-point signature is unchanged.
