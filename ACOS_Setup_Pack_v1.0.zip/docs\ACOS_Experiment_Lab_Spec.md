# ACOS Experiment / Creative Lab Studio — Design Specification

> **Studio ID:** STUDIO-36
> **Version:** 1.0
> **Format:** Borderless 16:9 Desktop Application
> **Resolution Target:** 8K (7680 x 4320)
> **Design Language:** Dark Glass + Neural Branching + Creative Violet

---

## 1. VISUAL IDENTITY

### 1.1 Color Palette

| Role | Token | Value |
|---|---|---|
| Deep Black Base | `--studio-bg-deep` | `#05050A` |
| Midnight Navy | `--studio-bg-midnight` | `#0A0E1A` |
| Surface Glass | `--studio-glass-bg` | `rgba(10, 14, 30, 0.72)` |
| Glass Border | `--studio-glass-border` | `rgba(0, 240, 255, 0.08)` |
| Experiment Accent | `--studio-experiment` | `#8B5CF6` |
| Experiment Glow | `--studio-experiment-glow` | `rgba(139, 92, 246, 0.35)` |
| Branch A | `--studio-branch-a` | `#8B5CF6` |
| Branch B | `--studio-branch-b` | `#00F0FF` |
| Branch C | `--studio-branch-c` | `#F59E0B` |
| Neural Cyan | `--studio-cyan` | `#00F0FF` |
| Neural Blue | `--studio-blue` | `#3B82F6` |
| Success Green | `--studio-success` | `#10B981` |
| Surface Text | `--studio-text` | `#F0F9FF` |
| Secondary Text | `--studio-text-dim` | `#64748B` |

### 1.2 Typography

- **Display:** Orbitron (headings, branch labels)
- **Body:** Inter (descriptions, controls)
- **Mono:** JetBrains Mono (scores, version tags)

### 1.3 Atmosphere

- Deep black background with violet-cyan bi-tone illumination
- Experiment violet `#8B5CF6` for active branch, recommendation, approval states
- Dark glass panels `backdrop-filter: blur(20px)` with cyan border at 0.08 opacity
- Branching particle rivers from central neural core splitting into A/B/C
- Grid pulse and radial vignette, scanline at 6% opacity

---

## 2. LAYOUT ARCHITECTURE

### 2.1 Full Desktop Layout (16:9)

```
+------------------------------------------------------------------+
|  APPLICATION BAR (ACOS Shell)                                    |
+------------------------------------------------------------------+
| LEFT: EXPERIMENT     |  CENTER: EXPERIMENTAL VIEWPORT              | RIGHT: EVALUATION        |
| BROWSER              |  Branching viewport with neural core        | PANEL                   |
| 280px glass          |  Flex - canvas + branch cards               | 320px glass             |
|                      |                                             |                         |
| Experiments          |  [Neural Core]                              |  Originality 82%        |
| Visual Styles        |       | | |                                 |  Cinematic Impact 91%   |
| Camera Ideas         |       v v v                                 |  Emotional Impact 88%   |
| Story Variations     |  [Branch A] [Branch B] [Branch C]           |  Technical Cost 45%     |
| VFX Tests            |  Purple     Cyan       Amber                |  Consistency 79%        |
| Character Tests      |  Preview    Preview    Preview              |  Recommendation:        |
| Audio Tests          |  Score 8.4  Score 7.9  Score 8.1            |  [Branch A - Strong]    |
|                      |                                             |  [Approve] [Merge]      |
+----------------------+---------------------------------------------+-------------------------+
| BOTTOM: VERSION COMPARISON TIMELINE (150px glass strip)                                         |
| V1 [A][B][C] | V2 [A][B][C] | V3 [A][B][C] | Compare | Approve | Reject | Merge              |
| Branch labels, score bars, status pills (PENDING / APPROVED / REJECTED / MERGED)               |
+------------------------------------------------------------------+
| STATUS BAR                                                       |
+------------------------------------------------------------------+
```

### 2.2 Panel Specifications

| Panel | Width | Style |
|---|---|---|
| Left: Experiment Browser | 280px | Glass, violet accent on active category, nested branch counts |
| Center: Branching Viewport | Flex | Canvas with core + 3 branch columns, preview cards, particle rivers |
| Right: Evaluation | 320px | Glass, score sliders/bars, recommendation card, action buttons |
| Bottom: Version Timeline | 150px height | Glass strip, version blocks with branch pills, action toolbar |

---

## 3. CENTER VIEWPORT — BRANCHING EXPERIMENTAL VIEWPORT

### 3.1 Neural Core

- Central orb at top-center of viewport, radius 26px, gradient violet->cyan, pulse scale 0.96-1.08, glow `0 0 28px rgba(139,92,246,0.45)`
- Label "NEURAL CORE" Orbitron 9px violet, state badge below (Orbitron 10px)
- Emits three branching particle rivers downward to Branch A/B/C columns

### 3.2 Branch Columns

| Branch | Accent | Position | Preview Style |
|---|---|---|---|
| Version A | `#8B5CF6` violet | Left 28% | Violet border, score 8.4, status pill |
| Version B | `#00F0FF` cyan | Center 50% | Cyan border, score 7.9, status pill |
| Version C | `#F59E0B` amber | Right 72% | Amber border, score 8.1, status pill |

Each branch column:
- Preview card: 220x140 placeholder with gradient (violet/cyan/amber tint), version label (A/B/C) Orbitron 24px, status badge top-right (PENDING/APPROVED/REJECTED/MERGED)
- Score bar: 4px height, fill accent color, width = score/10 * 100%
- Action row: [View] [Promote] mini buttons, ghost style, accent border on hover
- Selection: click branch card selects it as active evaluation target (right panel updates)

### 3.3 Particle Rivers

- Each river: 25 particles, color matching branch accent, spawn at core edge, travel along curved path to branch card top edge, speed 2.0 px/frame, size 2.5px circle with glow
- Rivers converge intensity with AI state: ANALYZING (slow), GENERATING (fast), VALIDATED (settled, particles orbit branch cards)
- Ambient particles: 50 drifting `rgba(0,240,255,0.06)` background

---

## 4. LEFT PANEL — EXPERIMENT BROWSER

### 4.1 Categories

| Category | Color | Branch Count | Description |
|---|---|---|---|
| Experiments | `#8B5CF6` | 12 | General experiment queue |
| Visual Styles | `#EC4899` | 9 | Look development variants |
| Camera Ideas | `#3B82F6` | 7 | Framing and lens experiments |
| Story Variations | `#F59E0B` | 11 | Narrative branching |
| VFX Tests | `#06B6D4` | 8 | Effects technique tests |
| Character Tests | `#10B981` | 6 | Performance variant tests |
| Audio Tests | `#64748B` | 5 | Sound design variants |

### 4.2 Row Style

- Glass row, 10px gap, 6px radius, left bar 2px transparent -> `#8B5CF6` on active
- Color dot 10px circle glow `0 0 8px <color>`
- Label Inter 13px `#F0F9FF`
- Count badge JetBrains Mono 9px violet bg `rgba(139,92,246,0.15)` text `#8B5CF6`
- Subtext: "3 branches" dim 9px when expanded
- Click selects category and filters center to show only relevant branches (center shows 3 generic branches for demo, label updates per category)

---

## 5. RIGHT PANEL — EVALUATION

### 5.1 Score Metrics

| Metric | Range | Color | Weight |
|---|---|---|---|
| Originality | 0-100 | `#8B5CF6` | 25% |
| Cinematic Impact | 0-100 | `#00F0FF` | 25% |
| Emotional Impact | 0-100 | `#EC4899` | 20% |
| Technical Cost | 0-100 (inverse) | `#F59E0B` | 15% |
| Consistency | 0-100 | `#10B981` | 15% |

Each metric:
- Label JetBrains Mono 10px dim, value 12px accent bold
- Progress bar height 6px, gradient accent->tinted, glow on fill head
- Slider control (range input) for manual override, thumb accent color

### 5.2 Recommendation

- Card with gradient violet `rgba(139,92,246,0.1)` border violet 0.25
- Title "RECOMMENDATION" Orbitron 10px violet
- Verdict: "Branch A — Strong Approve" Inter 13px `#F0F9FF` with confidence pill "92% confidence" violet
- Rationale sentence: Inter 11px dim, e.g., "Highest cinematic + emotional blend with manageable cost."
- Action buttons: [Approve] violet primary, [Reject] ghost, [Merge] cyan outline
- Approve moves branch status to APPROVED, updates timeline pill green; Reject red; Merge creates merged version node in center with blended color

---

## 6. BOTTOM PANEL — VERSION COMPARISON TIMELINE

### 6.1 Version Blocks

- Horizontal timeline with version segments V1, V2, V3 (each contains A/B/C pills)
- Each version block: label Orbitron 10px `#64748B`, row of 3 branch pills (20px height, accent bg 0.15, border 0.25, label "A 8.4" etc.)
- Status pill per branch: PENDING gray, APPROVED green, REJECTED red, MERGED violet-cyan gradient
- Connector lines between versions: cyan `rgba(0,240,255,0.2)` 1px, merge connectors violet 2px solid with merge icon
- Current version indicator: cyan playhead line with glow

### 6.2 Action Toolbar

- Controls at right of timeline: [Compare] (diff overlay for selected branches), [Approve], [Reject], [Merge] — all styled as ghost pills with accent borders, Compare uses violet-cyan gradient
- Compare mode: center viewport shows side-by-side branch cards with diff highlights (amber for changed pixels proxy, cyan for added)
- Legend row: "VIOLET = Originality leader | CYAN = Cinematic leader | AMBER = Cost leader"

---

## 7. AI LAB AGENT

### 7.1 State Machine

```
IDLE -> ANALYZING_EXPERIMENTS -> GENERATING_VARIANTS -> EVALUATING -> RECOMMENDING -> VALIDATED
```

- **IDLE:** Core dim 40% opacity, rivers paused, ambient drift only
- **ANALYZING_EXPERIMENTS:** Core cyan pulse, rivers start trickling violet/cyan/amber
- **GENERATING_VARIANTS:** Rivers accelerate, branch cards shimmer, scores animate from 0 to target
- **EVALUATING:** Right panel bars fill with easing, recommendation card fades in
- **RECOMMENDING:** Branch A card pulsates violet glow, recommendation pill brightens
- **VALIDATED:** All rivers settle into orbit rings around branch cards, core green-tinged validation ring

Auto-advances via interval (130ms tick +1.1% progress). Category change or branch action resets to ANALYZING_EXPERIMENTS.

---

## 8. INTERACTION PATTERNS

### 8.1 Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `1-7` | Select category 1-7 |
| `A/B/C` | Select branch A/B/C |
| `Space` | Cycle AI state |
| `Enter` | Approve selected branch |
| `R` | Reject selected branch |
| `M` | Merge selected branches |
| `Cmd+Z` | Undo branch action |

### 8.2 Mouse Interactions

| Action | Button |
|---|---|
| Select category | Click left row |
| Select branch | Click branch card |
| Adjust metric | Drag slider thumb |
| Approve/Reject/Merge | Click action button |
| Compare branches | Click Compare, then select 2 branches |
| Scrub version timeline | Drag playhead |

---

## 9. MOTION & ANIMATION

- Category row highlight 150ms ease
- Branch card selection scale 1.02 + glow intensify 200ms ease-out
- Particle rivers 60fps canvas, additive blending, bezier paths
- Score bar fill 700ms ease-out
- Recommendation card fade-in 300ms ease
- Version pill pulse on status change 1.2s ease-in-out
- Core pulse 1.6s ease-in-out infinite

---

## 10. TECHNICAL SPECIFICATIONS

| Metric | Target |
|---|---|
| Viewport FPS | 60fps @ 4K with 125 particles |
| Branch Cards | 3 columns @ 60fps with hover |
| Canvas | DPR scaled, 8K ready |
| Score Update | < 16ms |
| Timeline Scrub | 120fps interpolation |
| AI Cycle | ~9s full progression |

---

## 11. DESIGN COHERENCE

Shares ACOS DNA: Neural Core, Glass Surfaces, Branching Rivers, Orbitron/Inter/JetBrains Mono, DesignTokens, cyan-blue base + experiment violet `#8B5CF6` accent.

---

*Specification Version 1.0 — ACOS Creative Operating System*
*Design Standard: 8K, 16:9, Borderless Desktop*
*Color System: Deep Black + Midnight Navy + Experiment Violet + Neural Cyan-Blue*
