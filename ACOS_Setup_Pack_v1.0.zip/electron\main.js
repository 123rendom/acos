// electron/main.js - Electron Main Process for ACOS
const { app, BrowserWindow } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const http = require('http');

const BRIDGE_PORT = 8980;
const BRIDGE_POLL_ATTEMPTS = 20;
const BRIDGE_POLL_INTERVAL_MS = 500;

let mainWindow;
let pythonProcess = null;

// ---------------------------------------------------------------------------
// Bridge health check (with fast timeout)
// ---------------------------------------------------------------------------
function checkBridgeOnline() {
  return new Promise((resolve) => {
    const req = http.get(`http://127.0.0.1:${BRIDGE_PORT}/api/health`, (res) => {
      res.resume();
      resolve(res.statusCode === 200);
    });
    req.on('error', () => resolve(false));
    req.setTimeout(1000, () => {
      req.destroy();
      resolve(false);
    });
  });
}

// ---------------------------------------------------------------------------
// Start the Python bridge; wait until it answers /api/health or give up.
// ---------------------------------------------------------------------------
async function startPythonBridge() {
  if (await checkBridgeOnline()) {
    console.log(`[ACOS Electron] Bridge server already online on ${BRIDGE_PORT}`);
    return true;
  }

  console.log('[ACOS Electron] Spawning Python ACOS Bridge Server...');
  const pythonExe = path.join(__dirname, '..', '.venv', 'Scripts', 'python.exe');
  const serverScript = path.join(__dirname, '..', 'src', 'acos', 'server', 'bridge.py');
  const serverScriptCandidates = [
      path.join(__dirname, '..', 'src', 'acos_engine', 'server', 'bridge.py'),
      path.join(__dirname, '..', 'src', 'acos', 'server', 'bridge.py'),
  ];
  const serverScript = serverScriptCandidates.find((s) => fs.existsSync(s)) || serverScriptCandidates[0];

  pythonProcess = spawn(pythonExe, [serverScript, String(BRIDGE_PORT)], {
    cwd: path.join(__dirname, '..'),
    env: { ...process.env, PYTHONPATH: path.join(__dirname, '..', 'src') },
    stdio: 'ignore',
  });

  pythonProcess.on('error', (err) => {
    console.error('[ACOS Electron] Failed to spawn Python bridge:', err);
  });

  // Wait for the bridge to become reachable before creating the window.
  for (let i = 0; i < BRIDGE_POLL_ATTEMPTS; i += 1) {
    await new Promise((r) => setTimeout(r, BRIDGE_POLL_INTERVAL_MS));
    if (await checkBridgeOnline()) {
      console.log('[ACOS Electron] Bridge is ready.');
      return true;
    }
  }
  console.warn('[ACOS Electron] Bridge did not become ready in time; UI will show offline state.');
  return false;
}

// ---------------------------------------------------------------------------
// Window creation with GPU-failure fallback
// ---------------------------------------------------------------------------
function createWindow() {
  const webPreferences = {
    nodeIntegration: false,
    contextIsolation: true,
    webSecurity: true,
    spellcheck: false,
  };

  mainWindow = new BrowserWindow({
    width: 1600,
    height: 1000,
    minWidth: 1200,
    minHeight: 800,
    show: false,
    backgroundColor: '#0a0b0e',
    title: 'ACOS — AI Creative Operating System',
    // Borderless-but-safe: hide the native title bar so the Shell's custom
    // titlebar (CSS drag region) drives the frame; native window controls
    // (min/max/close) remain available on hover. autoHideMenuBar keeps the
    // menu out of the way without disabling it.
    titleBarStyle: 'hidden',
    autoHideMenuBar: true,
    webPreferences,
  });

  // Critical: bypass the system proxy for all localhost traffic. Chromium's
  // fetch() honours the OS proxy, so a configured/misbehaving system proxy
  // breaks renderer requests to 127.0.0.1:8980 ("TypeError: Failed to fetch")
  // even though the bridge is healthy.
  mainWindow.webContents.session.setProxy({
    proxyRules: 'direct://',
    proxyBypassRules: 'localhost;127.0.0.1;<local>',
  });

  const isDev = process.env.NODE_ENV === 'development' || process.argv.includes('--dev');

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
  } else {
    // Production load with startup fallback: Wait for bridge before showing window.
    const loadProduction = async () => {
      console.log('[ACOS Electron] Attempting to start in production mode...');

      // Give the bridge a generous time (10s) to start up and become available.
      await new Promise(resolve => setTimeout(resolve, 2000)); // Wait initial burst period

      if (await checkBridgeOnline()) {
          mainWindow.loadFile(path.join(__dirname, '..', 'build', 'index.html'));
      } else {
        // If bridge is not up after waiting, load a specialized splash screen or fallback HTML
        console.error('[ACOS Electron] ERROR: Bridge server failed to connect in production mode.');
        mainWindow.loadFile(path.join(__dirname, '..', 'build', 'fallback_offline.html'));
      }

    };
    loadProduction();
  }

  // Graceful GPU fallback: if the renderer/GPU process crashes, relaunch in
  // software rendering mode instead of showing a stale blank window.
  let gpuFallbackDone = false;
  const relaunchSoftware = () => {
    if (gpuFallbackDone) return;
    gpuFallbackDone = true;
    console.warn('[ACOS Electron] GPU process crashed; relaunching in software rendering mode.');
    try { mainWindow.destroy(); } catch (e) { /* noop */ }
    app.commandLine.appendSwitch('disable-gpu');
    app.commandLine.appendSwitch('disable-gpu-compositing');
    app.relaunch();
    app.quit();
  };

  mainWindow.webContents.on('render-process-gone', (event, details) => {
    if (details.reason === 'crashed' || details.reason === 'gpu-process-exited') {
      relaunchSoftware();
    }
  });
  app.on('child-process-gone', (event, details) => {
    if (details.type === 'GPU') relaunchSoftware();
  });

  mainWindow.webContents.on('did-fail-load', (e, code, desc) => {
    console.error('[ACOS Electron] Failed to load URL:', desc, `(code ${code})`);
  });

  mainWindow.webContents.on('console-message', (e, level, message, line, sourceId) => {
    console.log(`[Renderer Console] ${message}`);
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });
}

app.whenReady().then(async () => {
  await startPythonBridge();
  createWindow();
});

app.on('window-all-closed', () => {
  if (pythonProcess) {
    pythonProcess.kill();
    pythonProcess = null;
  }
  if (process.platform !== 'darwin') {
    app.quit();
  }
});