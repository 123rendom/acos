# ACOS Material & Texture Intelligence Studio — Design Specification

> **Studio ID:** STUDIO-32
> **Version:** 1.0
> **Format:** Borderless 16:9 Desktop Application
> **Resolution Target:** 8K (7680 × 4320)
> **Design Language:** Dark Glass + Neural Illumination + PBR Material Preview

---

## 1. VISUAL IDENTITY

### 1.1 Color Palette

| Role | Token | Value |
|---|---|---|
| Deep Black Base | `--studio-bg-deep` | `#05050A` |
| Midnight Navy | `--studio-bg-midnight` | `#0A0E1A` |
| Surface Glass | `--studio-glass-bg` | `rgba(10, 14, 30, 0.72)` |
| Glass Border | `--studio-glass-border` | `rgba(0, 240, 255, 0.08)` |
| Material Accent | `--studio-material` | `#E8A838` |
| PBR Albedo | `--studio-albedo` | `#FFD93D` |
| Roughness | `--studio-roughness` | `#FF6B6B` |
| Metallic | `--studio-metallic` | `#4ECDC4` |
| Normal | `--studio-normal` | `#6C5CE7` |
| Emission | `--studio-emission` | `#00F0FF` |
| Height | `--studio-height` | `#A855F7` |
| AO | `--studio-ao` | `#2D3436` |
| Surface Text | `--studio-text` | `#F0F9FF` |
| Secondary Text | `--studio-text-dim` | `#64748B` |

### 1.2 Typography

- **Display:** Orbitron (headings, channel labels)
- **Body:** Inter (material properties, descriptions)
- **Mono:** JetBrains Mono (values, roughness, metallic)

### 1.3 Atmosphere

- Deep black background with subtle warm gradient (#0A0F1E → #05050A)
- Material accent (`#E8A838`) rim lighting on glass panels
- Glowing particles flowing from neural core onto 3D object surface
- Warm-cool dual-tone lighting for PBR accuracy

---

## 2. LAYOUT ARCHITECTURE

### 2.1 Full Desktop Layout (16:9)

```
+------------------------------------------------------------------+
|  APPLICATION BAR (ACOS Shell)                                   |
+------------------------------------------------------------------+
|                              |                                    |
|  LEFT: MATERIAL              |  CENTER: 3D OBJECT              |
|  LIBRARY                     |  PREVIEW WITH PBR              |
|                              |  RENDERING                     |
|  • Metal                     |                                    |
|  • Wood                      |  Material Channels Overlay     |
|  • Stone                     |  • Base Color                  |
|  • Concrete                  |  • Roughness                   |
|  • Glass                     |  • Metallic                    |
|  • Fabric                    |  • Normal                      |
|  • Leather                   |  • Height                      |
|  • Plastic                   |  • Displacement                |
|  • Organic                   |  • AO                          |
|  • Sci-Fi                    |  • Emission                    |
|  • Custom Materials          |                                    |
|                              |  Macro Inspection Lens         |
|  Glass Panels                |  Scratch/Pore/Imperfection     |
|  with warm-amber borders     |  View                          |
|                              |                                    |
+------------------------------|------------------------------------+
|                              |  RIGHT: MATERIAL                |
|  BOTTOM:                     |  INTELLIGENCE PANEL             |
|  TEXTURE TIMELINE            |                                    |
|  & VARIATION CARDS           |  • Physical Properties           |
|                              |  • Surface Detail                |
|                              |  • Reflection                    |
|                              |  • Refraction                    |
|                              |  • Roughness                     |
|                              |  • Micro Detail                  |
|                              |  • Scale                         |
|                              |  • Weathering                    |
+------------------------------------------------------------------+
|  STATUS BAR                                                       |
+------------------------------------------------------------------+
```

### 2.2 Panel Specifications

| Panel | Width | Style |
|---|---|---|
| Left: Material Library | 300px | Glass, warm-amber accents |
| Center: 3D Preview | Flex (remaining) | Full PBR render |
| Right: Intelligence | 330px | Glass, collapsible sections |
| Bottom: Timeline | 180px height | Glass strip with variations |

---

## 3. CENTER VIEWPORT

### 3.1 3D Object Preview

- **Real-time PBR rendering** with physically accurate light response
- **Interactive object rotation** (orbit, zoom, pan)
- **Environment HDR** with studio lighting setup
- **Macro inspection lens** — magnify surface detail up to 10x
- **Multi-views:** Full material, Channel-only, Comparison

### 3.2 PBR Channel Visualization

| Channel | Color | Preview Mode |
|---|---|---|
| Base Color | `#FFD93D` | Albedo swatch + object |
| Roughness | `#FF6B6B` | Gradient map overlay |
| Metallic | `#4ECDC4` | Metallic mask |
| Normal | `#6C5CE7` | Normal map preview |
| Height | `#A855F7` | Displacement heightmap |
| AO | `#2D3436` | Ambient occlusion map |
| Emission | `#00F0FF` | Glow map |
| Displacement | `#FFD93D` | Height displacement |

### 3.3 Macro Inspection

- Zoom levels: 1x, 2x, 5x, 10x
- Surface detail visible at 5x+
- Scratch visibility at 10x
- Pore structure at 10x+
- Imperfection overlay toggle

---

## 4. LEFT PANEL — MATERIAL LIBRARY

### 4.1 Categories

| Category | Icon | Color Tag | Description |
|---|---|---|---|
| Metal | `[Metal]` | `#B8B8B8` | Polished, brushed, oxidized metals |
| Wood | `[Wood]` | `#8B6914` | Natural grain, lacquered, raw |
| Stone | `[Stone]` | `#808080` | Marble, granite, slate, limestone |
| Concrete | `[Concrete]` | `#A0A0A0` | Smooth, rough, reinforced |
| Glass | `[Glass]` | `#B0E0E6` | Clear, frosted, tinted, prism |
| Fabric | `[Fabric]` | `#D2B48C` | Silk, cotton, denim, leather-like |
| Leather | `[Leather]` | `#8B4513` | Smooth, worn, patent, suede |
| Plastic | `[Plastic]` | `#E8E8E8` | Glossy, matte, translucent, ABS |
| Organic | `[Organic]` | `#556B2F` | Organic surfaces, skin, biological |
| Sci-Fi | `[Sci-Fi]` | `#00E5CC` | Holographic, energy, nanoweave |
| Custom Materials | `[Custom]` | `#E8A838` | User-created or AI-generated |

### 4.2 Material Card Style

- Glass background (`rgba(10, 14, 30, 0.72)`)
- Warm-amber border on hover (`rgba(232, 168, 56, 0.3)`)
- Mini PBR preview thumbnail
- Category badge with color coding
- Procedural indicator (neural pulse dot)

### 4.3 Material Variation Cards

Each material can have multiple variations:
- Polished vs Matte
- Wet vs Dry
- Aged vs New
- Hot vs Cold
- Damaged vs Intact

---

## 5. RIGHT PANEL — MATERIAL INTELLIGENCE

### 5.1 Section: Physical Properties

| Property | Range | Description |
|---|---|---|
| Base Color | Color picker | Albedo / diffuse color |
| Roughness | 0.0 – 1.0 | Micro-surface roughness |
| Metallic | 0.0 – 1.0 | Metal vs dielectric |
| IOR | 1.0 – 2.5 | Index of refraction |
| Transmission | 0.0 – 1.0 | Light transmission |
| Coating | 0.0 – 1.0 | Clearcoat layer |
| Coating Roughness | 0.0 – 1.0 | Clearcoat roughness |
| Sheen | 0.0 – 1.0 | Fabric-like sheen |
| Sheen Tint | 0° – 360° | Sheen color tint |

### 5.2 Section: Surface Detail

- **Normal Map strength:** 0.0 – 4.0
- **Displacement scale:** 0.0 – 10.0
- **Bump map strength:** 0.0 – 1.0
- **Micro-detail toggle:** Subsurface scattering
- **Noise layer:** Scale, detail, roughness
- **Surface generation mode:** Procedural / Baked / Painting

### 5.3 Section: Reflection

| Parameter | Value |
|---|---|
| Reflectance | 0% – 100% |
| Fresnel | Linear / Schlick / Complex |
| Reflectivity Color | `#FFD93D` |
| Environment Contribution | 0% – 100% |
| Mirror Quality | Low / Medium / High / Ultra |
| Reflection Blur | 0 – 10 |

### 5.4 Section: Refraction

| Parameter | Value |
|---|---|
| IOR | 1.0003 (Air) – 2.42 (Diamond) |
| Transmission Color | RGB |
| Absorption Distance | 0.1 – 100 cm |
| Absorption Color | RGB |
| Thickness | 0.1 – 10 cm |
| Dispersion | 0.0 – 1.0 |
| Anisotropy | 0.0 – 1.0 |

### 5.5 Section: Roughness

- **Roughness map** visualization
- **Anisotropy direction** control
- **Tangent rotation** 0° – 360°
- **Height-to-roughness conversion** toggle
- **Subsurface scattering** parameters
- **Roughness distribution** histogram

### 5.6 Section: Micro Detail

- **Scale:** 0.001mm – 10mm
- **Feature type:** Pores, scratches, dents, grain
- **Density:** 0% – 100%
- **Depth:** 0.001 – 5.0 units
- **Random seed**
- **Procedural generation** toggle
- **Noise algorithm:** Perlin, Voronoi, Worley, Curl

### 5.7 Section: Scale

- **Real-world scale:** mm, cm, m, inches
- **Tiling:** U/V repeat count
- **Mapping projection:** Planar, Box, Sphere, Cylindrical
- **UV overlap detection**
- **Texture resolution:** 256 – 16384

### 5.8 Section: Weathering

| Parameter | Range | Description |
|---|---|---|
| Age | 0 – 100 years | Surface aging |
| Wear | 0% – 100% | Surface wear level |
| Dirt | 0% – 100% | Dirt/dust accumulation |
| Moisture | 0% – 100% | Wetness level |
| Oxidation | 0% – 100% | Metal oxidation |
| Cracks | 0 – 100 | Number of cracks |
| Patina | Color | Oxidation color |
| Damage | Boolean | Enable damage pattern |

---

## 6. BOTTOM PANEL — TEXTURE GENERATION TIMELINE

### 6.1 Texture Generation Timeline

- Horizontal timeline showing generation steps:
  - **BASE** (albedo generation)
  - **ROUGHNESS** (roughness map)
  - **METALLIC** (metallic map)
  - **NORMAL** (normal map)
  - **HEIGHT** (displacement map)
  - **AO** (ambient occlusion)
  - **EMISSION** (emission map)
  - **WEATHERING** (damage/dirt overlay)
  - **COMPOSE** (final material pack)

### 6.2 Material Variation Cards

```
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│  Polished    │  │  Matte       │  │  Brushed    │
│  Metal       │  │  Metal       │  │  Metal      │
│  Rough: 0.05 │  │  Rough: 0.7  │  │  Rough: 0.3 │
│  [Preview]   │  │  [Preview]   │  │  [Preview]  │
└─────────────┘  └─────────────┘  └─────────────┘
```

- Click to switch variation
- Side-by-side comparison mode
- Drag to reorder variations
- Favorite/bookmark variations

---

## 7. AI TEXTURE AGENT

### 7.1 State Machine

```
SCANNING → SAMPLING → GENERATING → APPLYING → REFINING → WEATHERING → POLISHING → VALIDATED
```

### 7.2 State Visualizations

| State | Color | Animation | Description |
|---|---|---|---|
| SCANNING | `#A855F7` | Violet scan ring | AI analyzes target surface |
| SAMPLING | `#6C5CE7` | Blue particles gathering | AI samples reference data |
| GENERATING | `#E8A838` | Gold particle flow | AI generates texture maps |
| APPLYING | `#00F0FF` | Cyan flow onto surface | AI applies PBR channels |
| REFINING | `#4ECDC4` | Green smoothing waves | AI refines micro-detail |
| WEATHERING | `#FF6B6B` | Red weathering particles | AI adds aging effects |
| POLISHING | `#FFD93D` | Gold polish shimmer | AI finalizes surface |
| VALIDATED | `#10B981` | Steady green, check pulse | AI validates material quality |

### 7.3 Neural Particle Flow

The AI Texture Agent creates materials procedurally:
1. Glowing particles (`#E8A838`) flow from the neural core
2. Particles travel along the 3D object surface
3. As they reach target areas, they crystallize into texture detail
4. Each PBR channel gets its own particle stream color
5. Final material shows all channels composited
6. Particles settle into a stable surface representation

---

## 8. PARTICLE VISUALIZATION

### 8.1 AI-Generated Material Flow

When the AI generates a material:

1. **Particle Phase (0-25%):**
   - Glowing gold particles (`#E8A838`) emanate from neural core
   - Particles flow toward the 3D object surface
   - Individual particles visible as bright points
   - Flow speed increases with generation progress

2. **Crystallization Phase (25-55%):**
   - Particles begin forming into texture patterns
   - Each channel forms its own crystal cluster:
     - Albedo → Yellow crystal
     - Roughness → Red crystal
     - Metallic → Cyan crystal
     - Normal → Purple crystal
   - Crystal formations match surface geometry
   - Violet neural energy (`#A855F7`) connects channels

3. **Detail Phase (55-80%):**
   - Micro-details emerge from crystal formations
   - Scratches, pores, imperfections visible
   - Surface roughness variation becomes apparent
   - Reflection properties update in real-time

4. **Weathering Phase (80-95%):**
   - Red/orange weathering particles overlay surface
   - Dirt, oxidation, and wear patterns appear
   - Age and damage effects applied
   - Wet/dry variation preview

5. **Completion (95-100%):**
   - All particles stabilize
   - Material shows full PBR properties
   - Final quality validation
   - Green pulse wave across surface

### 8.2 Particle Parameters

| Parameter | Value |
|---|---|
| Particle Count | 500K – 5M |
| Particle Size | 0.5 – 3.0 px |
| Albedo Color | `#FFD93D` |
| Roughness Color | `#FF6B6B` |
| Metallic Color | `#4ECDC4` |
| Normal Color | `#6C5CE7` |
| Height Color | `#A855F7` |
| Emission Color | `#00F0FF` |
| Neural Core | `#E8A838` |
| Convergence Speed | 0.5 – 2.0 units/sec |
| Animation Duration | 4 – 10 seconds |

---

## 9. WIREFRAME-TO-FINAL-MATERIAL TRANSITION

### 9.1 Transition Modes

| Mode | Description | Duration |
|---|---|---|
| Wireframe → Albedo | Edges dissolve, base color appears | 0.6s |
| Albedo → Roughness | Color fades, roughness map overlays | 0.8s |
| Roughness → Full PBR | All channels compose into material | 1.0s |
| Full PBR → X-Ray | Transparent material with channel view | 0.3s |
| Full PBR → Wireframe | Material dissolves into wireframe | 0.6s |
| Macro → Full | Close-up detail expands to full view | 0.4s |

### 9.2 Transition Controls

- Toggle button in viewport overlay
- Channel visibility toggles
- Keyboard shortcuts: `1`-`8` for channel layers
- Smooth interpolation with easing curves

---

## 10. PHYSICALLY ACCURATE LIGHTING

### 10.1 Studio Lighting Setup

| Light | Type | Color | Intensity |
|---|---|---|---|
| Key Light | Area | `#FFF5E6` | 10000 lux |
| Fill Light | Area | `#B0C4DE` | 3000 lux |
| Rim Light | Point | `#00F0FF` | 5000 lux |
| Bottom Fill | Area | `#2A2040` | 1000 lux |
| Environment HDR | Sky | 360° | Variable |

### 10.2 Light Response Visualization

- Real-time reflection update
- Fresnel effect visualization
- Metal vs dielectric response comparison
- Transmission through glass/water preview
- Subsurface scattering preview

---

## 11. INTERACTION PATTERNS

### 11.1 Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `1` | Toggle Base Color channel |
| `2` | Toggle Roughness channel |
| `3` | Toggle Metallic channel |
| `4` | Toggle Normal channel |
| `5` | Toggle Height channel |
| `6` | Toggle AO channel |
| `7` | Toggle Emission channel |
| `8` | Toggle Displacement channel |
| `W` | Wireframe overlay |
| `X` | X-Ray transparency |
| `M` | Macro inspection lens |
| `C` | Compare variations |
| `G` | Generate new material |
| `S` | Save material preset |
| `Ctrl+Z` | Undo |
| `Ctrl+Shift+Z` | Redo |
| `Space` | Play/pause generation |

### 11.2 Mouse Interactions

| Action | Button |
|---|---|
| Orbit object | Left drag |
| Pan view | Middle drag / Alt+Left |
| Zoom | Scroll wheel |
| Select material | Left click in library |
| Pick color | Alt+Left click on surface |
| Paint texture | Middle drag on surface |
| Scrub parameter | Left drag on slider |
| Rotate light | Right drag |

---

## 12. MOTION & ANIMATION

### 12.1 Panel Transitions

- Left panel slide-in/out: 300ms ease-out
- Right panel collapse/expand: 250ms ease-in-out
- Bottom timeline expand/collapse: 200ms linear
- Channel toggle transitions: 150ms ease
- Material variation switch: 400ms crossfade

### 12.2 Neural Particle Activity

- Background particle density varies with AI activity
- When AI is generating, particles flow toward viewport
- Particle color matches current AI agent state color
- Idle state: ambient particles at 10% opacity
- Active state: directed particle streams at 50% opacity
- Channel-specific streams for multi-channel generation

---

## 13. DESIGN SYSTEM COMPONENTS

### 13.1 Material Swatch

```jsx
<MaterialSwatch
  name="Polished Copper"
  color="#B87333"
  roughness={0.25}
  metallic={0.95}
  thumbnail="auto"
  isProcedural={true}
/>
```

### 13.2 Channel Toggle

```jsx
<ChannelToggle
  label="Roughness"
  color="#FF6B6B"
  value={0.65}
  onChange={(v) => updateChannel('roughness', v)}
/>
```

### 13.3 Material Card

```jsx
<MaterialCard
  name="Ancient Marble"
  category="Stone"
  channels={['baseColor', 'roughness', 'normal', 'ao']}
  variations={['polished', 'weathered', 'aged']}
  isAIGenerated={false}
/>
```

### 13.4 Button Styles

| Type | Background | Border | Text |
|---|---|---|---|
| Primary | `rgba(232, 168, 56, 0.15)` | `#E8A838` | `#F0F9FF` |
| Secondary | `rgba(108, 92, 231, 0.1)` | `#6C5CE7` | `#F0F9FF` |
| Channel | `rgba(0, 240, 255, 0.1)` | `#00F0FF` | `#F0F9FF` |
| Ghost | transparent | `#3A3A50` | `#A0A0B0` |
| Danger | `rgba(244, 67, 54, 0.15)` | `#EF6262` | `#FF6B6B` |

---

## 14. TECHNICAL SPECIFICATIONS

### 14.1 Performance Targets

| Metric | Target |
|---|---|
| PBR Render FPS | 60fps @ 4K |
| Channel Toggle | < 50ms |
| Material Switch | < 100ms |
| Texture Generation | < 5s |
| Macro Zoom | < 30ms |
| Parameter Update | < 16ms |
| Material Save/Load | < 2s |

### 14.2 Material Resolution

| Quality Level | Resolution | Channel Count |
|---|---|---|
| Preview | 512×512 | 4 |
| Standard | 2048×2048 | 6 |
| High | 4096×4096 | 8 |
| Ultra | 8192×8192 | 8 |
| Master | 16384×16384 | 8 + custom |

### 14.3 Supported Material Models

- **PBR Standard** (Metallic/Roughness workflow)
- **PBR Clearcoat** (Additional coat layer)
- **Subsurface Scattering** (Skin, wax, milk)
- **Transmission** (Glass, water, gemstones)
- **Volume Scatter** (Frosted glass, smoke)
- **Hair/Fur** (Strand-based rendering)
- **Decal** (Overlay projection)

---

## 15. DESIGN COHERENCE WITH ACOS ECOSYSTEM

This studio shares the following design DNA with all other ACOS studios:

- **Neural Core:** Central glowing node that pulses with AI activity
- **Glass Surfaces:** Consistent transparency and blur levels
- **Particle Activity:** Background neural particles respond to system state
- **Material Accent (`#E8A838`):** Shared warm-amber accent color
- **Spatial Transitions:** Smooth panel animations across all studios
- **AI Agent Pattern:** Consistent state machine visualization
- **Typography:** Orbitron + Inter + JetBrains Mono font stack
- **Design Tokens:** Single source of truth via `DesignTokens`

---

*Specification Version 1.0 — ACOS Creative Operating System*
*Design Standard: 8K, 16:9, Borderless Desktop*
*Color System: Deep Black + Midnight Navy + Material Accent + Neural Particles*
