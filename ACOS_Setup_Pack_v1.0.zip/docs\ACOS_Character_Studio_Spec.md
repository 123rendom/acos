# ACOS Character Intelligence Studio — Design Specification

> **Studio ID:** STUDIO-05
> **Version:** 1.0 · **Format:** Borderless 16:9 · **Resolution:** 8K · **Language:** Dark Glass + Neural Core + Character DNA Graph

## 1. Visual Identity
| Token | Value |
|---|---|
| --acos-bg-deep | `#05050A` |
| --acos-bg-navy | `#0A0E1A` |
| --acos-glass | `rgba(10,14,30,0.72)` + blur 20px + border `rgba(0,240,255,0.08)` |
| --acos-cyan | `#00F0FF` (connections) |
| --acos-magenta | `#D35DB8` (characters) |
| --acos-violet | `#9D7BFF` (personality/voice) |
| --acos-amber | `#F59E0B` (wardrobe/deviation) |
| --acos-green | `#10B981` (continuity 98%+) |

Typography Orbitron/Inter/JetBrains Mono. Holographic vectors, portrait lighting (key+fill+rim), skin subsurface, DOF, particles.

## 2. Layout 16:9
```
+---------------------------------------------------------------+
| APP BAR                                                     |
+---------------------------------------------------------------+
| LEFT 300px | CENTER flex (Character Preview + DNA Graph) | RIGHT 340px |
| Library    | Turntable · Expressions · Poses · Wardrobe | Intelligence|
| 8 cards    | ultra-realistic portrait, 3-angle strip     | 11 sections |
| identity   | DNA graph: 7 nodes around core              | consistency |
| status     |                                             | % + deviations|
+---------------------------------------------------------------+
| BOTTOM 160px: Character Continuity Timeline (Scenes 01-12)   |
+---------------------------------------------------------------+
| STATUS BAR                                                  |
+---------------------------------------------------------------+
```

## 3. Center — Character Preview
- **Turntable:** 0°/45°/90° strips, drag to rotate 360°, auto-spin 12s
- **States:** Neutral / Joy / Anger / Fear / Sadness / Suspense · Poses: Standing / Action / Close-up · Wardrobe: Hero / Alternate / Aged
- **Rendering:** Skin SSS, fabric micro-weave, hair strands, eye caustics, portrait light (key 5600K, fill 4500K, rim cyan), DOF f/2.8
- **Vectors:** Holographic measurement overlay (height, eye-distance, shoulder) cyan 30% opacity, toggled via `M`
- **Selection glow:** cyan ring on active, amber pulse on deviation

## 4. Character DNA Graph
Core at preview bottom-center → 7 nodes: **Appearance · Personality · Voice · Wardrobe · Props · Relationships · Scenes**
- Nodes 28-36px, color per domain, 1.2px bezier + particles (8/edge) when attribute modified
- Core pulse propagates to graph on change (120ms stagger)
- Deviation: node border amber + tooltip "Wardrobe mismatch Scene 07 vs 08"

## 5. Left — Character Library 300px
8 cards: `ARJUN (Lead) 98.2% · PRIYA (Support) 97.4% · VIKRAM (Antagonist) 96.8% · ...` Each: 48px avatar, name/role, consistency bar (green 90-100, amber 75-90, red <75), status pill (Locked/Synced/Draft/Deviation), 3-angle thumb strip. Filter by Status/Role, search, `+ New Character` CTA magenta.

## 6. Right — Character Intelligence 340px
11 collapsible sections:
**Identity** (name/role/archetype) · **Age** (24, slider) · **Appearance** (height/eye/skin/hair) · **Personality** (Big Five sliders) · **Voice** (Hindi/Neutral/Warm, sample) · **Emotion** (6 emotes + intensity) · **Wardrobe** (Hero/Alt/Aged + fabric) · **Body Language** (posture/gesture) · **Relationships** (graph to other chars) · **Backstory** (bio, 240ch) · **Continuity** (98.2% gauge + 2 deviations list)
Modify any → glowing connection core→DNA→preview (cyan filament, crystallize 300ms).

## 7. Bottom — Continuity Timeline 160px
Scenes 01-12 horizontal: each block shows character state (thumb + emotion + wardrobe). Line graph of consistency % (98→97→98). Amber pulse on Scene 07-08 deviation, click to diff drawer. Progress `Sc 04/12`.

## 8. AI States
`IDLE → ANALYZING_CHARACTER → GENERATING_VARIANT → CHECKING_CONSISTENCY → SYNCING_DNA → VALIDATED` (slate→cyan→magenta→amber→cyan→green, 140ms tick).

## 9. Interaction
Click card = load + preview crossfade 400ms + DNA propagate. Drag attribute = live preview. Right-click = Generate Variant / Style Transfer / Deviation Check / Expression Sheet. `Ctrl+K` palette, `V` voice, `W` wardrobe.

## 10. Tech
Canvas portrait composite + DNA graph @60fps, 12 particles/edge, 140ms AI tick, VRAM <250MB, slider <16ms.

*Spec 1.0 — Character Lab — 8K 16:9 — Glass + Magenta/Cyan/Violet — Hollywood Portrait*
