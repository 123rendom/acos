# ACOS Cinematography Studio — Design Specification

> **Studio ID:** STUDIO-07
> **Version:** 1.0 · **Format:** Borderless 16:9 · **Resolution:** 8K · **Language:** Dark Glass + Camera Trajectory + Anamorphic Optics

## 1. Visual Identity
| Token | Value |
|---|---|
| --acos-bg-deep | `#05050A` |
| --acos-bg-navy | `#0A0E1A` |
| --acos-glass | `rgba(10,14,30,0.72)` + blur 20px + border `rgba(0,240,255,0.08)` |
| --acos-cam | `#FFB547` (Cinematography) |
| --acos-cyan | `#00F0FF` (active camera, trajectory) |
| --acos-violet | `#9D7BFF` (focus/DOF) |
| --acos-green | `#10B981` (safe zones) |

Typography Orbitron/Inter/JetBrains Mono. Anamorphic lens reflections, volumetric light, photoreal optics.

## 2. Layout 16:9
```
+---------------------------------------------------------------+
| APP BAR                                                     |
+---------------------------------------------------------------+
| LEFT 300px | CENTER flex (Cinematic 3D Viewport) | RIGHT 340px |
| Shot List  | Virtual camera body · frustum ·       | Cinematography |
| Shot 001   | trajectory vector paths (glowing)     | Lens/Focal/Aperture |
| Shot 002   | framing guides · safe zones ·         | Shutter/ISO/Height |
| wide/med/  | rule-of-thirds · lens distortion ·    | Distance/Focus/ |
| close/trk/ | depth indicators · focus plane       | Movement/Speed/ |
| crane/dolly|                                       | Framing/Composition/|
| aerial     |                                       | DOF/Motion Blur  |
+---------------------------------------------------------------+
| BOTTOM 160px: Camera Movement Timeline — keyframes + curves |
+---------------------------------------------------------------+
| STATUS BAR                                                  |
+---------------------------------------------------------------+
```

## 3. Center — Cinematic Viewport
- **Virtual camera body:** 3D mesh with lens barrel, illuminated cyan when active (`#00F0FF` rim + `0 0 18px` glow), inactive slate
- **Frustum:** Wireframe pyramid (cyan 0.45), near/far planes, focus plane (violet dashed), lens cone (anamorphic streak)
- **Trajectory:** Glowing 3D vector paths (cyan polyline + 14 particles traveling when params change, speed 0.8u/s), keyframe diamonds on path
- **Guides:** Rule-of-thirds grid (white 0.18), safe zones (green 0.12), center cross, horizon
- **Optics:** Focal length 18/35/50/85mm switchable, aperture f/1.4–f/16, DOF preview (bokeh), motion blur shutter 1/48–1/2000, lens distortion preview (barrel/pincushion)
- **Interaction:** Orbit/pan/zoom, drag camera (L-drag), rotate (R-drag), focal wheel, click focus target

## 4. Left — Shot List 300px
Shots 001-012: `Shot 001 — Wide Establishing · 18mm · f/8 · 1/48` etc. Tags: close-up/medium/wide/tracking/crane/dolly/aerial. Selected = cyan border + amber `REC` dot. Filter by lens/movement. `+ New Shot` CTA amber.

## 5. Right — Cinematography Control 340px
14 controls:
**Lens** (select) · **Focal Length** (18-135mm slider) · **Aperture** (f/1.4-f/16) · **Shutter** (1/24-1/2000) · **ISO** (100-3200) · **Camera Height** (0.5-3.0m) · **Distance** (1-50m) · **Focus Target** (character/prop) · **Movement** (static/dolly/crane/tracking/aerial) · **Speed** (0.2-3.0m/s) · **Framing** (center/thirds/golden) · **Composition** (symmetry/rule/thirds) · **Depth of Field** (shallow/deep) · **Motion Blur** (0-100%)
Change → cyan particles travel trajectory, camera illuminates.

## 6. Bottom — Movement Timeline 160px
Keyframes (diamonds) + bezier trajectory curves (cyan). Scrub playhead (cyan line), snap to frames, easing handles. Time `00:14:00 / 00:42:00`. Speed graph overlay. Click keyframe = jump + focus pulse.

## 7. AI States
`IDLE → ANALYZING_SCENE → GENERATING_TRAJECTORY → OPTIMIZING_FRAMING → SIMULATING_DOF → VALIDATED` (slate→amber→cyan→violet→cyan→green, 130ms tick).

## 8. Interaction
Drag trajectory point = reshape path (live update). Slider = live DOF/framing. Right-click shot = Duplicate / Generate Alternative / Check Continuity. `Ctrl+K` palette, `C` camera, `G` generate.

## 9. Tech
Canvas 2D trajectory @60fps (40 particles), Three-like frustum math in 2D, 130ms AI tick, <16ms slider, VRAM <220MB.

*Spec 1.0 — Camera Lab — 8K 16:9 — Glass + Amber/Cyan/Violet — Hollywood Optics*
